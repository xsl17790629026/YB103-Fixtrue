﻿#ifndef __DATABASE_H
#define __DATABASE_H
#include "TSMaster.h"

// CAN Databases
// CAN Message GSM_1_1
extern const TCANSignal GSM_GearShiftAuthRelease_GSM_1_1;
struct _GSM_1_1;
typedef struct _GSM_1_1 TGSM_1_1;
struct _GSM_1_1{
  TCAN FCAN;
  double get_GSM_GearShiftAuthRelease(void) { return com.get_can_signal_value((TCANSignal* const)&GSM_GearShiftAuthRelease_GSM_1_1, FCAN.FData);}
  void set_GSM_GearShiftAuthRelease(const double value) { com.set_can_signal_value((TCANSignal* const)&GSM_GearShiftAuthRelease_GSM_1_1, FCAN.FData, value);}
  __declspec(property(get = get_GSM_GearShiftAuthRelease, put = set_GSM_GearShiftAuthRelease)) double GSM_GearShiftAuthRelease;
  void init() { FCAN = create().FCAN; }
  TGSM_1_1 create() { CANMsgDecl(_GSM_1_1, cGSM_1_1, 0, 0, 8, 899) return cGSM_1_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message ABS_1_1
extern const TCANSignal ABS_FLWheelSpeedValid_ABS_1_1;
extern const TCANSignal ABS_FLWheelSpeed_ABS_1_1;
extern const TCANSignal ABS_FLWheelSpeedRC_ABS_1_1;
extern const TCANSignal ABS_FRWheelSpeedValid_ABS_1_1;
extern const TCANSignal ABS_FRWheelSpeed_ABS_1_1;
extern const TCANSignal ABS_FRWheelSpeedRC_ABS_1_1;
extern const TCANSignal ABS_1_RollingCounter_ABS_1_1;
extern const TCANSignal ABS_FLWheelSts_ABS_1_1;
extern const TCANSignal ABS_FRWheelSts_ABS_1_1;
extern const TCANSignal ABS_1_Checksum_ABS_1_1;
struct _ABS_1_1;
typedef struct _ABS_1_1 TABS_1_1;
struct _ABS_1_1{
  TCAN FCAN;
  double get_ABS_FLWheelSpeedValid(void) { return com.get_can_signal_value((TCANSignal* const)&ABS_FLWheelSpeedValid_ABS_1_1, FCAN.FData);}
  void set_ABS_FLWheelSpeedValid(const double value) { com.set_can_signal_value((TCANSignal* const)&ABS_FLWheelSpeedValid_ABS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_ABS_FLWheelSpeedValid, put = set_ABS_FLWheelSpeedValid)) double ABS_FLWheelSpeedValid;
  double get_ABS_FLWheelSpeed(void) { return com.get_can_signal_value((TCANSignal* const)&ABS_FLWheelSpeed_ABS_1_1, FCAN.FData);}
  void set_ABS_FLWheelSpeed(const double value) { com.set_can_signal_value((TCANSignal* const)&ABS_FLWheelSpeed_ABS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_ABS_FLWheelSpeed, put = set_ABS_FLWheelSpeed)) double ABS_FLWheelSpeed;
  double get_ABS_FLWheelSpeedRC(void) { return com.get_can_signal_value((TCANSignal* const)&ABS_FLWheelSpeedRC_ABS_1_1, FCAN.FData);}
  void set_ABS_FLWheelSpeedRC(const double value) { com.set_can_signal_value((TCANSignal* const)&ABS_FLWheelSpeedRC_ABS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_ABS_FLWheelSpeedRC, put = set_ABS_FLWheelSpeedRC)) double ABS_FLWheelSpeedRC;
  double get_ABS_FRWheelSpeedValid(void) { return com.get_can_signal_value((TCANSignal* const)&ABS_FRWheelSpeedValid_ABS_1_1, FCAN.FData);}
  void set_ABS_FRWheelSpeedValid(const double value) { com.set_can_signal_value((TCANSignal* const)&ABS_FRWheelSpeedValid_ABS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_ABS_FRWheelSpeedValid, put = set_ABS_FRWheelSpeedValid)) double ABS_FRWheelSpeedValid;
  double get_ABS_FRWheelSpeed(void) { return com.get_can_signal_value((TCANSignal* const)&ABS_FRWheelSpeed_ABS_1_1, FCAN.FData);}
  void set_ABS_FRWheelSpeed(const double value) { com.set_can_signal_value((TCANSignal* const)&ABS_FRWheelSpeed_ABS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_ABS_FRWheelSpeed, put = set_ABS_FRWheelSpeed)) double ABS_FRWheelSpeed;
  double get_ABS_FRWheelSpeedRC(void) { return com.get_can_signal_value((TCANSignal* const)&ABS_FRWheelSpeedRC_ABS_1_1, FCAN.FData);}
  void set_ABS_FRWheelSpeedRC(const double value) { com.set_can_signal_value((TCANSignal* const)&ABS_FRWheelSpeedRC_ABS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_ABS_FRWheelSpeedRC, put = set_ABS_FRWheelSpeedRC)) double ABS_FRWheelSpeedRC;
  double get_ABS_1_RollingCounter(void) { return com.get_can_signal_value((TCANSignal* const)&ABS_1_RollingCounter_ABS_1_1, FCAN.FData);}
  void set_ABS_1_RollingCounter(const double value) { com.set_can_signal_value((TCANSignal* const)&ABS_1_RollingCounter_ABS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_ABS_1_RollingCounter, put = set_ABS_1_RollingCounter)) double ABS_1_RollingCounter;
  double get_ABS_FLWheelSts(void) { return com.get_can_signal_value((TCANSignal* const)&ABS_FLWheelSts_ABS_1_1, FCAN.FData);}
  void set_ABS_FLWheelSts(const double value) { com.set_can_signal_value((TCANSignal* const)&ABS_FLWheelSts_ABS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_ABS_FLWheelSts, put = set_ABS_FLWheelSts)) double ABS_FLWheelSts;
  double get_ABS_FRWheelSts(void) { return com.get_can_signal_value((TCANSignal* const)&ABS_FRWheelSts_ABS_1_1, FCAN.FData);}
  void set_ABS_FRWheelSts(const double value) { com.set_can_signal_value((TCANSignal* const)&ABS_FRWheelSts_ABS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_ABS_FRWheelSts, put = set_ABS_FRWheelSts)) double ABS_FRWheelSts;
  double get_ABS_1_Checksum(void) { return com.get_can_signal_value((TCANSignal* const)&ABS_1_Checksum_ABS_1_1, FCAN.FData);}
  void set_ABS_1_Checksum(const double value) { com.set_can_signal_value((TCANSignal* const)&ABS_1_Checksum_ABS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_ABS_1_Checksum, put = set_ABS_1_Checksum)) double ABS_1_Checksum;
  void init() { FCAN = create().FCAN; }
  TABS_1_1 create() { CANMsgDecl(_ABS_1_1, cABS_1_1, 0, 0, 8, 512) return cABS_1_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message ABS_2_1
extern const TCANSignal ABS_RLWheelSpeedValid_ABS_2_1;
extern const TCANSignal ABS_RLWheelSpeed_ABS_2_1;
extern const TCANSignal ABS_RLWheelSpeedRC_ABS_2_1;
extern const TCANSignal ABS_RRWheelSpeedValid_ABS_2_1;
extern const TCANSignal ABS_RRWheelSpeed_ABS_2_1;
extern const TCANSignal ABS_RRWheelSpeedRC_ABS_2_1;
extern const TCANSignal ABS_2_RollingCounter_ABS_2_1;
extern const TCANSignal ABS_RLWheelSts_ABS_2_1;
extern const TCANSignal ABS_RRWheelSts_ABS_2_1;
extern const TCANSignal ABS_2_Checksum_ABS_2_1;
struct _ABS_2_1;
typedef struct _ABS_2_1 TABS_2_1;
struct _ABS_2_1{
  TCAN FCAN;
  double get_ABS_RLWheelSpeedValid(void) { return com.get_can_signal_value((TCANSignal* const)&ABS_RLWheelSpeedValid_ABS_2_1, FCAN.FData);}
  void set_ABS_RLWheelSpeedValid(const double value) { com.set_can_signal_value((TCANSignal* const)&ABS_RLWheelSpeedValid_ABS_2_1, FCAN.FData, value);}
  __declspec(property(get = get_ABS_RLWheelSpeedValid, put = set_ABS_RLWheelSpeedValid)) double ABS_RLWheelSpeedValid;
  double get_ABS_RLWheelSpeed(void) { return com.get_can_signal_value((TCANSignal* const)&ABS_RLWheelSpeed_ABS_2_1, FCAN.FData);}
  void set_ABS_RLWheelSpeed(const double value) { com.set_can_signal_value((TCANSignal* const)&ABS_RLWheelSpeed_ABS_2_1, FCAN.FData, value);}
  __declspec(property(get = get_ABS_RLWheelSpeed, put = set_ABS_RLWheelSpeed)) double ABS_RLWheelSpeed;
  double get_ABS_RLWheelSpeedRC(void) { return com.get_can_signal_value((TCANSignal* const)&ABS_RLWheelSpeedRC_ABS_2_1, FCAN.FData);}
  void set_ABS_RLWheelSpeedRC(const double value) { com.set_can_signal_value((TCANSignal* const)&ABS_RLWheelSpeedRC_ABS_2_1, FCAN.FData, value);}
  __declspec(property(get = get_ABS_RLWheelSpeedRC, put = set_ABS_RLWheelSpeedRC)) double ABS_RLWheelSpeedRC;
  double get_ABS_RRWheelSpeedValid(void) { return com.get_can_signal_value((TCANSignal* const)&ABS_RRWheelSpeedValid_ABS_2_1, FCAN.FData);}
  void set_ABS_RRWheelSpeedValid(const double value) { com.set_can_signal_value((TCANSignal* const)&ABS_RRWheelSpeedValid_ABS_2_1, FCAN.FData, value);}
  __declspec(property(get = get_ABS_RRWheelSpeedValid, put = set_ABS_RRWheelSpeedValid)) double ABS_RRWheelSpeedValid;
  double get_ABS_RRWheelSpeed(void) { return com.get_can_signal_value((TCANSignal* const)&ABS_RRWheelSpeed_ABS_2_1, FCAN.FData);}
  void set_ABS_RRWheelSpeed(const double value) { com.set_can_signal_value((TCANSignal* const)&ABS_RRWheelSpeed_ABS_2_1, FCAN.FData, value);}
  __declspec(property(get = get_ABS_RRWheelSpeed, put = set_ABS_RRWheelSpeed)) double ABS_RRWheelSpeed;
  double get_ABS_RRWheelSpeedRC(void) { return com.get_can_signal_value((TCANSignal* const)&ABS_RRWheelSpeedRC_ABS_2_1, FCAN.FData);}
  void set_ABS_RRWheelSpeedRC(const double value) { com.set_can_signal_value((TCANSignal* const)&ABS_RRWheelSpeedRC_ABS_2_1, FCAN.FData, value);}
  __declspec(property(get = get_ABS_RRWheelSpeedRC, put = set_ABS_RRWheelSpeedRC)) double ABS_RRWheelSpeedRC;
  double get_ABS_2_RollingCounter(void) { return com.get_can_signal_value((TCANSignal* const)&ABS_2_RollingCounter_ABS_2_1, FCAN.FData);}
  void set_ABS_2_RollingCounter(const double value) { com.set_can_signal_value((TCANSignal* const)&ABS_2_RollingCounter_ABS_2_1, FCAN.FData, value);}
  __declspec(property(get = get_ABS_2_RollingCounter, put = set_ABS_2_RollingCounter)) double ABS_2_RollingCounter;
  double get_ABS_RLWheelSts(void) { return com.get_can_signal_value((TCANSignal* const)&ABS_RLWheelSts_ABS_2_1, FCAN.FData);}
  void set_ABS_RLWheelSts(const double value) { com.set_can_signal_value((TCANSignal* const)&ABS_RLWheelSts_ABS_2_1, FCAN.FData, value);}
  __declspec(property(get = get_ABS_RLWheelSts, put = set_ABS_RLWheelSts)) double ABS_RLWheelSts;
  double get_ABS_RRWheelSts(void) { return com.get_can_signal_value((TCANSignal* const)&ABS_RRWheelSts_ABS_2_1, FCAN.FData);}
  void set_ABS_RRWheelSts(const double value) { com.set_can_signal_value((TCANSignal* const)&ABS_RRWheelSts_ABS_2_1, FCAN.FData, value);}
  __declspec(property(get = get_ABS_RRWheelSts, put = set_ABS_RRWheelSts)) double ABS_RRWheelSts;
  double get_ABS_2_Checksum(void) { return com.get_can_signal_value((TCANSignal* const)&ABS_2_Checksum_ABS_2_1, FCAN.FData);}
  void set_ABS_2_Checksum(const double value) { com.set_can_signal_value((TCANSignal* const)&ABS_2_Checksum_ABS_2_1, FCAN.FData, value);}
  __declspec(property(get = get_ABS_2_Checksum, put = set_ABS_2_Checksum)) double ABS_2_Checksum;
  void init() { FCAN = create().FCAN; }
  TABS_2_1 create() { CANMsgDecl(_ABS_2_1, cABS_2_1, 0, 0, 8, 513) return cABS_2_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message ABS_3_1
extern const TCANSignal ABS_VehicleSpeedValid_ABS_3_1;
extern const TCANSignal ABS_AbsFault_ABS_3_1;
extern const TCANSignal ABS_AbsActive_ABS_3_1;
extern const TCANSignal ABS_VehicleSpeed_ABS_3_1;
extern const TCANSignal ABS_EbdFault_ABS_3_1;
extern const TCANSignal ABS_EbdActive_ABS_3_1;
struct _ABS_3_1;
typedef struct _ABS_3_1 TABS_3_1;
struct _ABS_3_1{
  TCAN FCAN;
  double get_ABS_VehicleSpeedValid(void) { return com.get_can_signal_value((TCANSignal* const)&ABS_VehicleSpeedValid_ABS_3_1, FCAN.FData);}
  void set_ABS_VehicleSpeedValid(const double value) { com.set_can_signal_value((TCANSignal* const)&ABS_VehicleSpeedValid_ABS_3_1, FCAN.FData, value);}
  __declspec(property(get = get_ABS_VehicleSpeedValid, put = set_ABS_VehicleSpeedValid)) double ABS_VehicleSpeedValid;
  double get_ABS_AbsFault(void) { return com.get_can_signal_value((TCANSignal* const)&ABS_AbsFault_ABS_3_1, FCAN.FData);}
  void set_ABS_AbsFault(const double value) { com.set_can_signal_value((TCANSignal* const)&ABS_AbsFault_ABS_3_1, FCAN.FData, value);}
  __declspec(property(get = get_ABS_AbsFault, put = set_ABS_AbsFault)) double ABS_AbsFault;
  double get_ABS_AbsActive(void) { return com.get_can_signal_value((TCANSignal* const)&ABS_AbsActive_ABS_3_1, FCAN.FData);}
  void set_ABS_AbsActive(const double value) { com.set_can_signal_value((TCANSignal* const)&ABS_AbsActive_ABS_3_1, FCAN.FData, value);}
  __declspec(property(get = get_ABS_AbsActive, put = set_ABS_AbsActive)) double ABS_AbsActive;
  double get_ABS_VehicleSpeed(void) { return com.get_can_signal_value((TCANSignal* const)&ABS_VehicleSpeed_ABS_3_1, FCAN.FData);}
  void set_ABS_VehicleSpeed(const double value) { com.set_can_signal_value((TCANSignal* const)&ABS_VehicleSpeed_ABS_3_1, FCAN.FData, value);}
  __declspec(property(get = get_ABS_VehicleSpeed, put = set_ABS_VehicleSpeed)) double ABS_VehicleSpeed;
  double get_ABS_EbdFault(void) { return com.get_can_signal_value((TCANSignal* const)&ABS_EbdFault_ABS_3_1, FCAN.FData);}
  void set_ABS_EbdFault(const double value) { com.set_can_signal_value((TCANSignal* const)&ABS_EbdFault_ABS_3_1, FCAN.FData, value);}
  __declspec(property(get = get_ABS_EbdFault, put = set_ABS_EbdFault)) double ABS_EbdFault;
  double get_ABS_EbdActive(void) { return com.get_can_signal_value((TCANSignal* const)&ABS_EbdActive_ABS_3_1, FCAN.FData);}
  void set_ABS_EbdActive(const double value) { com.set_can_signal_value((TCANSignal* const)&ABS_EbdActive_ABS_3_1, FCAN.FData, value);}
  __declspec(property(get = get_ABS_EbdActive, put = set_ABS_EbdActive)) double ABS_EbdActive;
  void init() { FCAN = create().FCAN; }
  TABS_3_1 create() { CANMsgDecl(_ABS_3_1, cABS_3_1, 0, 0, 8, 514) return cABS_3_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message EPB_1_1
extern const TCANSignal EPB_AutoHold_Standby_EPB_1_1;
extern const TCANSignal EPB_WarningLamp_EPB_1_1;
extern const TCANSignal EPB_ActiveLamp_EPB_1_1;
extern const TCANSignal EPB_TextDisplay_EPB_1_1;
extern const TCANSignal EPB_AutoholdActive_EPB_1_1;
extern const TCANSignal EPB_AutoholdValid_EPB_1_1;
extern const TCANSignal EPB_WrnMsg_EPB_1_1;
extern const TCANSignal EPB_WrnMsg2_EPB_1_1;
extern const TCANSignal EPB_TAB_SW_Status_EPB_1_1;
extern const TCANSignal EPB_TAB_Available_EPB_1_1;
extern const TCANSignal EPB_TAB_Sts_EPB_1_1;
struct _EPB_1_1;
typedef struct _EPB_1_1 TEPB_1_1;
struct _EPB_1_1{
  TCAN FCAN;
  double get_EPB_AutoHold_Standby(void) { return com.get_can_signal_value((TCANSignal* const)&EPB_AutoHold_Standby_EPB_1_1, FCAN.FData);}
  void set_EPB_AutoHold_Standby(const double value) { com.set_can_signal_value((TCANSignal* const)&EPB_AutoHold_Standby_EPB_1_1, FCAN.FData, value);}
  __declspec(property(get = get_EPB_AutoHold_Standby, put = set_EPB_AutoHold_Standby)) double EPB_AutoHold_Standby;
  double get_EPB_WarningLamp(void) { return com.get_can_signal_value((TCANSignal* const)&EPB_WarningLamp_EPB_1_1, FCAN.FData);}
  void set_EPB_WarningLamp(const double value) { com.set_can_signal_value((TCANSignal* const)&EPB_WarningLamp_EPB_1_1, FCAN.FData, value);}
  __declspec(property(get = get_EPB_WarningLamp, put = set_EPB_WarningLamp)) double EPB_WarningLamp;
  double get_EPB_ActiveLamp(void) { return com.get_can_signal_value((TCANSignal* const)&EPB_ActiveLamp_EPB_1_1, FCAN.FData);}
  void set_EPB_ActiveLamp(const double value) { com.set_can_signal_value((TCANSignal* const)&EPB_ActiveLamp_EPB_1_1, FCAN.FData, value);}
  __declspec(property(get = get_EPB_ActiveLamp, put = set_EPB_ActiveLamp)) double EPB_ActiveLamp;
  double get_EPB_TextDisplay(void) { return com.get_can_signal_value((TCANSignal* const)&EPB_TextDisplay_EPB_1_1, FCAN.FData);}
  void set_EPB_TextDisplay(const double value) { com.set_can_signal_value((TCANSignal* const)&EPB_TextDisplay_EPB_1_1, FCAN.FData, value);}
  __declspec(property(get = get_EPB_TextDisplay, put = set_EPB_TextDisplay)) double EPB_TextDisplay;
  double get_EPB_AutoholdActive(void) { return com.get_can_signal_value((TCANSignal* const)&EPB_AutoholdActive_EPB_1_1, FCAN.FData);}
  void set_EPB_AutoholdActive(const double value) { com.set_can_signal_value((TCANSignal* const)&EPB_AutoholdActive_EPB_1_1, FCAN.FData, value);}
  __declspec(property(get = get_EPB_AutoholdActive, put = set_EPB_AutoholdActive)) double EPB_AutoholdActive;
  double get_EPB_AutoholdValid(void) { return com.get_can_signal_value((TCANSignal* const)&EPB_AutoholdValid_EPB_1_1, FCAN.FData);}
  void set_EPB_AutoholdValid(const double value) { com.set_can_signal_value((TCANSignal* const)&EPB_AutoholdValid_EPB_1_1, FCAN.FData, value);}
  __declspec(property(get = get_EPB_AutoholdValid, put = set_EPB_AutoholdValid)) double EPB_AutoholdValid;
  double get_EPB_WrnMsg(void) { return com.get_can_signal_value((TCANSignal* const)&EPB_WrnMsg_EPB_1_1, FCAN.FData);}
  void set_EPB_WrnMsg(const double value) { com.set_can_signal_value((TCANSignal* const)&EPB_WrnMsg_EPB_1_1, FCAN.FData, value);}
  __declspec(property(get = get_EPB_WrnMsg, put = set_EPB_WrnMsg)) double EPB_WrnMsg;
  double get_EPB_WrnMsg2(void) { return com.get_can_signal_value((TCANSignal* const)&EPB_WrnMsg2_EPB_1_1, FCAN.FData);}
  void set_EPB_WrnMsg2(const double value) { com.set_can_signal_value((TCANSignal* const)&EPB_WrnMsg2_EPB_1_1, FCAN.FData, value);}
  __declspec(property(get = get_EPB_WrnMsg2, put = set_EPB_WrnMsg2)) double EPB_WrnMsg2;
  double get_EPB_TAB_SW_Status(void) { return com.get_can_signal_value((TCANSignal* const)&EPB_TAB_SW_Status_EPB_1_1, FCAN.FData);}
  void set_EPB_TAB_SW_Status(const double value) { com.set_can_signal_value((TCANSignal* const)&EPB_TAB_SW_Status_EPB_1_1, FCAN.FData, value);}
  __declspec(property(get = get_EPB_TAB_SW_Status, put = set_EPB_TAB_SW_Status)) double EPB_TAB_SW_Status;
  double get_EPB_TAB_Available(void) { return com.get_can_signal_value((TCANSignal* const)&EPB_TAB_Available_EPB_1_1, FCAN.FData);}
  void set_EPB_TAB_Available(const double value) { com.set_can_signal_value((TCANSignal* const)&EPB_TAB_Available_EPB_1_1, FCAN.FData, value);}
  __declspec(property(get = get_EPB_TAB_Available, put = set_EPB_TAB_Available)) double EPB_TAB_Available;
  double get_EPB_TAB_Sts(void) { return com.get_can_signal_value((TCANSignal* const)&EPB_TAB_Sts_EPB_1_1, FCAN.FData);}
  void set_EPB_TAB_Sts(const double value) { com.set_can_signal_value((TCANSignal* const)&EPB_TAB_Sts_EPB_1_1, FCAN.FData, value);}
  __declspec(property(get = get_EPB_TAB_Sts, put = set_EPB_TAB_Sts)) double EPB_TAB_Sts;
  void init() { FCAN = create().FCAN; }
  TEPB_1_1 create() { CANMsgDecl(_EPB_1_1, cEPB_1_1, 0, 0, 8, 533) return cEPB_1_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message ESP_5_1
extern const TCANSignal ESP_CCO_TgtGear_ESP_5_1;
extern const TCANSignal ESP_CCO_Active_ESP_5_1;
extern const TCANSignal ESP_CCO_Sts_ESP_5_1;
extern const TCANSignal ESP_CCO_Require_EPBRelease_ESP_5_1;
extern const TCANSignal ESP_CCO_Require_DriverSeatBelt_ESP_5_1;
extern const TCANSignal ESP_CCO_Require_DriverDoor_ESP_5_1;
extern const TCANSignal ESP_CCO_Require_4L_ESP_5_1;
extern const TCANSignal ESP_CCO_Display_Red_Warn_ESP_5_1;
extern const TCANSignal ESP_CCO_Faied_ESP_5_1;
extern const TCANSignal ESP_CCO_Require_NotReverseGear_ESP_5_1;
extern const TCANSignal ESP_CCO_Warning_ESP_5_1;
struct _ESP_5_1;
typedef struct _ESP_5_1 TESP_5_1;
struct _ESP_5_1{
  TCAN FCAN;
  double get_ESP_CCO_TgtGear(void) { return com.get_can_signal_value((TCANSignal* const)&ESP_CCO_TgtGear_ESP_5_1, FCAN.FData);}
  void set_ESP_CCO_TgtGear(const double value) { com.set_can_signal_value((TCANSignal* const)&ESP_CCO_TgtGear_ESP_5_1, FCAN.FData, value);}
  __declspec(property(get = get_ESP_CCO_TgtGear, put = set_ESP_CCO_TgtGear)) double ESP_CCO_TgtGear;
  double get_ESP_CCO_Active(void) { return com.get_can_signal_value((TCANSignal* const)&ESP_CCO_Active_ESP_5_1, FCAN.FData);}
  void set_ESP_CCO_Active(const double value) { com.set_can_signal_value((TCANSignal* const)&ESP_CCO_Active_ESP_5_1, FCAN.FData, value);}
  __declspec(property(get = get_ESP_CCO_Active, put = set_ESP_CCO_Active)) double ESP_CCO_Active;
  double get_ESP_CCO_Sts(void) { return com.get_can_signal_value((TCANSignal* const)&ESP_CCO_Sts_ESP_5_1, FCAN.FData);}
  void set_ESP_CCO_Sts(const double value) { com.set_can_signal_value((TCANSignal* const)&ESP_CCO_Sts_ESP_5_1, FCAN.FData, value);}
  __declspec(property(get = get_ESP_CCO_Sts, put = set_ESP_CCO_Sts)) double ESP_CCO_Sts;
  double get_ESP_CCO_Require_EPBRelease(void) { return com.get_can_signal_value((TCANSignal* const)&ESP_CCO_Require_EPBRelease_ESP_5_1, FCAN.FData);}
  void set_ESP_CCO_Require_EPBRelease(const double value) { com.set_can_signal_value((TCANSignal* const)&ESP_CCO_Require_EPBRelease_ESP_5_1, FCAN.FData, value);}
  __declspec(property(get = get_ESP_CCO_Require_EPBRelease, put = set_ESP_CCO_Require_EPBRelease)) double ESP_CCO_Require_EPBRelease;
  double get_ESP_CCO_Require_DriverSeatBelt(void) { return com.get_can_signal_value((TCANSignal* const)&ESP_CCO_Require_DriverSeatBelt_ESP_5_1, FCAN.FData);}
  void set_ESP_CCO_Require_DriverSeatBelt(const double value) { com.set_can_signal_value((TCANSignal* const)&ESP_CCO_Require_DriverSeatBelt_ESP_5_1, FCAN.FData, value);}
  __declspec(property(get = get_ESP_CCO_Require_DriverSeatBelt, put = set_ESP_CCO_Require_DriverSeatBelt)) double ESP_CCO_Require_DriverSeatBelt;
  double get_ESP_CCO_Require_DriverDoor(void) { return com.get_can_signal_value((TCANSignal* const)&ESP_CCO_Require_DriverDoor_ESP_5_1, FCAN.FData);}
  void set_ESP_CCO_Require_DriverDoor(const double value) { com.set_can_signal_value((TCANSignal* const)&ESP_CCO_Require_DriverDoor_ESP_5_1, FCAN.FData, value);}
  __declspec(property(get = get_ESP_CCO_Require_DriverDoor, put = set_ESP_CCO_Require_DriverDoor)) double ESP_CCO_Require_DriverDoor;
  double get_ESP_CCO_Require_4L(void) { return com.get_can_signal_value((TCANSignal* const)&ESP_CCO_Require_4L_ESP_5_1, FCAN.FData);}
  void set_ESP_CCO_Require_4L(const double value) { com.set_can_signal_value((TCANSignal* const)&ESP_CCO_Require_4L_ESP_5_1, FCAN.FData, value);}
  __declspec(property(get = get_ESP_CCO_Require_4L, put = set_ESP_CCO_Require_4L)) double ESP_CCO_Require_4L;
  double get_ESP_CCO_Display_Red_Warn(void) { return com.get_can_signal_value((TCANSignal* const)&ESP_CCO_Display_Red_Warn_ESP_5_1, FCAN.FData);}
  void set_ESP_CCO_Display_Red_Warn(const double value) { com.set_can_signal_value((TCANSignal* const)&ESP_CCO_Display_Red_Warn_ESP_5_1, FCAN.FData, value);}
  __declspec(property(get = get_ESP_CCO_Display_Red_Warn, put = set_ESP_CCO_Display_Red_Warn)) double ESP_CCO_Display_Red_Warn;
  double get_ESP_CCO_Faied(void) { return com.get_can_signal_value((TCANSignal* const)&ESP_CCO_Faied_ESP_5_1, FCAN.FData);}
  void set_ESP_CCO_Faied(const double value) { com.set_can_signal_value((TCANSignal* const)&ESP_CCO_Faied_ESP_5_1, FCAN.FData, value);}
  __declspec(property(get = get_ESP_CCO_Faied, put = set_ESP_CCO_Faied)) double ESP_CCO_Faied;
  double get_ESP_CCO_Require_NotReverseGear(void) { return com.get_can_signal_value((TCANSignal* const)&ESP_CCO_Require_NotReverseGear_ESP_5_1, FCAN.FData);}
  void set_ESP_CCO_Require_NotReverseGear(const double value) { com.set_can_signal_value((TCANSignal* const)&ESP_CCO_Require_NotReverseGear_ESP_5_1, FCAN.FData, value);}
  __declspec(property(get = get_ESP_CCO_Require_NotReverseGear, put = set_ESP_CCO_Require_NotReverseGear)) double ESP_CCO_Require_NotReverseGear;
  double get_ESP_CCO_Warning(void) { return com.get_can_signal_value((TCANSignal* const)&ESP_CCO_Warning_ESP_5_1, FCAN.FData);}
  void set_ESP_CCO_Warning(const double value) { com.set_can_signal_value((TCANSignal* const)&ESP_CCO_Warning_ESP_5_1, FCAN.FData, value);}
  __declspec(property(get = get_ESP_CCO_Warning, put = set_ESP_CCO_Warning)) double ESP_CCO_Warning;
  void init() { FCAN = create().FCAN; }
  TESP_5_1 create() { CANMsgDecl(_ESP_5_1, cESP_5_1, 0, 0, 8, 532) return cESP_5_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message ACU_1_1
extern const TCANSignal ACU_CrashOutputSts_ACU_1_1;
extern const TCANSignal ACU_AirbagWarningStatus_ACU_1_1;
extern const TCANSignal ACU_AirbagInhibitWarning_ACU_1_1;
struct _ACU_1_1;
typedef struct _ACU_1_1 TACU_1_1;
struct _ACU_1_1{
  TCAN FCAN;
  double get_ACU_CrashOutputSts(void) { return com.get_can_signal_value((TCANSignal* const)&ACU_CrashOutputSts_ACU_1_1, FCAN.FData);}
  void set_ACU_CrashOutputSts(const double value) { com.set_can_signal_value((TCANSignal* const)&ACU_CrashOutputSts_ACU_1_1, FCAN.FData, value);}
  __declspec(property(get = get_ACU_CrashOutputSts, put = set_ACU_CrashOutputSts)) double ACU_CrashOutputSts;
  double get_ACU_AirbagWarningStatus(void) { return com.get_can_signal_value((TCANSignal* const)&ACU_AirbagWarningStatus_ACU_1_1, FCAN.FData);}
  void set_ACU_AirbagWarningStatus(const double value) { com.set_can_signal_value((TCANSignal* const)&ACU_AirbagWarningStatus_ACU_1_1, FCAN.FData, value);}
  __declspec(property(get = get_ACU_AirbagWarningStatus, put = set_ACU_AirbagWarningStatus)) double ACU_AirbagWarningStatus;
  double get_ACU_AirbagInhibitWarning(void) { return com.get_can_signal_value((TCANSignal* const)&ACU_AirbagInhibitWarning_ACU_1_1, FCAN.FData);}
  void set_ACU_AirbagInhibitWarning(const double value) { com.set_can_signal_value((TCANSignal* const)&ACU_AirbagInhibitWarning_ACU_1_1, FCAN.FData, value);}
  __declspec(property(get = get_ACU_AirbagInhibitWarning, put = set_ACU_AirbagInhibitWarning)) double ACU_AirbagInhibitWarning;
  void init() { FCAN = create().FCAN; }
  TACU_1_1 create() { CANMsgDecl(_ACU_1_1, cACU_1_1, 0, 0, 8, 848) return cACU_1_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message BCM_1_1
extern const TCANSignal BCM_PowerMode_BCM_1_1;
extern const TCANSignal BCM_LowBeamSts_BCM_1_1;
extern const TCANSignal BCM_HighBeamSts_BCM_1_1;
extern const TCANSignal BCM_LeftTurnLightSts_BCM_1_1;
extern const TCANSignal BCM_RightTurnLightSts_BCM_1_1;
extern const TCANSignal BCM_PositionLightSts_BCM_1_1;
extern const TCANSignal BCM_EmergencyLightSts_BCM_1_1;
extern const TCANSignal BCM_RearFogLightSts_BCM_1_1;
extern const TCANSignal BCM_FrontFogLightSts_BCM_1_1;
extern const TCANSignal BCM_DaytimeRunningLightSts_BCM_1_1;
extern const TCANSignal BCM_FrontLeftDoorSts_BCM_1_1;
extern const TCANSignal BCM_FrontRightDoorSts_BCM_1_1;
extern const TCANSignal BCM_RearLeftDoorSts_BCM_1_1;
extern const TCANSignal BCM_RearRightDoorSts_BCM_1_1;
extern const TCANSignal BCM_TailGateOpenSts_BCM_1_1;
extern const TCANSignal BCM_ACRearFrostSts_BCM_1_1;
extern const TCANSignal BCM_ReverseGearInfo_BCM_1_1;
extern const TCANSignal BCM_BackMirrorFolderSts_BCM_1_1;
extern const TCANSignal BCM_HoodSts_BCM_1_1;
extern const TCANSignal BCM_FillerCapSts_BCM_1_1;
struct _BCM_1_1;
typedef struct _BCM_1_1 TBCM_1_1;
struct _BCM_1_1{
  TCAN FCAN;
  double get_BCM_PowerMode(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_PowerMode_BCM_1_1, FCAN.FData);}
  void set_BCM_PowerMode(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_PowerMode_BCM_1_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_PowerMode, put = set_BCM_PowerMode)) double BCM_PowerMode;
  double get_BCM_LowBeamSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_LowBeamSts_BCM_1_1, FCAN.FData);}
  void set_BCM_LowBeamSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_LowBeamSts_BCM_1_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_LowBeamSts, put = set_BCM_LowBeamSts)) double BCM_LowBeamSts;
  double get_BCM_HighBeamSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_HighBeamSts_BCM_1_1, FCAN.FData);}
  void set_BCM_HighBeamSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_HighBeamSts_BCM_1_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_HighBeamSts, put = set_BCM_HighBeamSts)) double BCM_HighBeamSts;
  double get_BCM_LeftTurnLightSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_LeftTurnLightSts_BCM_1_1, FCAN.FData);}
  void set_BCM_LeftTurnLightSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_LeftTurnLightSts_BCM_1_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_LeftTurnLightSts, put = set_BCM_LeftTurnLightSts)) double BCM_LeftTurnLightSts;
  double get_BCM_RightTurnLightSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_RightTurnLightSts_BCM_1_1, FCAN.FData);}
  void set_BCM_RightTurnLightSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_RightTurnLightSts_BCM_1_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_RightTurnLightSts, put = set_BCM_RightTurnLightSts)) double BCM_RightTurnLightSts;
  double get_BCM_PositionLightSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_PositionLightSts_BCM_1_1, FCAN.FData);}
  void set_BCM_PositionLightSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_PositionLightSts_BCM_1_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_PositionLightSts, put = set_BCM_PositionLightSts)) double BCM_PositionLightSts;
  double get_BCM_EmergencyLightSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_EmergencyLightSts_BCM_1_1, FCAN.FData);}
  void set_BCM_EmergencyLightSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_EmergencyLightSts_BCM_1_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_EmergencyLightSts, put = set_BCM_EmergencyLightSts)) double BCM_EmergencyLightSts;
  double get_BCM_RearFogLightSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_RearFogLightSts_BCM_1_1, FCAN.FData);}
  void set_BCM_RearFogLightSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_RearFogLightSts_BCM_1_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_RearFogLightSts, put = set_BCM_RearFogLightSts)) double BCM_RearFogLightSts;
  double get_BCM_FrontFogLightSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_FrontFogLightSts_BCM_1_1, FCAN.FData);}
  void set_BCM_FrontFogLightSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_FrontFogLightSts_BCM_1_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_FrontFogLightSts, put = set_BCM_FrontFogLightSts)) double BCM_FrontFogLightSts;
  double get_BCM_DaytimeRunningLightSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_DaytimeRunningLightSts_BCM_1_1, FCAN.FData);}
  void set_BCM_DaytimeRunningLightSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_DaytimeRunningLightSts_BCM_1_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_DaytimeRunningLightSts, put = set_BCM_DaytimeRunningLightSts)) double BCM_DaytimeRunningLightSts;
  double get_BCM_FrontLeftDoorSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_FrontLeftDoorSts_BCM_1_1, FCAN.FData);}
  void set_BCM_FrontLeftDoorSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_FrontLeftDoorSts_BCM_1_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_FrontLeftDoorSts, put = set_BCM_FrontLeftDoorSts)) double BCM_FrontLeftDoorSts;
  double get_BCM_FrontRightDoorSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_FrontRightDoorSts_BCM_1_1, FCAN.FData);}
  void set_BCM_FrontRightDoorSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_FrontRightDoorSts_BCM_1_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_FrontRightDoorSts, put = set_BCM_FrontRightDoorSts)) double BCM_FrontRightDoorSts;
  double get_BCM_RearLeftDoorSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_RearLeftDoorSts_BCM_1_1, FCAN.FData);}
  void set_BCM_RearLeftDoorSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_RearLeftDoorSts_BCM_1_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_RearLeftDoorSts, put = set_BCM_RearLeftDoorSts)) double BCM_RearLeftDoorSts;
  double get_BCM_RearRightDoorSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_RearRightDoorSts_BCM_1_1, FCAN.FData);}
  void set_BCM_RearRightDoorSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_RearRightDoorSts_BCM_1_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_RearRightDoorSts, put = set_BCM_RearRightDoorSts)) double BCM_RearRightDoorSts;
  double get_BCM_TailGateOpenSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_TailGateOpenSts_BCM_1_1, FCAN.FData);}
  void set_BCM_TailGateOpenSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_TailGateOpenSts_BCM_1_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_TailGateOpenSts, put = set_BCM_TailGateOpenSts)) double BCM_TailGateOpenSts;
  double get_BCM_ACRearFrostSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_ACRearFrostSts_BCM_1_1, FCAN.FData);}
  void set_BCM_ACRearFrostSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_ACRearFrostSts_BCM_1_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_ACRearFrostSts, put = set_BCM_ACRearFrostSts)) double BCM_ACRearFrostSts;
  double get_BCM_ReverseGearInfo(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_ReverseGearInfo_BCM_1_1, FCAN.FData);}
  void set_BCM_ReverseGearInfo(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_ReverseGearInfo_BCM_1_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_ReverseGearInfo, put = set_BCM_ReverseGearInfo)) double BCM_ReverseGearInfo;
  double get_BCM_BackMirrorFolderSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_BackMirrorFolderSts_BCM_1_1, FCAN.FData);}
  void set_BCM_BackMirrorFolderSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_BackMirrorFolderSts_BCM_1_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_BackMirrorFolderSts, put = set_BCM_BackMirrorFolderSts)) double BCM_BackMirrorFolderSts;
  double get_BCM_HoodSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_HoodSts_BCM_1_1, FCAN.FData);}
  void set_BCM_HoodSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_HoodSts_BCM_1_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_HoodSts, put = set_BCM_HoodSts)) double BCM_HoodSts;
  double get_BCM_FillerCapSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_FillerCapSts_BCM_1_1, FCAN.FData);}
  void set_BCM_FillerCapSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_FillerCapSts_BCM_1_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_FillerCapSts, put = set_BCM_FillerCapSts)) double BCM_FillerCapSts;
  void init() { FCAN = create().FCAN; }
  TBCM_1_1 create() { CANMsgDecl(_BCM_1_1, cBCM_1_1, 0, 0, 8, 864) return cBCM_1_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message BCM_2_1
extern const TCANSignal BCM_WindowRunningStatusFL_BCM_2_1;
extern const TCANSignal BCM_WindowRunningStatusFR_BCM_2_1;
extern const TCANSignal BCM_WindowRunningStatusRL_BCM_2_1;
extern const TCANSignal BCM_WindowRunningStatusRR_BCM_2_1;
extern const TCANSignal BCM_WindowPosFL_BCM_2_1;
extern const TCANSignal BCM_WindowPosFR_BCM_2_1;
extern const TCANSignal BCM_WindowPosRL_BCM_2_1;
extern const TCANSignal BCM_WindowPosRR_BCM_2_1;
struct _BCM_2_1;
typedef struct _BCM_2_1 TBCM_2_1;
struct _BCM_2_1{
  TCAN FCAN;
  double get_BCM_WindowRunningStatusFL(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_WindowRunningStatusFL_BCM_2_1, FCAN.FData);}
  void set_BCM_WindowRunningStatusFL(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_WindowRunningStatusFL_BCM_2_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_WindowRunningStatusFL, put = set_BCM_WindowRunningStatusFL)) double BCM_WindowRunningStatusFL;
  double get_BCM_WindowRunningStatusFR(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_WindowRunningStatusFR_BCM_2_1, FCAN.FData);}
  void set_BCM_WindowRunningStatusFR(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_WindowRunningStatusFR_BCM_2_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_WindowRunningStatusFR, put = set_BCM_WindowRunningStatusFR)) double BCM_WindowRunningStatusFR;
  double get_BCM_WindowRunningStatusRL(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_WindowRunningStatusRL_BCM_2_1, FCAN.FData);}
  void set_BCM_WindowRunningStatusRL(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_WindowRunningStatusRL_BCM_2_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_WindowRunningStatusRL, put = set_BCM_WindowRunningStatusRL)) double BCM_WindowRunningStatusRL;
  double get_BCM_WindowRunningStatusRR(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_WindowRunningStatusRR_BCM_2_1, FCAN.FData);}
  void set_BCM_WindowRunningStatusRR(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_WindowRunningStatusRR_BCM_2_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_WindowRunningStatusRR, put = set_BCM_WindowRunningStatusRR)) double BCM_WindowRunningStatusRR;
  double get_BCM_WindowPosFL(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_WindowPosFL_BCM_2_1, FCAN.FData);}
  void set_BCM_WindowPosFL(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_WindowPosFL_BCM_2_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_WindowPosFL, put = set_BCM_WindowPosFL)) double BCM_WindowPosFL;
  double get_BCM_WindowPosFR(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_WindowPosFR_BCM_2_1, FCAN.FData);}
  void set_BCM_WindowPosFR(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_WindowPosFR_BCM_2_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_WindowPosFR, put = set_BCM_WindowPosFR)) double BCM_WindowPosFR;
  double get_BCM_WindowPosRL(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_WindowPosRL_BCM_2_1, FCAN.FData);}
  void set_BCM_WindowPosRL(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_WindowPosRL_BCM_2_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_WindowPosRL, put = set_BCM_WindowPosRL)) double BCM_WindowPosRL;
  double get_BCM_WindowPosRR(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_WindowPosRR_BCM_2_1, FCAN.FData);}
  void set_BCM_WindowPosRR(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_WindowPosRR_BCM_2_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_WindowPosRR, put = set_BCM_WindowPosRR)) double BCM_WindowPosRR;
  void init() { FCAN = create().FCAN; }
  TBCM_2_1 create() { CANMsgDecl(_BCM_2_1, cBCM_2_1, 0, 0, 8, 865) return cBCM_2_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message BCM_4_1
extern const TCANSignal BCM_FollowMeHomeTimeSetSts_BCM_4_1;
extern const TCANSignal BCM_LeaveHomeTimeSetSts_BCM_4_1;
extern const TCANSignal BCM_WindowRemoteAutoDownSetSts_BCM_4_1;
extern const TCANSignal BCM_AssistIlluminationSetSts_BCM_4_1;
extern const TCANSignal BCM_InteriorLightTimeSetSts_BCM_4_1;
extern const TCANSignal BCM_SpeedLockSetSts_BCM_4_1;
extern const TCANSignal BCM_exRearMirrorAutoFoldSetSts_BCM_4_1;
extern const TCANSignal BCM_HornAlertVolumeSetSts_BCM_4_1;
extern const TCANSignal BCM_WindowAutoUPbyLockSetSts_BCM_4_1;
extern const TCANSignal BCM_SearchCarWarnModSetSts_BCM_4_1;
extern const TCANSignal BCM_AutoWshWipSetSts_BCM_4_1;
extern const TCANSignal BCM_FlaoutUnlockSetSts_BCM_4_1;
extern const TCANSignal BCM_ClsWinSpdSetSts_BCM_4_1;
extern const TCANSignal BCM_AmbientLightSwtSts_BCM_4_1;
extern const TCANSignal BCM_AmbientLightLvl_BCM_4_1;
extern const TCANSignal BCM_FrontwindshieldheatingSts_BCM_4_1;
extern const TCANSignal BCM_NozzleheatingSts_BCM_4_1;
extern const TCANSignal BCM_SteeringwheelheatingSts_BCM_4_1;
extern const TCANSignal BCM_AAL_ONOFFSts_BCM_4_1;
extern const TCANSignal BCM_AAL_PitchAngle_BCM_4_1;
extern const TCANSignal BCM_AAL_YawAngle_BCM_4_1;
struct _BCM_4_1;
typedef struct _BCM_4_1 TBCM_4_1;
struct _BCM_4_1{
  TCAN FCAN;
  double get_BCM_FollowMeHomeTimeSetSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_FollowMeHomeTimeSetSts_BCM_4_1, FCAN.FData);}
  void set_BCM_FollowMeHomeTimeSetSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_FollowMeHomeTimeSetSts_BCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_FollowMeHomeTimeSetSts, put = set_BCM_FollowMeHomeTimeSetSts)) double BCM_FollowMeHomeTimeSetSts;
  double get_BCM_LeaveHomeTimeSetSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_LeaveHomeTimeSetSts_BCM_4_1, FCAN.FData);}
  void set_BCM_LeaveHomeTimeSetSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_LeaveHomeTimeSetSts_BCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_LeaveHomeTimeSetSts, put = set_BCM_LeaveHomeTimeSetSts)) double BCM_LeaveHomeTimeSetSts;
  double get_BCM_WindowRemoteAutoDownSetSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_WindowRemoteAutoDownSetSts_BCM_4_1, FCAN.FData);}
  void set_BCM_WindowRemoteAutoDownSetSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_WindowRemoteAutoDownSetSts_BCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_WindowRemoteAutoDownSetSts, put = set_BCM_WindowRemoteAutoDownSetSts)) double BCM_WindowRemoteAutoDownSetSts;
  double get_BCM_AssistIlluminationSetSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_AssistIlluminationSetSts_BCM_4_1, FCAN.FData);}
  void set_BCM_AssistIlluminationSetSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_AssistIlluminationSetSts_BCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_AssistIlluminationSetSts, put = set_BCM_AssistIlluminationSetSts)) double BCM_AssistIlluminationSetSts;
  double get_BCM_InteriorLightTimeSetSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_InteriorLightTimeSetSts_BCM_4_1, FCAN.FData);}
  void set_BCM_InteriorLightTimeSetSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_InteriorLightTimeSetSts_BCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_InteriorLightTimeSetSts, put = set_BCM_InteriorLightTimeSetSts)) double BCM_InteriorLightTimeSetSts;
  double get_BCM_SpeedLockSetSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_SpeedLockSetSts_BCM_4_1, FCAN.FData);}
  void set_BCM_SpeedLockSetSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_SpeedLockSetSts_BCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_SpeedLockSetSts, put = set_BCM_SpeedLockSetSts)) double BCM_SpeedLockSetSts;
  double get_BCM_exRearMirrorAutoFoldSetSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_exRearMirrorAutoFoldSetSts_BCM_4_1, FCAN.FData);}
  void set_BCM_exRearMirrorAutoFoldSetSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_exRearMirrorAutoFoldSetSts_BCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_exRearMirrorAutoFoldSetSts, put = set_BCM_exRearMirrorAutoFoldSetSts)) double BCM_exRearMirrorAutoFoldSetSts;
  double get_BCM_HornAlertVolumeSetSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_HornAlertVolumeSetSts_BCM_4_1, FCAN.FData);}
  void set_BCM_HornAlertVolumeSetSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_HornAlertVolumeSetSts_BCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_HornAlertVolumeSetSts, put = set_BCM_HornAlertVolumeSetSts)) double BCM_HornAlertVolumeSetSts;
  double get_BCM_WindowAutoUPbyLockSetSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_WindowAutoUPbyLockSetSts_BCM_4_1, FCAN.FData);}
  void set_BCM_WindowAutoUPbyLockSetSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_WindowAutoUPbyLockSetSts_BCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_WindowAutoUPbyLockSetSts, put = set_BCM_WindowAutoUPbyLockSetSts)) double BCM_WindowAutoUPbyLockSetSts;
  double get_BCM_SearchCarWarnModSetSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_SearchCarWarnModSetSts_BCM_4_1, FCAN.FData);}
  void set_BCM_SearchCarWarnModSetSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_SearchCarWarnModSetSts_BCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_SearchCarWarnModSetSts, put = set_BCM_SearchCarWarnModSetSts)) double BCM_SearchCarWarnModSetSts;
  double get_BCM_AutoWshWipSetSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_AutoWshWipSetSts_BCM_4_1, FCAN.FData);}
  void set_BCM_AutoWshWipSetSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_AutoWshWipSetSts_BCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_AutoWshWipSetSts, put = set_BCM_AutoWshWipSetSts)) double BCM_AutoWshWipSetSts;
  double get_BCM_FlaoutUnlockSetSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_FlaoutUnlockSetSts_BCM_4_1, FCAN.FData);}
  void set_BCM_FlaoutUnlockSetSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_FlaoutUnlockSetSts_BCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_FlaoutUnlockSetSts, put = set_BCM_FlaoutUnlockSetSts)) double BCM_FlaoutUnlockSetSts;
  double get_BCM_ClsWinSpdSetSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_ClsWinSpdSetSts_BCM_4_1, FCAN.FData);}
  void set_BCM_ClsWinSpdSetSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_ClsWinSpdSetSts_BCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_ClsWinSpdSetSts, put = set_BCM_ClsWinSpdSetSts)) double BCM_ClsWinSpdSetSts;
  double get_BCM_AmbientLightSwtSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_AmbientLightSwtSts_BCM_4_1, FCAN.FData);}
  void set_BCM_AmbientLightSwtSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_AmbientLightSwtSts_BCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_AmbientLightSwtSts, put = set_BCM_AmbientLightSwtSts)) double BCM_AmbientLightSwtSts;
  double get_BCM_AmbientLightLvl(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_AmbientLightLvl_BCM_4_1, FCAN.FData);}
  void set_BCM_AmbientLightLvl(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_AmbientLightLvl_BCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_AmbientLightLvl, put = set_BCM_AmbientLightLvl)) double BCM_AmbientLightLvl;
  double get_BCM_FrontwindshieldheatingSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_FrontwindshieldheatingSts_BCM_4_1, FCAN.FData);}
  void set_BCM_FrontwindshieldheatingSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_FrontwindshieldheatingSts_BCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_FrontwindshieldheatingSts, put = set_BCM_FrontwindshieldheatingSts)) double BCM_FrontwindshieldheatingSts;
  double get_BCM_NozzleheatingSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_NozzleheatingSts_BCM_4_1, FCAN.FData);}
  void set_BCM_NozzleheatingSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_NozzleheatingSts_BCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_NozzleheatingSts, put = set_BCM_NozzleheatingSts)) double BCM_NozzleheatingSts;
  double get_BCM_SteeringwheelheatingSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_SteeringwheelheatingSts_BCM_4_1, FCAN.FData);}
  void set_BCM_SteeringwheelheatingSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_SteeringwheelheatingSts_BCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_SteeringwheelheatingSts, put = set_BCM_SteeringwheelheatingSts)) double BCM_SteeringwheelheatingSts;
  double get_BCM_AAL_ONOFFSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_AAL_ONOFFSts_BCM_4_1, FCAN.FData);}
  void set_BCM_AAL_ONOFFSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_AAL_ONOFFSts_BCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_AAL_ONOFFSts, put = set_BCM_AAL_ONOFFSts)) double BCM_AAL_ONOFFSts;
  double get_BCM_AAL_PitchAngle(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_AAL_PitchAngle_BCM_4_1, FCAN.FData);}
  void set_BCM_AAL_PitchAngle(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_AAL_PitchAngle_BCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_AAL_PitchAngle, put = set_BCM_AAL_PitchAngle)) double BCM_AAL_PitchAngle;
  double get_BCM_AAL_YawAngle(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_AAL_YawAngle_BCM_4_1, FCAN.FData);}
  void set_BCM_AAL_YawAngle(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_AAL_YawAngle_BCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_AAL_YawAngle, put = set_BCM_AAL_YawAngle)) double BCM_AAL_YawAngle;
  void init() { FCAN = create().FCAN; }
  TBCM_4_1 create() { CANMsgDecl(_BCM_4_1, cBCM_4_1, 0, 0, 8, 866) return cBCM_4_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message BCM_5_1
extern const TCANSignal BCM_SRF_PosStatus_BCM_5_1;
extern const TCANSignal BCM_SRF_InitializeStatus_BCM_5_1;
extern const TCANSignal BCM_SRF_SW_Fault_BCM_5_1;
extern const TCANSignal BCM_SRF_Motor_Circuit_Fault_BCM_5_1;
extern const TCANSignal BCM_SRF_ECU_Fault_BCM_5_1;
extern const TCANSignal BCM_SRF_Alarm_BCM_5_1;
extern const TCANSignal BCM_RLS_Fault_Rain_BCM_5_1;
extern const TCANSignal BCM_RLS_Fault_Light_BCM_5_1;
extern const TCANSignal BCM_RLS_REP_Error_BCM_5_1;
extern const TCANSignal BCM_RLS_VOLT_Error_BCM_5_1;
struct _BCM_5_1;
typedef struct _BCM_5_1 TBCM_5_1;
struct _BCM_5_1{
  TCAN FCAN;
  double get_BCM_SRF_PosStatus(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_SRF_PosStatus_BCM_5_1, FCAN.FData);}
  void set_BCM_SRF_PosStatus(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_SRF_PosStatus_BCM_5_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_SRF_PosStatus, put = set_BCM_SRF_PosStatus)) double BCM_SRF_PosStatus;
  double get_BCM_SRF_InitializeStatus(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_SRF_InitializeStatus_BCM_5_1, FCAN.FData);}
  void set_BCM_SRF_InitializeStatus(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_SRF_InitializeStatus_BCM_5_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_SRF_InitializeStatus, put = set_BCM_SRF_InitializeStatus)) double BCM_SRF_InitializeStatus;
  double get_BCM_SRF_SW_Fault(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_SRF_SW_Fault_BCM_5_1, FCAN.FData);}
  void set_BCM_SRF_SW_Fault(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_SRF_SW_Fault_BCM_5_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_SRF_SW_Fault, put = set_BCM_SRF_SW_Fault)) double BCM_SRF_SW_Fault;
  double get_BCM_SRF_Motor_Circuit_Fault(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_SRF_Motor_Circuit_Fault_BCM_5_1, FCAN.FData);}
  void set_BCM_SRF_Motor_Circuit_Fault(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_SRF_Motor_Circuit_Fault_BCM_5_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_SRF_Motor_Circuit_Fault, put = set_BCM_SRF_Motor_Circuit_Fault)) double BCM_SRF_Motor_Circuit_Fault;
  double get_BCM_SRF_ECU_Fault(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_SRF_ECU_Fault_BCM_5_1, FCAN.FData);}
  void set_BCM_SRF_ECU_Fault(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_SRF_ECU_Fault_BCM_5_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_SRF_ECU_Fault, put = set_BCM_SRF_ECU_Fault)) double BCM_SRF_ECU_Fault;
  double get_BCM_SRF_Alarm(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_SRF_Alarm_BCM_5_1, FCAN.FData);}
  void set_BCM_SRF_Alarm(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_SRF_Alarm_BCM_5_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_SRF_Alarm, put = set_BCM_SRF_Alarm)) double BCM_SRF_Alarm;
  double get_BCM_RLS_Fault_Rain(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_RLS_Fault_Rain_BCM_5_1, FCAN.FData);}
  void set_BCM_RLS_Fault_Rain(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_RLS_Fault_Rain_BCM_5_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_RLS_Fault_Rain, put = set_BCM_RLS_Fault_Rain)) double BCM_RLS_Fault_Rain;
  double get_BCM_RLS_Fault_Light(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_RLS_Fault_Light_BCM_5_1, FCAN.FData);}
  void set_BCM_RLS_Fault_Light(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_RLS_Fault_Light_BCM_5_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_RLS_Fault_Light, put = set_BCM_RLS_Fault_Light)) double BCM_RLS_Fault_Light;
  double get_BCM_RLS_REP_Error(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_RLS_REP_Error_BCM_5_1, FCAN.FData);}
  void set_BCM_RLS_REP_Error(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_RLS_REP_Error_BCM_5_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_RLS_REP_Error, put = set_BCM_RLS_REP_Error)) double BCM_RLS_REP_Error;
  double get_BCM_RLS_VOLT_Error(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_RLS_VOLT_Error_BCM_5_1, FCAN.FData);}
  void set_BCM_RLS_VOLT_Error(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_RLS_VOLT_Error_BCM_5_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_RLS_VOLT_Error, put = set_BCM_RLS_VOLT_Error)) double BCM_RLS_VOLT_Error;
  void init() { FCAN = create().FCAN; }
  TBCM_5_1 create() { CANMsgDecl(_BCM_5_1, cBCM_5_1, 0, 0, 8, 786) return cBCM_5_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message CPS_1_1
extern const TCANSignal CPS_DriveModeIntfaceSw_CPS_1_1;
extern const TCANSignal CPS_CustomSw1_CPS_1_1;
extern const TCANSignal CPS_CustomSw2_CPS_1_1;
struct _CPS_1_1;
typedef struct _CPS_1_1 TCPS_1_1;
struct _CPS_1_1{
  TCAN FCAN;
  double get_CPS_DriveModeIntfaceSw(void) { return com.get_can_signal_value((TCANSignal* const)&CPS_DriveModeIntfaceSw_CPS_1_1, FCAN.FData);}
  void set_CPS_DriveModeIntfaceSw(const double value) { com.set_can_signal_value((TCANSignal* const)&CPS_DriveModeIntfaceSw_CPS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_CPS_DriveModeIntfaceSw, put = set_CPS_DriveModeIntfaceSw)) double CPS_DriveModeIntfaceSw;
  double get_CPS_CustomSw1(void) { return com.get_can_signal_value((TCANSignal* const)&CPS_CustomSw1_CPS_1_1, FCAN.FData);}
  void set_CPS_CustomSw1(const double value) { com.set_can_signal_value((TCANSignal* const)&CPS_CustomSw1_CPS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_CPS_CustomSw1, put = set_CPS_CustomSw1)) double CPS_CustomSw1;
  double get_CPS_CustomSw2(void) { return com.get_can_signal_value((TCANSignal* const)&CPS_CustomSw2_CPS_1_1, FCAN.FData);}
  void set_CPS_CustomSw2(const double value) { com.set_can_signal_value((TCANSignal* const)&CPS_CustomSw2_CPS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_CPS_CustomSw2, put = set_CPS_CustomSw2)) double CPS_CustomSw2;
  void init() { FCAN = create().FCAN; }
  TCPS_1_1 create() { CANMsgDecl(_CPS_1_1, cCPS_1_1, 0, 0, 8, 790) return cCPS_1_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message WCM_1_1
extern const TCANSignal WCM_ChargingSts_WCM_1_1;
extern const TCANSignal WCM_FailureSts_WCM_1_1;
extern const TCANSignal WCM_WirelessChargeSwtSts_WCM_1_1;
extern const TCANSignal WCM_PhoneReminder_WCM_1_1;
struct _WCM_1_1;
typedef struct _WCM_1_1 TWCM_1_1;
struct _WCM_1_1{
  TCAN FCAN;
  double get_WCM_ChargingSts(void) { return com.get_can_signal_value((TCANSignal* const)&WCM_ChargingSts_WCM_1_1, FCAN.FData);}
  void set_WCM_ChargingSts(const double value) { com.set_can_signal_value((TCANSignal* const)&WCM_ChargingSts_WCM_1_1, FCAN.FData, value);}
  __declspec(property(get = get_WCM_ChargingSts, put = set_WCM_ChargingSts)) double WCM_ChargingSts;
  double get_WCM_FailureSts(void) { return com.get_can_signal_value((TCANSignal* const)&WCM_FailureSts_WCM_1_1, FCAN.FData);}
  void set_WCM_FailureSts(const double value) { com.set_can_signal_value((TCANSignal* const)&WCM_FailureSts_WCM_1_1, FCAN.FData, value);}
  __declspec(property(get = get_WCM_FailureSts, put = set_WCM_FailureSts)) double WCM_FailureSts;
  double get_WCM_WirelessChargeSwtSts(void) { return com.get_can_signal_value((TCANSignal* const)&WCM_WirelessChargeSwtSts_WCM_1_1, FCAN.FData);}
  void set_WCM_WirelessChargeSwtSts(const double value) { com.set_can_signal_value((TCANSignal* const)&WCM_WirelessChargeSwtSts_WCM_1_1, FCAN.FData, value);}
  __declspec(property(get = get_WCM_WirelessChargeSwtSts, put = set_WCM_WirelessChargeSwtSts)) double WCM_WirelessChargeSwtSts;
  double get_WCM_PhoneReminder(void) { return com.get_can_signal_value((TCANSignal* const)&WCM_PhoneReminder_WCM_1_1, FCAN.FData);}
  void set_WCM_PhoneReminder(const double value) { com.set_can_signal_value((TCANSignal* const)&WCM_PhoneReminder_WCM_1_1, FCAN.FData, value);}
  __declspec(property(get = get_WCM_PhoneReminder, put = set_WCM_PhoneReminder)) double WCM_PhoneReminder;
  void init() { FCAN = create().FCAN; }
  TWCM_1_1 create() { CANMsgDecl(_WCM_1_1, cWCM_1_1, 0, 0, 8, 875) return cWCM_1_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message TPMS_1_1
extern const TCANSignal TPMS_SystemStatus_TPMS_1_1;
extern const TCANSignal TPMS_TireID_TPMS_1_1;
extern const TCANSignal TPMS_SensorLost_TPMS_1_1;
extern const TCANSignal TPMS_TireLeakage_TPMS_1_1;
extern const TCANSignal TPMS_LearningStatus_TPMS_1_1;
extern const TCANSignal TPMS_TirePressureStatus_TPMS_1_1;
extern const TCANSignal TPMS_TireTemperatureSts_TPMS_1_1;
extern const TCANSignal TPMS_TireBatteryPowerSts_TPMS_1_1;
extern const TCANSignal TPMS_TirePressure_TPMS_1_1;
extern const TCANSignal TPMS_TireTemperature_TPMS_1_1;
extern const TCANSignal TPMS_TireBatteryPower_TPMS_1_1;
struct _TPMS_1_1;
typedef struct _TPMS_1_1 TTPMS_1_1;
struct _TPMS_1_1{
  TCAN FCAN;
  double get_TPMS_SystemStatus(void) { return com.get_can_signal_value((TCANSignal* const)&TPMS_SystemStatus_TPMS_1_1, FCAN.FData);}
  void set_TPMS_SystemStatus(const double value) { com.set_can_signal_value((TCANSignal* const)&TPMS_SystemStatus_TPMS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TPMS_SystemStatus, put = set_TPMS_SystemStatus)) double TPMS_SystemStatus;
  double get_TPMS_TireID(void) { return com.get_can_signal_value((TCANSignal* const)&TPMS_TireID_TPMS_1_1, FCAN.FData);}
  void set_TPMS_TireID(const double value) { com.set_can_signal_value((TCANSignal* const)&TPMS_TireID_TPMS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TPMS_TireID, put = set_TPMS_TireID)) double TPMS_TireID;
  double get_TPMS_SensorLost(void) { return com.get_can_signal_value((TCANSignal* const)&TPMS_SensorLost_TPMS_1_1, FCAN.FData);}
  void set_TPMS_SensorLost(const double value) { com.set_can_signal_value((TCANSignal* const)&TPMS_SensorLost_TPMS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TPMS_SensorLost, put = set_TPMS_SensorLost)) double TPMS_SensorLost;
  double get_TPMS_TireLeakage(void) { return com.get_can_signal_value((TCANSignal* const)&TPMS_TireLeakage_TPMS_1_1, FCAN.FData);}
  void set_TPMS_TireLeakage(const double value) { com.set_can_signal_value((TCANSignal* const)&TPMS_TireLeakage_TPMS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TPMS_TireLeakage, put = set_TPMS_TireLeakage)) double TPMS_TireLeakage;
  double get_TPMS_LearningStatus(void) { return com.get_can_signal_value((TCANSignal* const)&TPMS_LearningStatus_TPMS_1_1, FCAN.FData);}
  void set_TPMS_LearningStatus(const double value) { com.set_can_signal_value((TCANSignal* const)&TPMS_LearningStatus_TPMS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TPMS_LearningStatus, put = set_TPMS_LearningStatus)) double TPMS_LearningStatus;
  double get_TPMS_TirePressureStatus(void) { return com.get_can_signal_value((TCANSignal* const)&TPMS_TirePressureStatus_TPMS_1_1, FCAN.FData);}
  void set_TPMS_TirePressureStatus(const double value) { com.set_can_signal_value((TCANSignal* const)&TPMS_TirePressureStatus_TPMS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TPMS_TirePressureStatus, put = set_TPMS_TirePressureStatus)) double TPMS_TirePressureStatus;
  double get_TPMS_TireTemperatureSts(void) { return com.get_can_signal_value((TCANSignal* const)&TPMS_TireTemperatureSts_TPMS_1_1, FCAN.FData);}
  void set_TPMS_TireTemperatureSts(const double value) { com.set_can_signal_value((TCANSignal* const)&TPMS_TireTemperatureSts_TPMS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TPMS_TireTemperatureSts, put = set_TPMS_TireTemperatureSts)) double TPMS_TireTemperatureSts;
  double get_TPMS_TireBatteryPowerSts(void) { return com.get_can_signal_value((TCANSignal* const)&TPMS_TireBatteryPowerSts_TPMS_1_1, FCAN.FData);}
  void set_TPMS_TireBatteryPowerSts(const double value) { com.set_can_signal_value((TCANSignal* const)&TPMS_TireBatteryPowerSts_TPMS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TPMS_TireBatteryPowerSts, put = set_TPMS_TireBatteryPowerSts)) double TPMS_TireBatteryPowerSts;
  double get_TPMS_TirePressure(void) { return com.get_can_signal_value((TCANSignal* const)&TPMS_TirePressure_TPMS_1_1, FCAN.FData);}
  void set_TPMS_TirePressure(const double value) { com.set_can_signal_value((TCANSignal* const)&TPMS_TirePressure_TPMS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TPMS_TirePressure, put = set_TPMS_TirePressure)) double TPMS_TirePressure;
  double get_TPMS_TireTemperature(void) { return com.get_can_signal_value((TCANSignal* const)&TPMS_TireTemperature_TPMS_1_1, FCAN.FData);}
  void set_TPMS_TireTemperature(const double value) { com.set_can_signal_value((TCANSignal* const)&TPMS_TireTemperature_TPMS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TPMS_TireTemperature, put = set_TPMS_TireTemperature)) double TPMS_TireTemperature;
  double get_TPMS_TireBatteryPower(void) { return com.get_can_signal_value((TCANSignal* const)&TPMS_TireBatteryPower_TPMS_1_1, FCAN.FData);}
  void set_TPMS_TireBatteryPower(const double value) { com.set_can_signal_value((TCANSignal* const)&TPMS_TireBatteryPower_TPMS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TPMS_TireBatteryPower, put = set_TPMS_TireBatteryPower)) double TPMS_TireBatteryPower;
  void init() { FCAN = create().FCAN; }
  TTPMS_1_1 create() { CANMsgDecl(_TPMS_1_1, cTPMS_1_1, 0, 0, 8, 869) return cTPMS_1_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message TCM_1_1
extern const TCANSignal TCM_LeftTurnLightSWSts_TCM_1_1;
extern const TCANSignal TCM_LeftTurnLightSWStsValid_TCM_1_1;
extern const TCANSignal TCM_RightTurnLightSWSts_TCM_1_1;
extern const TCANSignal TCM_RightTurnLightSWStsValid_TCM_1_1;
struct _TCM_1_1;
typedef struct _TCM_1_1 TTCM_1_1;
struct _TCM_1_1{
  TCAN FCAN;
  double get_TCM_LeftTurnLightSWSts(void) { return com.get_can_signal_value((TCANSignal* const)&TCM_LeftTurnLightSWSts_TCM_1_1, FCAN.FData);}
  void set_TCM_LeftTurnLightSWSts(const double value) { com.set_can_signal_value((TCANSignal* const)&TCM_LeftTurnLightSWSts_TCM_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TCM_LeftTurnLightSWSts, put = set_TCM_LeftTurnLightSWSts)) double TCM_LeftTurnLightSWSts;
  double get_TCM_LeftTurnLightSWStsValid(void) { return com.get_can_signal_value((TCANSignal* const)&TCM_LeftTurnLightSWStsValid_TCM_1_1, FCAN.FData);}
  void set_TCM_LeftTurnLightSWStsValid(const double value) { com.set_can_signal_value((TCANSignal* const)&TCM_LeftTurnLightSWStsValid_TCM_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TCM_LeftTurnLightSWStsValid, put = set_TCM_LeftTurnLightSWStsValid)) double TCM_LeftTurnLightSWStsValid;
  double get_TCM_RightTurnLightSWSts(void) { return com.get_can_signal_value((TCANSignal* const)&TCM_RightTurnLightSWSts_TCM_1_1, FCAN.FData);}
  void set_TCM_RightTurnLightSWSts(const double value) { com.set_can_signal_value((TCANSignal* const)&TCM_RightTurnLightSWSts_TCM_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TCM_RightTurnLightSWSts, put = set_TCM_RightTurnLightSWSts)) double TCM_RightTurnLightSWSts;
  double get_TCM_RightTurnLightSWStsValid(void) { return com.get_can_signal_value((TCANSignal* const)&TCM_RightTurnLightSWStsValid_TCM_1_1, FCAN.FData);}
  void set_TCM_RightTurnLightSWStsValid(const double value) { com.set_can_signal_value((TCANSignal* const)&TCM_RightTurnLightSWStsValid_TCM_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TCM_RightTurnLightSWStsValid, put = set_TCM_RightTurnLightSWStsValid)) double TCM_RightTurnLightSWStsValid;
  void init() { FCAN = create().FCAN; }
  TTCM_1_1 create() { CANMsgDecl(_TCM_1_1, cTCM_1_1, 0, 0, 8, 871) return cTCM_1_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message PEPS_1_1
extern const TCANSignal PEPS_PowerRelayOutputFail_PEPS_1_1;
extern const TCANSignal PEPS_PIN_LearningStatus_PEPS_1_1;
extern const TCANSignal PEPS_SSB_FailStatus_PEPS_1_1;
extern const TCANSignal PEPS_ESCL_FailStatus_PEPS_1_1;
extern const TCANSignal PEPS_FailStatus_PEPS_1_1;
extern const TCANSignal PEPS_ESCL_NotUnlockWarning_PEPS_1_1;
extern const TCANSignal PEPS_ESCL_NotLockWarning_PEPS_1_1;
extern const TCANSignal PEPS_NotPNWarning_PEPS_1_1;
extern const TCANSignal PEPS_BrakeIndicationWarning_PEPS_1_1;
extern const TCANSignal PEPS_ClutchIndicationWarning_PEPS_1_1;
extern const TCANSignal PEPS_KeyReminderWarning_PEPS_1_1;
extern const TCANSignal PEPS_NoKeyFoundWarning_PEPS_1_1;
extern const TCANSignal PEPS_KeyOutWarning1_PEPS_1_1;
extern const TCANSignal PEPS_KeyBatteryWarning_PEPS_1_1;
extern const TCANSignal PEPS_KeyIntWarning1_PEPS_1_1;
extern const TCANSignal PEPS_LockNotOFFWarning_PEPS_1_1;
extern const TCANSignal PEPS_GearShiftAuthRequest_PEPS_1_1;
struct _PEPS_1_1;
typedef struct _PEPS_1_1 TPEPS_1_1;
struct _PEPS_1_1{
  TCAN FCAN;
  double get_PEPS_PowerRelayOutputFail(void) { return com.get_can_signal_value((TCANSignal* const)&PEPS_PowerRelayOutputFail_PEPS_1_1, FCAN.FData);}
  void set_PEPS_PowerRelayOutputFail(const double value) { com.set_can_signal_value((TCANSignal* const)&PEPS_PowerRelayOutputFail_PEPS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_PEPS_PowerRelayOutputFail, put = set_PEPS_PowerRelayOutputFail)) double PEPS_PowerRelayOutputFail;
  double get_PEPS_PIN_LearningStatus(void) { return com.get_can_signal_value((TCANSignal* const)&PEPS_PIN_LearningStatus_PEPS_1_1, FCAN.FData);}
  void set_PEPS_PIN_LearningStatus(const double value) { com.set_can_signal_value((TCANSignal* const)&PEPS_PIN_LearningStatus_PEPS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_PEPS_PIN_LearningStatus, put = set_PEPS_PIN_LearningStatus)) double PEPS_PIN_LearningStatus;
  double get_PEPS_SSB_FailStatus(void) { return com.get_can_signal_value((TCANSignal* const)&PEPS_SSB_FailStatus_PEPS_1_1, FCAN.FData);}
  void set_PEPS_SSB_FailStatus(const double value) { com.set_can_signal_value((TCANSignal* const)&PEPS_SSB_FailStatus_PEPS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_PEPS_SSB_FailStatus, put = set_PEPS_SSB_FailStatus)) double PEPS_SSB_FailStatus;
  double get_PEPS_ESCL_FailStatus(void) { return com.get_can_signal_value((TCANSignal* const)&PEPS_ESCL_FailStatus_PEPS_1_1, FCAN.FData);}
  void set_PEPS_ESCL_FailStatus(const double value) { com.set_can_signal_value((TCANSignal* const)&PEPS_ESCL_FailStatus_PEPS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_PEPS_ESCL_FailStatus, put = set_PEPS_ESCL_FailStatus)) double PEPS_ESCL_FailStatus;
  double get_PEPS_FailStatus(void) { return com.get_can_signal_value((TCANSignal* const)&PEPS_FailStatus_PEPS_1_1, FCAN.FData);}
  void set_PEPS_FailStatus(const double value) { com.set_can_signal_value((TCANSignal* const)&PEPS_FailStatus_PEPS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_PEPS_FailStatus, put = set_PEPS_FailStatus)) double PEPS_FailStatus;
  double get_PEPS_ESCL_NotUnlockWarning(void) { return com.get_can_signal_value((TCANSignal* const)&PEPS_ESCL_NotUnlockWarning_PEPS_1_1, FCAN.FData);}
  void set_PEPS_ESCL_NotUnlockWarning(const double value) { com.set_can_signal_value((TCANSignal* const)&PEPS_ESCL_NotUnlockWarning_PEPS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_PEPS_ESCL_NotUnlockWarning, put = set_PEPS_ESCL_NotUnlockWarning)) double PEPS_ESCL_NotUnlockWarning;
  double get_PEPS_ESCL_NotLockWarning(void) { return com.get_can_signal_value((TCANSignal* const)&PEPS_ESCL_NotLockWarning_PEPS_1_1, FCAN.FData);}
  void set_PEPS_ESCL_NotLockWarning(const double value) { com.set_can_signal_value((TCANSignal* const)&PEPS_ESCL_NotLockWarning_PEPS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_PEPS_ESCL_NotLockWarning, put = set_PEPS_ESCL_NotLockWarning)) double PEPS_ESCL_NotLockWarning;
  double get_PEPS_NotPNWarning(void) { return com.get_can_signal_value((TCANSignal* const)&PEPS_NotPNWarning_PEPS_1_1, FCAN.FData);}
  void set_PEPS_NotPNWarning(const double value) { com.set_can_signal_value((TCANSignal* const)&PEPS_NotPNWarning_PEPS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_PEPS_NotPNWarning, put = set_PEPS_NotPNWarning)) double PEPS_NotPNWarning;
  double get_PEPS_BrakeIndicationWarning(void) { return com.get_can_signal_value((TCANSignal* const)&PEPS_BrakeIndicationWarning_PEPS_1_1, FCAN.FData);}
  void set_PEPS_BrakeIndicationWarning(const double value) { com.set_can_signal_value((TCANSignal* const)&PEPS_BrakeIndicationWarning_PEPS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_PEPS_BrakeIndicationWarning, put = set_PEPS_BrakeIndicationWarning)) double PEPS_BrakeIndicationWarning;
  double get_PEPS_ClutchIndicationWarning(void) { return com.get_can_signal_value((TCANSignal* const)&PEPS_ClutchIndicationWarning_PEPS_1_1, FCAN.FData);}
  void set_PEPS_ClutchIndicationWarning(const double value) { com.set_can_signal_value((TCANSignal* const)&PEPS_ClutchIndicationWarning_PEPS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_PEPS_ClutchIndicationWarning, put = set_PEPS_ClutchIndicationWarning)) double PEPS_ClutchIndicationWarning;
  double get_PEPS_KeyReminderWarning(void) { return com.get_can_signal_value((TCANSignal* const)&PEPS_KeyReminderWarning_PEPS_1_1, FCAN.FData);}
  void set_PEPS_KeyReminderWarning(const double value) { com.set_can_signal_value((TCANSignal* const)&PEPS_KeyReminderWarning_PEPS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_PEPS_KeyReminderWarning, put = set_PEPS_KeyReminderWarning)) double PEPS_KeyReminderWarning;
  double get_PEPS_NoKeyFoundWarning(void) { return com.get_can_signal_value((TCANSignal* const)&PEPS_NoKeyFoundWarning_PEPS_1_1, FCAN.FData);}
  void set_PEPS_NoKeyFoundWarning(const double value) { com.set_can_signal_value((TCANSignal* const)&PEPS_NoKeyFoundWarning_PEPS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_PEPS_NoKeyFoundWarning, put = set_PEPS_NoKeyFoundWarning)) double PEPS_NoKeyFoundWarning;
  double get_PEPS_KeyOutWarning1(void) { return com.get_can_signal_value((TCANSignal* const)&PEPS_KeyOutWarning1_PEPS_1_1, FCAN.FData);}
  void set_PEPS_KeyOutWarning1(const double value) { com.set_can_signal_value((TCANSignal* const)&PEPS_KeyOutWarning1_PEPS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_PEPS_KeyOutWarning1, put = set_PEPS_KeyOutWarning1)) double PEPS_KeyOutWarning1;
  double get_PEPS_KeyBatteryWarning(void) { return com.get_can_signal_value((TCANSignal* const)&PEPS_KeyBatteryWarning_PEPS_1_1, FCAN.FData);}
  void set_PEPS_KeyBatteryWarning(const double value) { com.set_can_signal_value((TCANSignal* const)&PEPS_KeyBatteryWarning_PEPS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_PEPS_KeyBatteryWarning, put = set_PEPS_KeyBatteryWarning)) double PEPS_KeyBatteryWarning;
  double get_PEPS_KeyIntWarning1(void) { return com.get_can_signal_value((TCANSignal* const)&PEPS_KeyIntWarning1_PEPS_1_1, FCAN.FData);}
  void set_PEPS_KeyIntWarning1(const double value) { com.set_can_signal_value((TCANSignal* const)&PEPS_KeyIntWarning1_PEPS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_PEPS_KeyIntWarning1, put = set_PEPS_KeyIntWarning1)) double PEPS_KeyIntWarning1;
  double get_PEPS_LockNotOFFWarning(void) { return com.get_can_signal_value((TCANSignal* const)&PEPS_LockNotOFFWarning_PEPS_1_1, FCAN.FData);}
  void set_PEPS_LockNotOFFWarning(const double value) { com.set_can_signal_value((TCANSignal* const)&PEPS_LockNotOFFWarning_PEPS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_PEPS_LockNotOFFWarning, put = set_PEPS_LockNotOFFWarning)) double PEPS_LockNotOFFWarning;
  double get_PEPS_GearShiftAuthRequest(void) { return com.get_can_signal_value((TCANSignal* const)&PEPS_GearShiftAuthRequest_PEPS_1_1, FCAN.FData);}
  void set_PEPS_GearShiftAuthRequest(const double value) { com.set_can_signal_value((TCANSignal* const)&PEPS_GearShiftAuthRequest_PEPS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_PEPS_GearShiftAuthRequest, put = set_PEPS_GearShiftAuthRequest)) double PEPS_GearShiftAuthRequest;
  void init() { FCAN = create().FCAN; }
  TPEPS_1_1 create() { CANMsgDecl(_PEPS_1_1, cPEPS_1_1, 0, 0, 8, 616) return cPEPS_1_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message PEPS_3_1
extern const TCANSignal PEPS_RemoteControlSt_PEPS_3_1;
extern const TCANSignal PEPS_3_RollingCounter_PEPS_3_1;
extern const TCANSignal PEPS_3_Checksum_PEPS_3_1;
struct _PEPS_3_1;
typedef struct _PEPS_3_1 TPEPS_3_1;
struct _PEPS_3_1{
  TCAN FCAN;
  double get_PEPS_RemoteControlSt(void) { return com.get_can_signal_value((TCANSignal* const)&PEPS_RemoteControlSt_PEPS_3_1, FCAN.FData);}
  void set_PEPS_RemoteControlSt(const double value) { com.set_can_signal_value((TCANSignal* const)&PEPS_RemoteControlSt_PEPS_3_1, FCAN.FData, value);}
  __declspec(property(get = get_PEPS_RemoteControlSt, put = set_PEPS_RemoteControlSt)) double PEPS_RemoteControlSt;
  double get_PEPS_3_RollingCounter(void) { return com.get_can_signal_value((TCANSignal* const)&PEPS_3_RollingCounter_PEPS_3_1, FCAN.FData);}
  void set_PEPS_3_RollingCounter(const double value) { com.set_can_signal_value((TCANSignal* const)&PEPS_3_RollingCounter_PEPS_3_1, FCAN.FData, value);}
  __declspec(property(get = get_PEPS_3_RollingCounter, put = set_PEPS_3_RollingCounter)) double PEPS_3_RollingCounter;
  double get_PEPS_3_Checksum(void) { return com.get_can_signal_value((TCANSignal* const)&PEPS_3_Checksum_PEPS_3_1, FCAN.FData);}
  void set_PEPS_3_Checksum(const double value) { com.set_can_signal_value((TCANSignal* const)&PEPS_3_Checksum_PEPS_3_1, FCAN.FData, value);}
  __declspec(property(get = get_PEPS_3_Checksum, put = set_PEPS_3_Checksum)) double PEPS_3_Checksum;
  void init() { FCAN = create().FCAN; }
  TPEPS_3_1 create() { CANMsgDecl(_PEPS_3_1, cPEPS_3_1, 0, 0, 8, 617) return cPEPS_3_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message IC_1_1
extern const TCANSignal IC_SurplusFuel_IC_1_1;
extern const TCANSignal IC_ParkingBrakeIndication_IC_1_1;
extern const TCANSignal IC_BrakeFluidLevelIndication_IC_1_1;
extern const TCANSignal IC_FuelSignalShortToGND_IC_1_1;
extern const TCANSignal IC_FuelSignalShortToBattery_IC_1_1;
extern const TCANSignal IC_FuelSignalOpen_IC_1_1;
extern const TCANSignal IC_EngineOilLowPressure_IC_1_1;
extern const TCANSignal IC_BrakeSysFailIndication_IC_1_1;
extern const TCANSignal IC_SurplusMileage_IC_1_1;
extern const TCANSignal IC_SurplusFuelValid_IC_1_1;
extern const TCANSignal IC_OdoMeterValid_IC_1_1;
extern const TCANSignal IC_PassSeatbeltBucklestatus_IC_1_1;
extern const TCANSignal IC_DrvSeatbeltBucklestatus_IC_1_1;
extern const TCANSignal IC_OdoMeter_IC_1_1;
extern const TCANSignal IC_ICFaultSts_IC_1_1;
extern const TCANSignal IC_RearleftsideSeatbeltBucklesta_IC_1_1;
extern const TCANSignal IC_RearmiddleSeatbeltBucklestatu_IC_1_1;
extern const TCANSignal IC_RearrightsideSeatbeltBucklest_IC_1_1;
extern const TCANSignal IC_AirbagInhibitWarning_IC_1_1;
extern const TCANSignal IC_DisplayVehicleSpeedUnit_IC_1_1;
extern const TCANSignal IC_DisplayVehicleSpeedValue_IC_1_1;
struct _IC_1_1;
typedef struct _IC_1_1 TIC_1_1;
struct _IC_1_1{
  TCAN FCAN;
  double get_IC_SurplusFuel(void) { return com.get_can_signal_value((TCANSignal* const)&IC_SurplusFuel_IC_1_1, FCAN.FData);}
  void set_IC_SurplusFuel(const double value) { com.set_can_signal_value((TCANSignal* const)&IC_SurplusFuel_IC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IC_SurplusFuel, put = set_IC_SurplusFuel)) double IC_SurplusFuel;
  double get_IC_ParkingBrakeIndication(void) { return com.get_can_signal_value((TCANSignal* const)&IC_ParkingBrakeIndication_IC_1_1, FCAN.FData);}
  void set_IC_ParkingBrakeIndication(const double value) { com.set_can_signal_value((TCANSignal* const)&IC_ParkingBrakeIndication_IC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IC_ParkingBrakeIndication, put = set_IC_ParkingBrakeIndication)) double IC_ParkingBrakeIndication;
  double get_IC_BrakeFluidLevelIndication(void) { return com.get_can_signal_value((TCANSignal* const)&IC_BrakeFluidLevelIndication_IC_1_1, FCAN.FData);}
  void set_IC_BrakeFluidLevelIndication(const double value) { com.set_can_signal_value((TCANSignal* const)&IC_BrakeFluidLevelIndication_IC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IC_BrakeFluidLevelIndication, put = set_IC_BrakeFluidLevelIndication)) double IC_BrakeFluidLevelIndication;
  double get_IC_FuelSignalShortToGND(void) { return com.get_can_signal_value((TCANSignal* const)&IC_FuelSignalShortToGND_IC_1_1, FCAN.FData);}
  void set_IC_FuelSignalShortToGND(const double value) { com.set_can_signal_value((TCANSignal* const)&IC_FuelSignalShortToGND_IC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IC_FuelSignalShortToGND, put = set_IC_FuelSignalShortToGND)) double IC_FuelSignalShortToGND;
  double get_IC_FuelSignalShortToBattery(void) { return com.get_can_signal_value((TCANSignal* const)&IC_FuelSignalShortToBattery_IC_1_1, FCAN.FData);}
  void set_IC_FuelSignalShortToBattery(const double value) { com.set_can_signal_value((TCANSignal* const)&IC_FuelSignalShortToBattery_IC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IC_FuelSignalShortToBattery, put = set_IC_FuelSignalShortToBattery)) double IC_FuelSignalShortToBattery;
  double get_IC_FuelSignalOpen(void) { return com.get_can_signal_value((TCANSignal* const)&IC_FuelSignalOpen_IC_1_1, FCAN.FData);}
  void set_IC_FuelSignalOpen(const double value) { com.set_can_signal_value((TCANSignal* const)&IC_FuelSignalOpen_IC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IC_FuelSignalOpen, put = set_IC_FuelSignalOpen)) double IC_FuelSignalOpen;
  double get_IC_EngineOilLowPressure(void) { return com.get_can_signal_value((TCANSignal* const)&IC_EngineOilLowPressure_IC_1_1, FCAN.FData);}
  void set_IC_EngineOilLowPressure(const double value) { com.set_can_signal_value((TCANSignal* const)&IC_EngineOilLowPressure_IC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IC_EngineOilLowPressure, put = set_IC_EngineOilLowPressure)) double IC_EngineOilLowPressure;
  double get_IC_BrakeSysFailIndication(void) { return com.get_can_signal_value((TCANSignal* const)&IC_BrakeSysFailIndication_IC_1_1, FCAN.FData);}
  void set_IC_BrakeSysFailIndication(const double value) { com.set_can_signal_value((TCANSignal* const)&IC_BrakeSysFailIndication_IC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IC_BrakeSysFailIndication, put = set_IC_BrakeSysFailIndication)) double IC_BrakeSysFailIndication;
  double get_IC_SurplusMileage(void) { return com.get_can_signal_value((TCANSignal* const)&IC_SurplusMileage_IC_1_1, FCAN.FData);}
  void set_IC_SurplusMileage(const double value) { com.set_can_signal_value((TCANSignal* const)&IC_SurplusMileage_IC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IC_SurplusMileage, put = set_IC_SurplusMileage)) double IC_SurplusMileage;
  double get_IC_SurplusFuelValid(void) { return com.get_can_signal_value((TCANSignal* const)&IC_SurplusFuelValid_IC_1_1, FCAN.FData);}
  void set_IC_SurplusFuelValid(const double value) { com.set_can_signal_value((TCANSignal* const)&IC_SurplusFuelValid_IC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IC_SurplusFuelValid, put = set_IC_SurplusFuelValid)) double IC_SurplusFuelValid;
  double get_IC_OdoMeterValid(void) { return com.get_can_signal_value((TCANSignal* const)&IC_OdoMeterValid_IC_1_1, FCAN.FData);}
  void set_IC_OdoMeterValid(const double value) { com.set_can_signal_value((TCANSignal* const)&IC_OdoMeterValid_IC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IC_OdoMeterValid, put = set_IC_OdoMeterValid)) double IC_OdoMeterValid;
  double get_IC_PassSeatbeltBucklestatus(void) { return com.get_can_signal_value((TCANSignal* const)&IC_PassSeatbeltBucklestatus_IC_1_1, FCAN.FData);}
  void set_IC_PassSeatbeltBucklestatus(const double value) { com.set_can_signal_value((TCANSignal* const)&IC_PassSeatbeltBucklestatus_IC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IC_PassSeatbeltBucklestatus, put = set_IC_PassSeatbeltBucklestatus)) double IC_PassSeatbeltBucklestatus;
  double get_IC_DrvSeatbeltBucklestatus(void) { return com.get_can_signal_value((TCANSignal* const)&IC_DrvSeatbeltBucklestatus_IC_1_1, FCAN.FData);}
  void set_IC_DrvSeatbeltBucklestatus(const double value) { com.set_can_signal_value((TCANSignal* const)&IC_DrvSeatbeltBucklestatus_IC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IC_DrvSeatbeltBucklestatus, put = set_IC_DrvSeatbeltBucklestatus)) double IC_DrvSeatbeltBucklestatus;
  double get_IC_OdoMeter(void) { return com.get_can_signal_value((TCANSignal* const)&IC_OdoMeter_IC_1_1, FCAN.FData);}
  void set_IC_OdoMeter(const double value) { com.set_can_signal_value((TCANSignal* const)&IC_OdoMeter_IC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IC_OdoMeter, put = set_IC_OdoMeter)) double IC_OdoMeter;
  double get_IC_ICFaultSts(void) { return com.get_can_signal_value((TCANSignal* const)&IC_ICFaultSts_IC_1_1, FCAN.FData);}
  void set_IC_ICFaultSts(const double value) { com.set_can_signal_value((TCANSignal* const)&IC_ICFaultSts_IC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IC_ICFaultSts, put = set_IC_ICFaultSts)) double IC_ICFaultSts;
  double get_IC_RearleftsideSeatbeltBucklesta(void) { return com.get_can_signal_value((TCANSignal* const)&IC_RearleftsideSeatbeltBucklesta_IC_1_1, FCAN.FData);}
  void set_IC_RearleftsideSeatbeltBucklesta(const double value) { com.set_can_signal_value((TCANSignal* const)&IC_RearleftsideSeatbeltBucklesta_IC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IC_RearleftsideSeatbeltBucklesta, put = set_IC_RearleftsideSeatbeltBucklesta)) double IC_RearleftsideSeatbeltBucklesta;
  double get_IC_RearmiddleSeatbeltBucklestatu(void) { return com.get_can_signal_value((TCANSignal* const)&IC_RearmiddleSeatbeltBucklestatu_IC_1_1, FCAN.FData);}
  void set_IC_RearmiddleSeatbeltBucklestatu(const double value) { com.set_can_signal_value((TCANSignal* const)&IC_RearmiddleSeatbeltBucklestatu_IC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IC_RearmiddleSeatbeltBucklestatu, put = set_IC_RearmiddleSeatbeltBucklestatu)) double IC_RearmiddleSeatbeltBucklestatu;
  double get_IC_RearrightsideSeatbeltBucklest(void) { return com.get_can_signal_value((TCANSignal* const)&IC_RearrightsideSeatbeltBucklest_IC_1_1, FCAN.FData);}
  void set_IC_RearrightsideSeatbeltBucklest(const double value) { com.set_can_signal_value((TCANSignal* const)&IC_RearrightsideSeatbeltBucklest_IC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IC_RearrightsideSeatbeltBucklest, put = set_IC_RearrightsideSeatbeltBucklest)) double IC_RearrightsideSeatbeltBucklest;
  double get_IC_AirbagInhibitWarning(void) { return com.get_can_signal_value((TCANSignal* const)&IC_AirbagInhibitWarning_IC_1_1, FCAN.FData);}
  void set_IC_AirbagInhibitWarning(const double value) { com.set_can_signal_value((TCANSignal* const)&IC_AirbagInhibitWarning_IC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IC_AirbagInhibitWarning, put = set_IC_AirbagInhibitWarning)) double IC_AirbagInhibitWarning;
  double get_IC_DisplayVehicleSpeedUnit(void) { return com.get_can_signal_value((TCANSignal* const)&IC_DisplayVehicleSpeedUnit_IC_1_1, FCAN.FData);}
  void set_IC_DisplayVehicleSpeedUnit(const double value) { com.set_can_signal_value((TCANSignal* const)&IC_DisplayVehicleSpeedUnit_IC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IC_DisplayVehicleSpeedUnit, put = set_IC_DisplayVehicleSpeedUnit)) double IC_DisplayVehicleSpeedUnit;
  double get_IC_DisplayVehicleSpeedValue(void) { return com.get_can_signal_value((TCANSignal* const)&IC_DisplayVehicleSpeedValue_IC_1_1, FCAN.FData);}
  void set_IC_DisplayVehicleSpeedValue(const double value) { com.set_can_signal_value((TCANSignal* const)&IC_DisplayVehicleSpeedValue_IC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IC_DisplayVehicleSpeedValue, put = set_IC_DisplayVehicleSpeedValue)) double IC_DisplayVehicleSpeedValue;
  void init() { FCAN = create().FCAN; }
  TIC_1_1 create() { CANMsgDecl(_IC_1_1, cIC_1_1, 0, 0, 8, 885) return cIC_1_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message IC_2_1
extern const TCANSignal IC_TripAvgFuelConsRate_IC_2_1;
extern const TCANSignal IC_LifeTimeAvgFuelConsRate_IC_2_1;
struct _IC_2_1;
typedef struct _IC_2_1 TIC_2_1;
struct _IC_2_1{
  TCAN FCAN;
  double get_IC_TripAvgFuelConsRate(void) { return com.get_can_signal_value((TCANSignal* const)&IC_TripAvgFuelConsRate_IC_2_1, FCAN.FData);}
  void set_IC_TripAvgFuelConsRate(const double value) { com.set_can_signal_value((TCANSignal* const)&IC_TripAvgFuelConsRate_IC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_IC_TripAvgFuelConsRate, put = set_IC_TripAvgFuelConsRate)) double IC_TripAvgFuelConsRate;
  double get_IC_LifeTimeAvgFuelConsRate(void) { return com.get_can_signal_value((TCANSignal* const)&IC_LifeTimeAvgFuelConsRate_IC_2_1, FCAN.FData);}
  void set_IC_LifeTimeAvgFuelConsRate(const double value) { com.set_can_signal_value((TCANSignal* const)&IC_LifeTimeAvgFuelConsRate_IC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_IC_LifeTimeAvgFuelConsRate, put = set_IC_LifeTimeAvgFuelConsRate)) double IC_LifeTimeAvgFuelConsRate;
  void init() { FCAN = create().FCAN; }
  TIC_2_1 create() { CANMsgDecl(_IC_2_1, cIC_2_1, 0, 0, 8, 886) return cIC_2_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message IHU_1_1
extern const TCANSignal IHU_EPMModSet_IHU_1_1;
extern const TCANSignal IHU_ACSelfCleanModeSet_IHU_1_1;
extern const TCANSignal IHU_FrontDefrostButtonSts_IHU_1_1;
extern const TCANSignal IHU_RearDefrostButtonSts_IHU_1_1;
extern const TCANSignal IHU_FollowMeHome_Time_IHU_1_1;
extern const TCANSignal IHU_LeaveHome_Time_IHU_1_1;
extern const TCANSignal IHU_ACButtonSts_IHU_1_1;
extern const TCANSignal IHU_InteriorLightTimeAjust_IHU_1_1;
extern const TCANSignal IHU_TemperatureAjust_IHU_1_1;
extern const TCANSignal IHU_ACSystemOff_IHU_1_1;
extern const TCANSignal IHU_BlowerSpeedAjust_IHU_1_1;
extern const TCANSignal IHU_AirDistributeMode_IHU_1_1;
extern const TCANSignal IHU_AirCirculationMode_IHU_1_1;
extern const TCANSignal IHU_PTCButtonSts_IHU_1_1;
extern const TCANSignal IHU_AUTOButtonSts_IHU_1_1;
extern const TCANSignal IHU_AUTOPassengerButtonSts_IHU_1_1;
extern const TCANSignal IHU_DualButtonSts_IHU_1_1;
extern const TCANSignal IHU_DriverSetTemperature_IHU_1_1;
extern const TCANSignal IHU_PngSetTemperature_IHU_1_1;
extern const TCANSignal IHU_SS_Set_IHU_1_1;
extern const TCANSignal IHU_DrivemodeSet_IHU_1_1;
extern const TCANSignal IHU_WirelessChargeSwtSet_IHU_1_1;
struct _IHU_1_1;
typedef struct _IHU_1_1 TIHU_1_1;
struct _IHU_1_1{
  TCAN FCAN;
  double get_IHU_EPMModSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_EPMModSet_IHU_1_1, FCAN.FData);}
  void set_IHU_EPMModSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_EPMModSet_IHU_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_EPMModSet, put = set_IHU_EPMModSet)) double IHU_EPMModSet;
  double get_IHU_ACSelfCleanModeSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_ACSelfCleanModeSet_IHU_1_1, FCAN.FData);}
  void set_IHU_ACSelfCleanModeSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_ACSelfCleanModeSet_IHU_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_ACSelfCleanModeSet, put = set_IHU_ACSelfCleanModeSet)) double IHU_ACSelfCleanModeSet;
  double get_IHU_FrontDefrostButtonSts(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_FrontDefrostButtonSts_IHU_1_1, FCAN.FData);}
  void set_IHU_FrontDefrostButtonSts(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_FrontDefrostButtonSts_IHU_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_FrontDefrostButtonSts, put = set_IHU_FrontDefrostButtonSts)) double IHU_FrontDefrostButtonSts;
  double get_IHU_RearDefrostButtonSts(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_RearDefrostButtonSts_IHU_1_1, FCAN.FData);}
  void set_IHU_RearDefrostButtonSts(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_RearDefrostButtonSts_IHU_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_RearDefrostButtonSts, put = set_IHU_RearDefrostButtonSts)) double IHU_RearDefrostButtonSts;
  double get_IHU_FollowMeHome_Time(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_FollowMeHome_Time_IHU_1_1, FCAN.FData);}
  void set_IHU_FollowMeHome_Time(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_FollowMeHome_Time_IHU_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_FollowMeHome_Time, put = set_IHU_FollowMeHome_Time)) double IHU_FollowMeHome_Time;
  double get_IHU_LeaveHome_Time(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_LeaveHome_Time_IHU_1_1, FCAN.FData);}
  void set_IHU_LeaveHome_Time(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_LeaveHome_Time_IHU_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_LeaveHome_Time, put = set_IHU_LeaveHome_Time)) double IHU_LeaveHome_Time;
  double get_IHU_ACButtonSts(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_ACButtonSts_IHU_1_1, FCAN.FData);}
  void set_IHU_ACButtonSts(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_ACButtonSts_IHU_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_ACButtonSts, put = set_IHU_ACButtonSts)) double IHU_ACButtonSts;
  double get_IHU_InteriorLightTimeAjust(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_InteriorLightTimeAjust_IHU_1_1, FCAN.FData);}
  void set_IHU_InteriorLightTimeAjust(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_InteriorLightTimeAjust_IHU_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_InteriorLightTimeAjust, put = set_IHU_InteriorLightTimeAjust)) double IHU_InteriorLightTimeAjust;
  double get_IHU_TemperatureAjust(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_TemperatureAjust_IHU_1_1, FCAN.FData);}
  void set_IHU_TemperatureAjust(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_TemperatureAjust_IHU_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_TemperatureAjust, put = set_IHU_TemperatureAjust)) double IHU_TemperatureAjust;
  double get_IHU_ACSystemOff(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_ACSystemOff_IHU_1_1, FCAN.FData);}
  void set_IHU_ACSystemOff(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_ACSystemOff_IHU_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_ACSystemOff, put = set_IHU_ACSystemOff)) double IHU_ACSystemOff;
  double get_IHU_BlowerSpeedAjust(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_BlowerSpeedAjust_IHU_1_1, FCAN.FData);}
  void set_IHU_BlowerSpeedAjust(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_BlowerSpeedAjust_IHU_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_BlowerSpeedAjust, put = set_IHU_BlowerSpeedAjust)) double IHU_BlowerSpeedAjust;
  double get_IHU_AirDistributeMode(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_AirDistributeMode_IHU_1_1, FCAN.FData);}
  void set_IHU_AirDistributeMode(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_AirDistributeMode_IHU_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_AirDistributeMode, put = set_IHU_AirDistributeMode)) double IHU_AirDistributeMode;
  double get_IHU_AirCirculationMode(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_AirCirculationMode_IHU_1_1, FCAN.FData);}
  void set_IHU_AirCirculationMode(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_AirCirculationMode_IHU_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_AirCirculationMode, put = set_IHU_AirCirculationMode)) double IHU_AirCirculationMode;
  double get_IHU_PTCButtonSts(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_PTCButtonSts_IHU_1_1, FCAN.FData);}
  void set_IHU_PTCButtonSts(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_PTCButtonSts_IHU_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_PTCButtonSts, put = set_IHU_PTCButtonSts)) double IHU_PTCButtonSts;
  double get_IHU_AUTOButtonSts(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_AUTOButtonSts_IHU_1_1, FCAN.FData);}
  void set_IHU_AUTOButtonSts(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_AUTOButtonSts_IHU_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_AUTOButtonSts, put = set_IHU_AUTOButtonSts)) double IHU_AUTOButtonSts;
  double get_IHU_AUTOPassengerButtonSts(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_AUTOPassengerButtonSts_IHU_1_1, FCAN.FData);}
  void set_IHU_AUTOPassengerButtonSts(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_AUTOPassengerButtonSts_IHU_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_AUTOPassengerButtonSts, put = set_IHU_AUTOPassengerButtonSts)) double IHU_AUTOPassengerButtonSts;
  double get_IHU_DualButtonSts(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_DualButtonSts_IHU_1_1, FCAN.FData);}
  void set_IHU_DualButtonSts(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_DualButtonSts_IHU_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_DualButtonSts, put = set_IHU_DualButtonSts)) double IHU_DualButtonSts;
  double get_IHU_DriverSetTemperature(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_DriverSetTemperature_IHU_1_1, FCAN.FData);}
  void set_IHU_DriverSetTemperature(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_DriverSetTemperature_IHU_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_DriverSetTemperature, put = set_IHU_DriverSetTemperature)) double IHU_DriverSetTemperature;
  double get_IHU_PngSetTemperature(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_PngSetTemperature_IHU_1_1, FCAN.FData);}
  void set_IHU_PngSetTemperature(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_PngSetTemperature_IHU_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_PngSetTemperature, put = set_IHU_PngSetTemperature)) double IHU_PngSetTemperature;
  double get_IHU_SS_Set(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_SS_Set_IHU_1_1, FCAN.FData);}
  void set_IHU_SS_Set(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_SS_Set_IHU_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_SS_Set, put = set_IHU_SS_Set)) double IHU_SS_Set;
  double get_IHU_DrivemodeSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_DrivemodeSet_IHU_1_1, FCAN.FData);}
  void set_IHU_DrivemodeSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_DrivemodeSet_IHU_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_DrivemodeSet, put = set_IHU_DrivemodeSet)) double IHU_DrivemodeSet;
  double get_IHU_WirelessChargeSwtSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_WirelessChargeSwtSet_IHU_1_1, FCAN.FData);}
  void set_IHU_WirelessChargeSwtSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_WirelessChargeSwtSet_IHU_1_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_WirelessChargeSwtSet, put = set_IHU_WirelessChargeSwtSet)) double IHU_WirelessChargeSwtSet;
  void init() { FCAN = create().FCAN; }
  TIHU_1_1 create() { CANMsgDecl(_IHU_1_1, cIHU_1_1, 0, 0, 8, 768) return cIHU_1_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message IHU_2_1
extern const TCANSignal IHU_DateTimeSecond_IHU_2_1;
extern const TCANSignal IHU_DateTimeMinute_IHU_2_1;
extern const TCANSignal IHU_DateTimeHour_IHU_2_1;
extern const TCANSignal IHU_DateTimeDay_IHU_2_1;
extern const TCANSignal IHU_DateTimeMonth_IHU_2_1;
extern const TCANSignal IHU_DateTimeYear_IHU_2_1;
extern const TCANSignal IHU_TimeValid_IHU_2_1;
struct _IHU_2_1;
typedef struct _IHU_2_1 TIHU_2_1;
struct _IHU_2_1{
  TCAN FCAN;
  double get_IHU_DateTimeSecond(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_DateTimeSecond_IHU_2_1, FCAN.FData);}
  void set_IHU_DateTimeSecond(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_DateTimeSecond_IHU_2_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_DateTimeSecond, put = set_IHU_DateTimeSecond)) double IHU_DateTimeSecond;
  double get_IHU_DateTimeMinute(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_DateTimeMinute_IHU_2_1, FCAN.FData);}
  void set_IHU_DateTimeMinute(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_DateTimeMinute_IHU_2_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_DateTimeMinute, put = set_IHU_DateTimeMinute)) double IHU_DateTimeMinute;
  double get_IHU_DateTimeHour(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_DateTimeHour_IHU_2_1, FCAN.FData);}
  void set_IHU_DateTimeHour(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_DateTimeHour_IHU_2_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_DateTimeHour, put = set_IHU_DateTimeHour)) double IHU_DateTimeHour;
  double get_IHU_DateTimeDay(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_DateTimeDay_IHU_2_1, FCAN.FData);}
  void set_IHU_DateTimeDay(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_DateTimeDay_IHU_2_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_DateTimeDay, put = set_IHU_DateTimeDay)) double IHU_DateTimeDay;
  double get_IHU_DateTimeMonth(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_DateTimeMonth_IHU_2_1, FCAN.FData);}
  void set_IHU_DateTimeMonth(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_DateTimeMonth_IHU_2_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_DateTimeMonth, put = set_IHU_DateTimeMonth)) double IHU_DateTimeMonth;
  double get_IHU_DateTimeYear(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_DateTimeYear_IHU_2_1, FCAN.FData);}
  void set_IHU_DateTimeYear(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_DateTimeYear_IHU_2_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_DateTimeYear, put = set_IHU_DateTimeYear)) double IHU_DateTimeYear;
  double get_IHU_TimeValid(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_TimeValid_IHU_2_1, FCAN.FData);}
  void set_IHU_TimeValid(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_TimeValid_IHU_2_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_TimeValid, put = set_IHU_TimeValid)) double IHU_TimeValid;
  void init() { FCAN = create().FCAN; }
  TIHU_2_1 create() { CANMsgDecl(_IHU_2_1, cIHU_2_1, 0, 0, 8, 1346) return cIHU_2_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message IHU_3_1
extern const TCANSignal IHU_AEBSwtSet_IHU_3_1;
extern const TCANSignal IHU_LDWWarnVoiceSwtSet_IHU_3_1;
extern const TCANSignal IHU_TSRSwtSet_IHU_3_1;
extern const TCANSignal IHU__IHBCSwtSet_IHU_3_1;
extern const TCANSignal IHU_TSROverSpeedSwSet_IHU_3_1;
extern const TCANSignal IHU_TSROverSpeedAcousticSwSet_IHU_3_1;
extern const TCANSignal IHU_FlaoutUnlockSet_IHU_3_1;
extern const TCANSignal IHU_AutoWshWipSet_IHU_3_1;
extern const TCANSignal IHU_SpeedLockSet_IHU_3_1;
extern const TCANSignal IHU_HornAlertVolumeSet_IHU_3_1;
extern const TCANSignal IHU_WindowRemoteAutoDownSet_IHU_3_1;
extern const TCANSignal IHU_AssistIlluminationSet_IHU_3_1;
extern const TCANSignal IHU_exRearMirrorAutoFoldSet_IHU_3_1;
extern const TCANSignal IHU_WindowAutoUPbyLockSet_IHU_3_1;
extern const TCANSignal IHU_SearchCarWarnModSet_IHU_3_1;
extern const TCANSignal IHU_FLSeatHeatLvlSet_IHU_3_1;
extern const TCANSignal IHU_FRSeatHeatLvlSet_IHU_3_1;
extern const TCANSignal IHU_FLSeatMassgLvlSet_IHU_3_1;
extern const TCANSignal IHU_FLSeatMassgModSet_IHU_3_1;
extern const TCANSignal IHU_ClsWinSpdSet_IHU_3_1;
extern const TCANSignal IHU_Frontwindshieldheatingtset_IHU_3_1;
extern const TCANSignal IHU_Nozzleheatingset_IHU_3_1;
struct _IHU_3_1;
typedef struct _IHU_3_1 TIHU_3_1;
struct _IHU_3_1{
  TCAN FCAN;
  double get_IHU_AEBSwtSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_AEBSwtSet_IHU_3_1, FCAN.FData);}
  void set_IHU_AEBSwtSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_AEBSwtSet_IHU_3_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_AEBSwtSet, put = set_IHU_AEBSwtSet)) double IHU_AEBSwtSet;
  double get_IHU_LDWWarnVoiceSwtSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_LDWWarnVoiceSwtSet_IHU_3_1, FCAN.FData);}
  void set_IHU_LDWWarnVoiceSwtSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_LDWWarnVoiceSwtSet_IHU_3_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_LDWWarnVoiceSwtSet, put = set_IHU_LDWWarnVoiceSwtSet)) double IHU_LDWWarnVoiceSwtSet;
  double get_IHU_TSRSwtSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_TSRSwtSet_IHU_3_1, FCAN.FData);}
  void set_IHU_TSRSwtSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_TSRSwtSet_IHU_3_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_TSRSwtSet, put = set_IHU_TSRSwtSet)) double IHU_TSRSwtSet;
  double get_IHU__IHBCSwtSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU__IHBCSwtSet_IHU_3_1, FCAN.FData);}
  void set_IHU__IHBCSwtSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU__IHBCSwtSet_IHU_3_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU__IHBCSwtSet, put = set_IHU__IHBCSwtSet)) double IHU__IHBCSwtSet;
  double get_IHU_TSROverSpeedSwSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_TSROverSpeedSwSet_IHU_3_1, FCAN.FData);}
  void set_IHU_TSROverSpeedSwSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_TSROverSpeedSwSet_IHU_3_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_TSROverSpeedSwSet, put = set_IHU_TSROverSpeedSwSet)) double IHU_TSROverSpeedSwSet;
  double get_IHU_TSROverSpeedAcousticSwSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_TSROverSpeedAcousticSwSet_IHU_3_1, FCAN.FData);}
  void set_IHU_TSROverSpeedAcousticSwSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_TSROverSpeedAcousticSwSet_IHU_3_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_TSROverSpeedAcousticSwSet, put = set_IHU_TSROverSpeedAcousticSwSet)) double IHU_TSROverSpeedAcousticSwSet;
  double get_IHU_FlaoutUnlockSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_FlaoutUnlockSet_IHU_3_1, FCAN.FData);}
  void set_IHU_FlaoutUnlockSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_FlaoutUnlockSet_IHU_3_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_FlaoutUnlockSet, put = set_IHU_FlaoutUnlockSet)) double IHU_FlaoutUnlockSet;
  double get_IHU_AutoWshWipSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_AutoWshWipSet_IHU_3_1, FCAN.FData);}
  void set_IHU_AutoWshWipSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_AutoWshWipSet_IHU_3_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_AutoWshWipSet, put = set_IHU_AutoWshWipSet)) double IHU_AutoWshWipSet;
  double get_IHU_SpeedLockSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_SpeedLockSet_IHU_3_1, FCAN.FData);}
  void set_IHU_SpeedLockSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_SpeedLockSet_IHU_3_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_SpeedLockSet, put = set_IHU_SpeedLockSet)) double IHU_SpeedLockSet;
  double get_IHU_HornAlertVolumeSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_HornAlertVolumeSet_IHU_3_1, FCAN.FData);}
  void set_IHU_HornAlertVolumeSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_HornAlertVolumeSet_IHU_3_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_HornAlertVolumeSet, put = set_IHU_HornAlertVolumeSet)) double IHU_HornAlertVolumeSet;
  double get_IHU_WindowRemoteAutoDownSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_WindowRemoteAutoDownSet_IHU_3_1, FCAN.FData);}
  void set_IHU_WindowRemoteAutoDownSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_WindowRemoteAutoDownSet_IHU_3_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_WindowRemoteAutoDownSet, put = set_IHU_WindowRemoteAutoDownSet)) double IHU_WindowRemoteAutoDownSet;
  double get_IHU_AssistIlluminationSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_AssistIlluminationSet_IHU_3_1, FCAN.FData);}
  void set_IHU_AssistIlluminationSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_AssistIlluminationSet_IHU_3_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_AssistIlluminationSet, put = set_IHU_AssistIlluminationSet)) double IHU_AssistIlluminationSet;
  double get_IHU_exRearMirrorAutoFoldSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_exRearMirrorAutoFoldSet_IHU_3_1, FCAN.FData);}
  void set_IHU_exRearMirrorAutoFoldSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_exRearMirrorAutoFoldSet_IHU_3_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_exRearMirrorAutoFoldSet, put = set_IHU_exRearMirrorAutoFoldSet)) double IHU_exRearMirrorAutoFoldSet;
  double get_IHU_WindowAutoUPbyLockSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_WindowAutoUPbyLockSet_IHU_3_1, FCAN.FData);}
  void set_IHU_WindowAutoUPbyLockSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_WindowAutoUPbyLockSet_IHU_3_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_WindowAutoUPbyLockSet, put = set_IHU_WindowAutoUPbyLockSet)) double IHU_WindowAutoUPbyLockSet;
  double get_IHU_SearchCarWarnModSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_SearchCarWarnModSet_IHU_3_1, FCAN.FData);}
  void set_IHU_SearchCarWarnModSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_SearchCarWarnModSet_IHU_3_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_SearchCarWarnModSet, put = set_IHU_SearchCarWarnModSet)) double IHU_SearchCarWarnModSet;
  double get_IHU_FLSeatHeatLvlSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_FLSeatHeatLvlSet_IHU_3_1, FCAN.FData);}
  void set_IHU_FLSeatHeatLvlSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_FLSeatHeatLvlSet_IHU_3_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_FLSeatHeatLvlSet, put = set_IHU_FLSeatHeatLvlSet)) double IHU_FLSeatHeatLvlSet;
  double get_IHU_FRSeatHeatLvlSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_FRSeatHeatLvlSet_IHU_3_1, FCAN.FData);}
  void set_IHU_FRSeatHeatLvlSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_FRSeatHeatLvlSet_IHU_3_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_FRSeatHeatLvlSet, put = set_IHU_FRSeatHeatLvlSet)) double IHU_FRSeatHeatLvlSet;
  double get_IHU_FLSeatMassgLvlSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_FLSeatMassgLvlSet_IHU_3_1, FCAN.FData);}
  void set_IHU_FLSeatMassgLvlSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_FLSeatMassgLvlSet_IHU_3_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_FLSeatMassgLvlSet, put = set_IHU_FLSeatMassgLvlSet)) double IHU_FLSeatMassgLvlSet;
  double get_IHU_FLSeatMassgModSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_FLSeatMassgModSet_IHU_3_1, FCAN.FData);}
  void set_IHU_FLSeatMassgModSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_FLSeatMassgModSet_IHU_3_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_FLSeatMassgModSet, put = set_IHU_FLSeatMassgModSet)) double IHU_FLSeatMassgModSet;
  double get_IHU_ClsWinSpdSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_ClsWinSpdSet_IHU_3_1, FCAN.FData);}
  void set_IHU_ClsWinSpdSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_ClsWinSpdSet_IHU_3_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_ClsWinSpdSet, put = set_IHU_ClsWinSpdSet)) double IHU_ClsWinSpdSet;
  double get_IHU_Frontwindshieldheatingtset(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_Frontwindshieldheatingtset_IHU_3_1, FCAN.FData);}
  void set_IHU_Frontwindshieldheatingtset(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_Frontwindshieldheatingtset_IHU_3_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_Frontwindshieldheatingtset, put = set_IHU_Frontwindshieldheatingtset)) double IHU_Frontwindshieldheatingtset;
  double get_IHU_Nozzleheatingset(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_Nozzleheatingset_IHU_3_1, FCAN.FData);}
  void set_IHU_Nozzleheatingset(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_Nozzleheatingset_IHU_3_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_Nozzleheatingset, put = set_IHU_Nozzleheatingset)) double IHU_Nozzleheatingset;
  void init() { FCAN = create().FCAN; }
  TIHU_3_1 create() { CANMsgDecl(_IHU_3_1, cIHU_3_1, 0, 0, 8, 144) return cIHU_3_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message IHU_4_1
extern const TCANSignal IHU_NavSpeedLimitStatus_IHU_4_1;
extern const TCANSignal IHU_NavSpeedLimit_IHU_4_1;
extern const TCANSignal IHU_NavSpeedLimitUnits_IHU_4_1;
extern const TCANSignal IHU_NavCurrRoadType_IHU_4_1;
struct _IHU_4_1;
typedef struct _IHU_4_1 TIHU_4_1;
struct _IHU_4_1{
  TCAN FCAN;
  double get_IHU_NavSpeedLimitStatus(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_NavSpeedLimitStatus_IHU_4_1, FCAN.FData);}
  void set_IHU_NavSpeedLimitStatus(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_NavSpeedLimitStatus_IHU_4_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_NavSpeedLimitStatus, put = set_IHU_NavSpeedLimitStatus)) double IHU_NavSpeedLimitStatus;
  double get_IHU_NavSpeedLimit(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_NavSpeedLimit_IHU_4_1, FCAN.FData);}
  void set_IHU_NavSpeedLimit(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_NavSpeedLimit_IHU_4_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_NavSpeedLimit, put = set_IHU_NavSpeedLimit)) double IHU_NavSpeedLimit;
  double get_IHU_NavSpeedLimitUnits(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_NavSpeedLimitUnits_IHU_4_1, FCAN.FData);}
  void set_IHU_NavSpeedLimitUnits(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_NavSpeedLimitUnits_IHU_4_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_NavSpeedLimitUnits, put = set_IHU_NavSpeedLimitUnits)) double IHU_NavSpeedLimitUnits;
  double get_IHU_NavCurrRoadType(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_NavCurrRoadType_IHU_4_1, FCAN.FData);}
  void set_IHU_NavCurrRoadType(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_NavCurrRoadType_IHU_4_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_NavCurrRoadType, put = set_IHU_NavCurrRoadType)) double IHU_NavCurrRoadType;
  void init() { FCAN = create().FCAN; }
  TIHU_4_1 create() { CANMsgDecl(_IHU_4_1, cIHU_4_1, 0, 0, 8, 944) return cIHU_4_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message IHU_5_1
extern const TCANSignal IHU_BrightnessLevel_IHU_5_1;
extern const TCANSignal IHU_VehiclePitchAngle_IHU_5_1;
extern const TCANSignal IHU_VehicleRollAngle_IHU_5_1;
extern const TCANSignal IHU_DVSts_IHU_5_1;
extern const TCANSignal IHU_VideoSts_IHU_5_1;
extern const TCANSignal IHU_GPSErr_IHU_5_1;
extern const TCANSignal IHU_GPSAntennaShortCircuit_IHU_5_1;
extern const TCANSignal IHU_GPSAntennaTurnOff_IHU_5_1;
extern const TCANSignal IHU_GPSSatelliteNum_IHU_5_1;
extern const TCANSignal IHU_AudioMuteSts_IHU_5_1;
extern const TCANSignal IHU_IHUFaultSts_IHU_5_1;
extern const TCANSignal IHU_USBtoTboxConnectSts_IHU_5_1;
extern const TCANSignal IHU_CustomSw1Sts_IHU_5_1;
extern const TCANSignal IHU_CustomSw2Sts_IHU_5_1;
struct _IHU_5_1;
typedef struct _IHU_5_1 TIHU_5_1;
struct _IHU_5_1{
  TCAN FCAN;
  double get_IHU_BrightnessLevel(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_BrightnessLevel_IHU_5_1, FCAN.FData);}
  void set_IHU_BrightnessLevel(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_BrightnessLevel_IHU_5_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_BrightnessLevel, put = set_IHU_BrightnessLevel)) double IHU_BrightnessLevel;
  double get_IHU_VehiclePitchAngle(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_VehiclePitchAngle_IHU_5_1, FCAN.FData);}
  void set_IHU_VehiclePitchAngle(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_VehiclePitchAngle_IHU_5_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_VehiclePitchAngle, put = set_IHU_VehiclePitchAngle)) double IHU_VehiclePitchAngle;
  double get_IHU_VehicleRollAngle(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_VehicleRollAngle_IHU_5_1, FCAN.FData);}
  void set_IHU_VehicleRollAngle(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_VehicleRollAngle_IHU_5_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_VehicleRollAngle, put = set_IHU_VehicleRollAngle)) double IHU_VehicleRollAngle;
  double get_IHU_DVSts(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_DVSts_IHU_5_1, FCAN.FData);}
  void set_IHU_DVSts(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_DVSts_IHU_5_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_DVSts, put = set_IHU_DVSts)) double IHU_DVSts;
  double get_IHU_VideoSts(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_VideoSts_IHU_5_1, FCAN.FData);}
  void set_IHU_VideoSts(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_VideoSts_IHU_5_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_VideoSts, put = set_IHU_VideoSts)) double IHU_VideoSts;
  double get_IHU_GPSErr(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_GPSErr_IHU_5_1, FCAN.FData);}
  void set_IHU_GPSErr(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_GPSErr_IHU_5_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_GPSErr, put = set_IHU_GPSErr)) double IHU_GPSErr;
  double get_IHU_GPSAntennaShortCircuit(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_GPSAntennaShortCircuit_IHU_5_1, FCAN.FData);}
  void set_IHU_GPSAntennaShortCircuit(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_GPSAntennaShortCircuit_IHU_5_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_GPSAntennaShortCircuit, put = set_IHU_GPSAntennaShortCircuit)) double IHU_GPSAntennaShortCircuit;
  double get_IHU_GPSAntennaTurnOff(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_GPSAntennaTurnOff_IHU_5_1, FCAN.FData);}
  void set_IHU_GPSAntennaTurnOff(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_GPSAntennaTurnOff_IHU_5_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_GPSAntennaTurnOff, put = set_IHU_GPSAntennaTurnOff)) double IHU_GPSAntennaTurnOff;
  double get_IHU_GPSSatelliteNum(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_GPSSatelliteNum_IHU_5_1, FCAN.FData);}
  void set_IHU_GPSSatelliteNum(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_GPSSatelliteNum_IHU_5_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_GPSSatelliteNum, put = set_IHU_GPSSatelliteNum)) double IHU_GPSSatelliteNum;
  double get_IHU_AudioMuteSts(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_AudioMuteSts_IHU_5_1, FCAN.FData);}
  void set_IHU_AudioMuteSts(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_AudioMuteSts_IHU_5_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_AudioMuteSts, put = set_IHU_AudioMuteSts)) double IHU_AudioMuteSts;
  double get_IHU_IHUFaultSts(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_IHUFaultSts_IHU_5_1, FCAN.FData);}
  void set_IHU_IHUFaultSts(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_IHUFaultSts_IHU_5_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_IHUFaultSts, put = set_IHU_IHUFaultSts)) double IHU_IHUFaultSts;
  double get_IHU_USBtoTboxConnectSts(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_USBtoTboxConnectSts_IHU_5_1, FCAN.FData);}
  void set_IHU_USBtoTboxConnectSts(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_USBtoTboxConnectSts_IHU_5_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_USBtoTboxConnectSts, put = set_IHU_USBtoTboxConnectSts)) double IHU_USBtoTboxConnectSts;
  double get_IHU_CustomSw1Sts(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_CustomSw1Sts_IHU_5_1, FCAN.FData);}
  void set_IHU_CustomSw1Sts(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_CustomSw1Sts_IHU_5_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_CustomSw1Sts, put = set_IHU_CustomSw1Sts)) double IHU_CustomSw1Sts;
  double get_IHU_CustomSw2Sts(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_CustomSw2Sts_IHU_5_1, FCAN.FData);}
  void set_IHU_CustomSw2Sts(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_CustomSw2Sts_IHU_5_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_CustomSw2Sts, put = set_IHU_CustomSw2Sts)) double IHU_CustomSw2Sts;
  void init() { FCAN = create().FCAN; }
  TIHU_5_1 create() { CANMsgDecl(_IHU_5_1, cIHU_5_1, 0, 0, 8, 945) return cIHU_5_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message IHU_6_1
extern const TCANSignal IHU_WindowPosFLCmd_IHU_6_1;
extern const TCANSignal IHU_WindowPosFRCmd_IHU_6_1;
extern const TCANSignal IHU_WindowPosRLCmd_IHU_6_1;
extern const TCANSignal IHU_WindowPosRRCmd_IHU_6_1;
extern const TCANSignal IHU_SunroofCmd_IHU_6_1;
extern const TCANSignal IHU_BackMirrorFoldCmd_IHU_6_1;
struct _IHU_6_1;
typedef struct _IHU_6_1 TIHU_6_1;
struct _IHU_6_1{
  TCAN FCAN;
  double get_IHU_WindowPosFLCmd(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_WindowPosFLCmd_IHU_6_1, FCAN.FData);}
  void set_IHU_WindowPosFLCmd(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_WindowPosFLCmd_IHU_6_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_WindowPosFLCmd, put = set_IHU_WindowPosFLCmd)) double IHU_WindowPosFLCmd;
  double get_IHU_WindowPosFRCmd(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_WindowPosFRCmd_IHU_6_1, FCAN.FData);}
  void set_IHU_WindowPosFRCmd(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_WindowPosFRCmd_IHU_6_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_WindowPosFRCmd, put = set_IHU_WindowPosFRCmd)) double IHU_WindowPosFRCmd;
  double get_IHU_WindowPosRLCmd(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_WindowPosRLCmd_IHU_6_1, FCAN.FData);}
  void set_IHU_WindowPosRLCmd(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_WindowPosRLCmd_IHU_6_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_WindowPosRLCmd, put = set_IHU_WindowPosRLCmd)) double IHU_WindowPosRLCmd;
  double get_IHU_WindowPosRRCmd(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_WindowPosRRCmd_IHU_6_1, FCAN.FData);}
  void set_IHU_WindowPosRRCmd(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_WindowPosRRCmd_IHU_6_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_WindowPosRRCmd, put = set_IHU_WindowPosRRCmd)) double IHU_WindowPosRRCmd;
  double get_IHU_SunroofCmd(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_SunroofCmd_IHU_6_1, FCAN.FData);}
  void set_IHU_SunroofCmd(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_SunroofCmd_IHU_6_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_SunroofCmd, put = set_IHU_SunroofCmd)) double IHU_SunroofCmd;
  double get_IHU_BackMirrorFoldCmd(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_BackMirrorFoldCmd_IHU_6_1, FCAN.FData);}
  void set_IHU_BackMirrorFoldCmd(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_BackMirrorFoldCmd_IHU_6_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_BackMirrorFoldCmd, put = set_IHU_BackMirrorFoldCmd)) double IHU_BackMirrorFoldCmd;
  void init() { FCAN = create().FCAN; }
  TIHU_6_1 create() { CANMsgDecl(_IHU_6_1, cIHU_6_1, 0, 0, 8, 145) return cIHU_6_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message IHU_7_1
extern const TCANSignal IHU_GPSDataGroup_IHU_7_1;
extern const TCANSignal IHU_GPSDataType_IHU_7_1;
extern const TCANSignal IHU_GPSPositioningSts_IHU_7_1;
extern const TCANSignal IHU_GPSviaGPS_IHU_7_1;
extern const TCANSignal IHU_GPSviaBeidou_IHU_7_1;
extern const TCANSignal IHU_GPSviaGLONASS_IHU_7_1;
extern const TCANSignal IHU_GPSviaGALILEO_IHU_7_1;
extern const TCANSignal IHU_GPSAltitude_IHU_7_1;
extern const TCANSignal IHU_GPSLatitudeDirection_IHU_7_1;
extern const TCANSignal IHU_GPSLatitude_IHU_7_1;
struct _IHU_7_1;
typedef struct _IHU_7_1 TIHU_7_1;
struct _IHU_7_1{
  TCAN FCAN;
  double get_IHU_GPSDataGroup(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_GPSDataGroup_IHU_7_1, FCAN.FData);}
  void set_IHU_GPSDataGroup(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_GPSDataGroup_IHU_7_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_GPSDataGroup, put = set_IHU_GPSDataGroup)) double IHU_GPSDataGroup;
  double get_IHU_GPSDataType(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_GPSDataType_IHU_7_1, FCAN.FData);}
  void set_IHU_GPSDataType(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_GPSDataType_IHU_7_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_GPSDataType, put = set_IHU_GPSDataType)) double IHU_GPSDataType;
  double get_IHU_GPSPositioningSts(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_GPSPositioningSts_IHU_7_1, FCAN.FData);}
  void set_IHU_GPSPositioningSts(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_GPSPositioningSts_IHU_7_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_GPSPositioningSts, put = set_IHU_GPSPositioningSts)) double IHU_GPSPositioningSts;
  double get_IHU_GPSviaGPS(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_GPSviaGPS_IHU_7_1, FCAN.FData);}
  void set_IHU_GPSviaGPS(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_GPSviaGPS_IHU_7_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_GPSviaGPS, put = set_IHU_GPSviaGPS)) double IHU_GPSviaGPS;
  double get_IHU_GPSviaBeidou(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_GPSviaBeidou_IHU_7_1, FCAN.FData);}
  void set_IHU_GPSviaBeidou(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_GPSviaBeidou_IHU_7_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_GPSviaBeidou, put = set_IHU_GPSviaBeidou)) double IHU_GPSviaBeidou;
  double get_IHU_GPSviaGLONASS(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_GPSviaGLONASS_IHU_7_1, FCAN.FData);}
  void set_IHU_GPSviaGLONASS(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_GPSviaGLONASS_IHU_7_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_GPSviaGLONASS, put = set_IHU_GPSviaGLONASS)) double IHU_GPSviaGLONASS;
  double get_IHU_GPSviaGALILEO(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_GPSviaGALILEO_IHU_7_1, FCAN.FData);}
  void set_IHU_GPSviaGALILEO(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_GPSviaGALILEO_IHU_7_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_GPSviaGALILEO, put = set_IHU_GPSviaGALILEO)) double IHU_GPSviaGALILEO;
  double get_IHU_GPSAltitude(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_GPSAltitude_IHU_7_1, FCAN.FData);}
  void set_IHU_GPSAltitude(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_GPSAltitude_IHU_7_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_GPSAltitude, put = set_IHU_GPSAltitude)) double IHU_GPSAltitude;
  double get_IHU_GPSLatitudeDirection(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_GPSLatitudeDirection_IHU_7_1, FCAN.FData);}
  void set_IHU_GPSLatitudeDirection(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_GPSLatitudeDirection_IHU_7_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_GPSLatitudeDirection, put = set_IHU_GPSLatitudeDirection)) double IHU_GPSLatitudeDirection;
  double get_IHU_GPSLatitude(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_GPSLatitude_IHU_7_1, FCAN.FData);}
  void set_IHU_GPSLatitude(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_GPSLatitude_IHU_7_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_GPSLatitude, put = set_IHU_GPSLatitude)) double IHU_GPSLatitude;
  void init() { FCAN = create().FCAN; }
  TIHU_7_1 create() { CANMsgDecl(_IHU_7_1, cIHU_7_1, 0, 0, 8, 1408) return cIHU_7_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message IHU_8_1
extern const TCANSignal IHU_GPSDataGroup_IHU_8_1;
extern const TCANSignal IHU_GPSDataType_IHU_8_1;
extern const TCANSignal IHU_GPSLongitudeDirection_IHU_8_1;
extern const TCANSignal IHU_GPSLongitude_IHU_8_1;
extern const TCANSignal IHU_GPSVehicleDirection_IHU_8_1;
extern const TCANSignal IHU_GPSVehicleSpeed_IHU_8_1;
struct _IHU_8_1;
typedef struct _IHU_8_1 TIHU_8_1;
struct _IHU_8_1{
  TCAN FCAN;
  double get_IHU_GPSDataGroup(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_GPSDataGroup_IHU_8_1, FCAN.FData);}
  void set_IHU_GPSDataGroup(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_GPSDataGroup_IHU_8_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_GPSDataGroup, put = set_IHU_GPSDataGroup)) double IHU_GPSDataGroup;
  double get_IHU_GPSDataType(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_GPSDataType_IHU_8_1, FCAN.FData);}
  void set_IHU_GPSDataType(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_GPSDataType_IHU_8_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_GPSDataType, put = set_IHU_GPSDataType)) double IHU_GPSDataType;
  double get_IHU_GPSLongitudeDirection(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_GPSLongitudeDirection_IHU_8_1, FCAN.FData);}
  void set_IHU_GPSLongitudeDirection(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_GPSLongitudeDirection_IHU_8_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_GPSLongitudeDirection, put = set_IHU_GPSLongitudeDirection)) double IHU_GPSLongitudeDirection;
  double get_IHU_GPSLongitude(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_GPSLongitude_IHU_8_1, FCAN.FData);}
  void set_IHU_GPSLongitude(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_GPSLongitude_IHU_8_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_GPSLongitude, put = set_IHU_GPSLongitude)) double IHU_GPSLongitude;
  double get_IHU_GPSVehicleDirection(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_GPSVehicleDirection_IHU_8_1, FCAN.FData);}
  void set_IHU_GPSVehicleDirection(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_GPSVehicleDirection_IHU_8_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_GPSVehicleDirection, put = set_IHU_GPSVehicleDirection)) double IHU_GPSVehicleDirection;
  double get_IHU_GPSVehicleSpeed(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_GPSVehicleSpeed_IHU_8_1, FCAN.FData);}
  void set_IHU_GPSVehicleSpeed(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_GPSVehicleSpeed_IHU_8_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_GPSVehicleSpeed, put = set_IHU_GPSVehicleSpeed)) double IHU_GPSVehicleSpeed;
  void init() { FCAN = create().FCAN; }
  TIHU_8_1 create() { CANMsgDecl(_IHU_8_1, cIHU_8_1, 0, 0, 8, 1409) return cIHU_8_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message IHU_9_1
extern const TCANSignal IHU_GPSDataGroup_IHU_9_1;
extern const TCANSignal IHU_GPSDataType_IHU_9_1;
extern const TCANSignal IHU_GPSTime_IHU_9_1;
struct _IHU_9_1;
typedef struct _IHU_9_1 TIHU_9_1;
struct _IHU_9_1{
  TCAN FCAN;
  double get_IHU_GPSDataGroup(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_GPSDataGroup_IHU_9_1, FCAN.FData);}
  void set_IHU_GPSDataGroup(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_GPSDataGroup_IHU_9_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_GPSDataGroup, put = set_IHU_GPSDataGroup)) double IHU_GPSDataGroup;
  double get_IHU_GPSDataType(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_GPSDataType_IHU_9_1, FCAN.FData);}
  void set_IHU_GPSDataType(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_GPSDataType_IHU_9_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_GPSDataType, put = set_IHU_GPSDataType)) double IHU_GPSDataType;
  double get_IHU_GPSTime(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_GPSTime_IHU_9_1, FCAN.FData);}
  void set_IHU_GPSTime(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_GPSTime_IHU_9_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_GPSTime, put = set_IHU_GPSTime)) double IHU_GPSTime;
  void init() { FCAN = create().FCAN; }
  TIHU_9_1 create() { CANMsgDecl(_IHU_9_1, cIHU_9_1, 0, 0, 8, 1410) return cIHU_9_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message IHU_10_1
extern const TCANSignal IHU_AmbientLightSwtSet_IHU_10_1;
extern const TCANSignal IHU_AmbientLightLvlSet_IHU_10_1;
extern const TCANSignal IHU_ACMaxSwtSet_IHU_10_1;
extern const TCANSignal IHU_SteeringWheelHeatingSWSet_IHU_10_1;
extern const TCANSignal IHU_AVASSwtSet_IHU_10_1;
extern const TCANSignal IHU_FLSeatVentLvlSet_IHU_10_1;
extern const TCANSignal IHU_AVASSoundTypSet_IHU_10_1;
extern const TCANSignal IHU_FRSeatVentLvlSet_IHU_10_1;
extern const TCANSignal IHU_RAEBSwtSet_IHU_10_1;
extern const TCANSignal IHU_RadarSwtSet_IHU_10_1;
struct _IHU_10_1;
typedef struct _IHU_10_1 TIHU_10_1;
struct _IHU_10_1{
  TCAN FCAN;
  double get_IHU_AmbientLightSwtSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_AmbientLightSwtSet_IHU_10_1, FCAN.FData);}
  void set_IHU_AmbientLightSwtSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_AmbientLightSwtSet_IHU_10_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_AmbientLightSwtSet, put = set_IHU_AmbientLightSwtSet)) double IHU_AmbientLightSwtSet;
  double get_IHU_AmbientLightLvlSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_AmbientLightLvlSet_IHU_10_1, FCAN.FData);}
  void set_IHU_AmbientLightLvlSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_AmbientLightLvlSet_IHU_10_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_AmbientLightLvlSet, put = set_IHU_AmbientLightLvlSet)) double IHU_AmbientLightLvlSet;
  double get_IHU_ACMaxSwtSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_ACMaxSwtSet_IHU_10_1, FCAN.FData);}
  void set_IHU_ACMaxSwtSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_ACMaxSwtSet_IHU_10_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_ACMaxSwtSet, put = set_IHU_ACMaxSwtSet)) double IHU_ACMaxSwtSet;
  double get_IHU_SteeringWheelHeatingSWSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_SteeringWheelHeatingSWSet_IHU_10_1, FCAN.FData);}
  void set_IHU_SteeringWheelHeatingSWSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_SteeringWheelHeatingSWSet_IHU_10_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_SteeringWheelHeatingSWSet, put = set_IHU_SteeringWheelHeatingSWSet)) double IHU_SteeringWheelHeatingSWSet;
  double get_IHU_AVASSwtSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_AVASSwtSet_IHU_10_1, FCAN.FData);}
  void set_IHU_AVASSwtSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_AVASSwtSet_IHU_10_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_AVASSwtSet, put = set_IHU_AVASSwtSet)) double IHU_AVASSwtSet;
  double get_IHU_FLSeatVentLvlSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_FLSeatVentLvlSet_IHU_10_1, FCAN.FData);}
  void set_IHU_FLSeatVentLvlSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_FLSeatVentLvlSet_IHU_10_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_FLSeatVentLvlSet, put = set_IHU_FLSeatVentLvlSet)) double IHU_FLSeatVentLvlSet;
  double get_IHU_AVASSoundTypSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_AVASSoundTypSet_IHU_10_1, FCAN.FData);}
  void set_IHU_AVASSoundTypSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_AVASSoundTypSet_IHU_10_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_AVASSoundTypSet, put = set_IHU_AVASSoundTypSet)) double IHU_AVASSoundTypSet;
  double get_IHU_FRSeatVentLvlSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_FRSeatVentLvlSet_IHU_10_1, FCAN.FData);}
  void set_IHU_FRSeatVentLvlSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_FRSeatVentLvlSet_IHU_10_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_FRSeatVentLvlSet, put = set_IHU_FRSeatVentLvlSet)) double IHU_FRSeatVentLvlSet;
  double get_IHU_RAEBSwtSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_RAEBSwtSet_IHU_10_1, FCAN.FData);}
  void set_IHU_RAEBSwtSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_RAEBSwtSet_IHU_10_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_RAEBSwtSet, put = set_IHU_RAEBSwtSet)) double IHU_RAEBSwtSet;
  double get_IHU_RadarSwtSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_RadarSwtSet_IHU_10_1, FCAN.FData);}
  void set_IHU_RadarSwtSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_RadarSwtSet_IHU_10_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_RadarSwtSet, put = set_IHU_RadarSwtSet)) double IHU_RadarSwtSet;
  void init() { FCAN = create().FCAN; }
  TIHU_10_1 create() { CANMsgDecl(_IHU_10_1, cIHU_10_1, 0, 0, 8, 146) return cIHU_10_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message IHU_11_1
extern const TCANSignal IHU_VDCSwtSet_IHU_11_1;
extern const TCANSignal IHU_TCSSwtSet_IHU_11_1;
extern const TCANSignal IHU_CSTSwtSet_IHU_11_1;
extern const TCANSignal IHU_SOCHoldHEVSwtSet_IHU_11_1;
extern const TCANSignal IHU_SOCHoldHEVTgtSOCSet_IHU_11_1;
extern const TCANSignal IHU_GearPGenerationReq_IHU_11_1;
extern const TCANSignal IHU_GearPGenerationTgtSOCSet_IHU_11_1;
extern const TCANSignal IHU_GearPGenerationPwLvlSet_IHU_11_1;
extern const TCANSignal IHU_HYBModReq_IHU_11_1;
extern const TCANSignal IHU_V2LSwtSet_IHU_11_1;
extern const TCANSignal VCU_V2LLowSOCStrtSwtSet_IHU_11_1;
extern const TCANSignal IHU_BrakeAssistModeSet_IHU_11_1;
extern const TCANSignal IHU_V2VSwtSet_IHU_11_1;
extern const TCANSignal IHU_CoastdwnRegDepthLvlSet_IHU_11_1;
struct _IHU_11_1;
typedef struct _IHU_11_1 TIHU_11_1;
struct _IHU_11_1{
  TCAN FCAN;
  double get_IHU_VDCSwtSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_VDCSwtSet_IHU_11_1, FCAN.FData);}
  void set_IHU_VDCSwtSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_VDCSwtSet_IHU_11_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_VDCSwtSet, put = set_IHU_VDCSwtSet)) double IHU_VDCSwtSet;
  double get_IHU_TCSSwtSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_TCSSwtSet_IHU_11_1, FCAN.FData);}
  void set_IHU_TCSSwtSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_TCSSwtSet_IHU_11_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_TCSSwtSet, put = set_IHU_TCSSwtSet)) double IHU_TCSSwtSet;
  double get_IHU_CSTSwtSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_CSTSwtSet_IHU_11_1, FCAN.FData);}
  void set_IHU_CSTSwtSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_CSTSwtSet_IHU_11_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_CSTSwtSet, put = set_IHU_CSTSwtSet)) double IHU_CSTSwtSet;
  double get_IHU_SOCHoldHEVSwtSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_SOCHoldHEVSwtSet_IHU_11_1, FCAN.FData);}
  void set_IHU_SOCHoldHEVSwtSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_SOCHoldHEVSwtSet_IHU_11_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_SOCHoldHEVSwtSet, put = set_IHU_SOCHoldHEVSwtSet)) double IHU_SOCHoldHEVSwtSet;
  double get_IHU_SOCHoldHEVTgtSOCSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_SOCHoldHEVTgtSOCSet_IHU_11_1, FCAN.FData);}
  void set_IHU_SOCHoldHEVTgtSOCSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_SOCHoldHEVTgtSOCSet_IHU_11_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_SOCHoldHEVTgtSOCSet, put = set_IHU_SOCHoldHEVTgtSOCSet)) double IHU_SOCHoldHEVTgtSOCSet;
  double get_IHU_GearPGenerationReq(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_GearPGenerationReq_IHU_11_1, FCAN.FData);}
  void set_IHU_GearPGenerationReq(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_GearPGenerationReq_IHU_11_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_GearPGenerationReq, put = set_IHU_GearPGenerationReq)) double IHU_GearPGenerationReq;
  double get_IHU_GearPGenerationTgtSOCSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_GearPGenerationTgtSOCSet_IHU_11_1, FCAN.FData);}
  void set_IHU_GearPGenerationTgtSOCSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_GearPGenerationTgtSOCSet_IHU_11_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_GearPGenerationTgtSOCSet, put = set_IHU_GearPGenerationTgtSOCSet)) double IHU_GearPGenerationTgtSOCSet;
  double get_IHU_GearPGenerationPwLvlSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_GearPGenerationPwLvlSet_IHU_11_1, FCAN.FData);}
  void set_IHU_GearPGenerationPwLvlSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_GearPGenerationPwLvlSet_IHU_11_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_GearPGenerationPwLvlSet, put = set_IHU_GearPGenerationPwLvlSet)) double IHU_GearPGenerationPwLvlSet;
  double get_IHU_HYBModReq(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_HYBModReq_IHU_11_1, FCAN.FData);}
  void set_IHU_HYBModReq(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_HYBModReq_IHU_11_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_HYBModReq, put = set_IHU_HYBModReq)) double IHU_HYBModReq;
  double get_IHU_V2LSwtSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_V2LSwtSet_IHU_11_1, FCAN.FData);}
  void set_IHU_V2LSwtSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_V2LSwtSet_IHU_11_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_V2LSwtSet, put = set_IHU_V2LSwtSet)) double IHU_V2LSwtSet;
  double get_VCU_V2LLowSOCStrtSwtSet(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_V2LLowSOCStrtSwtSet_IHU_11_1, FCAN.FData);}
  void set_VCU_V2LLowSOCStrtSwtSet(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_V2LLowSOCStrtSwtSet_IHU_11_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_V2LLowSOCStrtSwtSet, put = set_VCU_V2LLowSOCStrtSwtSet)) double VCU_V2LLowSOCStrtSwtSet;
  double get_IHU_BrakeAssistModeSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_BrakeAssistModeSet_IHU_11_1, FCAN.FData);}
  void set_IHU_BrakeAssistModeSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_BrakeAssistModeSet_IHU_11_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_BrakeAssistModeSet, put = set_IHU_BrakeAssistModeSet)) double IHU_BrakeAssistModeSet;
  double get_IHU_V2VSwtSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_V2VSwtSet_IHU_11_1, FCAN.FData);}
  void set_IHU_V2VSwtSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_V2VSwtSet_IHU_11_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_V2VSwtSet, put = set_IHU_V2VSwtSet)) double IHU_V2VSwtSet;
  double get_IHU_CoastdwnRegDepthLvlSet(void) { return com.get_can_signal_value((TCANSignal* const)&IHU_CoastdwnRegDepthLvlSet_IHU_11_1, FCAN.FData);}
  void set_IHU_CoastdwnRegDepthLvlSet(const double value) { com.set_can_signal_value((TCANSignal* const)&IHU_CoastdwnRegDepthLvlSet_IHU_11_1, FCAN.FData, value);}
  __declspec(property(get = get_IHU_CoastdwnRegDepthLvlSet, put = set_IHU_CoastdwnRegDepthLvlSet)) double IHU_CoastdwnRegDepthLvlSet;
  void init() { FCAN = create().FCAN; }
  TIHU_11_1 create() { CANMsgDecl(_IHU_11_1, cIHU_11_1, 0, 0, 8, 147) return cIHU_11_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message AVAS_1_1
extern const TCANSignal AVAS_SwtSts_AVAS_1_1;
extern const TCANSignal AVAS_SoundTypSts_AVAS_1_1;
struct _AVAS_1_1;
typedef struct _AVAS_1_1 TAVAS_1_1;
struct _AVAS_1_1{
  TCAN FCAN;
  double get_AVAS_SwtSts(void) { return com.get_can_signal_value((TCANSignal* const)&AVAS_SwtSts_AVAS_1_1, FCAN.FData);}
  void set_AVAS_SwtSts(const double value) { com.set_can_signal_value((TCANSignal* const)&AVAS_SwtSts_AVAS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_AVAS_SwtSts, put = set_AVAS_SwtSts)) double AVAS_SwtSts;
  double get_AVAS_SoundTypSts(void) { return com.get_can_signal_value((TCANSignal* const)&AVAS_SoundTypSts_AVAS_1_1, FCAN.FData);}
  void set_AVAS_SoundTypSts(const double value) { com.set_can_signal_value((TCANSignal* const)&AVAS_SoundTypSts_AVAS_1_1, FCAN.FData, value);}
  __declspec(property(get = get_AVAS_SoundTypSts, put = set_AVAS_SoundTypSts)) double AVAS_SoundTypSts;
  void init() { FCAN = create().FCAN; }
  TAVAS_1_1 create() { CANMsgDecl(_AVAS_1_1, cAVAS_1_1, 0, 0, 8, 1388) return cAVAS_1_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message PDC_1_1
extern const TCANSignal PDC_RadarFailSts_PDC_1_1;
extern const TCANSignal PDC_RadarSwtSts_PDC_1_1;
extern const TCANSignal PDC_AudibleBeepRate_PDC_1_1;
extern const TCANSignal PDC_LRSensorDistance_PDC_1_1;
extern const TCANSignal PDC_LMRSensorDistance_PDC_1_1;
extern const TCANSignal PDC_RRSensorDistance_PDC_1_1;
extern const TCANSignal PDC_RMRSensorDistance_PDC_1_1;
extern const TCANSignal PDC_LFSensorDistance_PDC_1_1;
extern const TCANSignal PDC_RMFSensorDistance_PDC_1_1;
extern const TCANSignal PDC_LMFSensorDistance_PDC_1_1;
extern const TCANSignal PDC_RadarWorkSts_PDC_1_1;
extern const TCANSignal PDC_RFSensorDistance_PDC_1_1;
struct _PDC_1_1;
typedef struct _PDC_1_1 TPDC_1_1;
struct _PDC_1_1{
  TCAN FCAN;
  double get_PDC_RadarFailSts(void) { return com.get_can_signal_value((TCANSignal* const)&PDC_RadarFailSts_PDC_1_1, FCAN.FData);}
  void set_PDC_RadarFailSts(const double value) { com.set_can_signal_value((TCANSignal* const)&PDC_RadarFailSts_PDC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_PDC_RadarFailSts, put = set_PDC_RadarFailSts)) double PDC_RadarFailSts;
  double get_PDC_RadarSwtSts(void) { return com.get_can_signal_value((TCANSignal* const)&PDC_RadarSwtSts_PDC_1_1, FCAN.FData);}
  void set_PDC_RadarSwtSts(const double value) { com.set_can_signal_value((TCANSignal* const)&PDC_RadarSwtSts_PDC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_PDC_RadarSwtSts, put = set_PDC_RadarSwtSts)) double PDC_RadarSwtSts;
  double get_PDC_AudibleBeepRate(void) { return com.get_can_signal_value((TCANSignal* const)&PDC_AudibleBeepRate_PDC_1_1, FCAN.FData);}
  void set_PDC_AudibleBeepRate(const double value) { com.set_can_signal_value((TCANSignal* const)&PDC_AudibleBeepRate_PDC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_PDC_AudibleBeepRate, put = set_PDC_AudibleBeepRate)) double PDC_AudibleBeepRate;
  double get_PDC_LRSensorDistance(void) { return com.get_can_signal_value((TCANSignal* const)&PDC_LRSensorDistance_PDC_1_1, FCAN.FData);}
  void set_PDC_LRSensorDistance(const double value) { com.set_can_signal_value((TCANSignal* const)&PDC_LRSensorDistance_PDC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_PDC_LRSensorDistance, put = set_PDC_LRSensorDistance)) double PDC_LRSensorDistance;
  double get_PDC_LMRSensorDistance(void) { return com.get_can_signal_value((TCANSignal* const)&PDC_LMRSensorDistance_PDC_1_1, FCAN.FData);}
  void set_PDC_LMRSensorDistance(const double value) { com.set_can_signal_value((TCANSignal* const)&PDC_LMRSensorDistance_PDC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_PDC_LMRSensorDistance, put = set_PDC_LMRSensorDistance)) double PDC_LMRSensorDistance;
  double get_PDC_RRSensorDistance(void) { return com.get_can_signal_value((TCANSignal* const)&PDC_RRSensorDistance_PDC_1_1, FCAN.FData);}
  void set_PDC_RRSensorDistance(const double value) { com.set_can_signal_value((TCANSignal* const)&PDC_RRSensorDistance_PDC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_PDC_RRSensorDistance, put = set_PDC_RRSensorDistance)) double PDC_RRSensorDistance;
  double get_PDC_RMRSensorDistance(void) { return com.get_can_signal_value((TCANSignal* const)&PDC_RMRSensorDistance_PDC_1_1, FCAN.FData);}
  void set_PDC_RMRSensorDistance(const double value) { com.set_can_signal_value((TCANSignal* const)&PDC_RMRSensorDistance_PDC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_PDC_RMRSensorDistance, put = set_PDC_RMRSensorDistance)) double PDC_RMRSensorDistance;
  double get_PDC_LFSensorDistance(void) { return com.get_can_signal_value((TCANSignal* const)&PDC_LFSensorDistance_PDC_1_1, FCAN.FData);}
  void set_PDC_LFSensorDistance(const double value) { com.set_can_signal_value((TCANSignal* const)&PDC_LFSensorDistance_PDC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_PDC_LFSensorDistance, put = set_PDC_LFSensorDistance)) double PDC_LFSensorDistance;
  double get_PDC_RMFSensorDistance(void) { return com.get_can_signal_value((TCANSignal* const)&PDC_RMFSensorDistance_PDC_1_1, FCAN.FData);}
  void set_PDC_RMFSensorDistance(const double value) { com.set_can_signal_value((TCANSignal* const)&PDC_RMFSensorDistance_PDC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_PDC_RMFSensorDistance, put = set_PDC_RMFSensorDistance)) double PDC_RMFSensorDistance;
  double get_PDC_LMFSensorDistance(void) { return com.get_can_signal_value((TCANSignal* const)&PDC_LMFSensorDistance_PDC_1_1, FCAN.FData);}
  void set_PDC_LMFSensorDistance(const double value) { com.set_can_signal_value((TCANSignal* const)&PDC_LMFSensorDistance_PDC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_PDC_LMFSensorDistance, put = set_PDC_LMFSensorDistance)) double PDC_LMFSensorDistance;
  double get_PDC_RadarWorkSts(void) { return com.get_can_signal_value((TCANSignal* const)&PDC_RadarWorkSts_PDC_1_1, FCAN.FData);}
  void set_PDC_RadarWorkSts(const double value) { com.set_can_signal_value((TCANSignal* const)&PDC_RadarWorkSts_PDC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_PDC_RadarWorkSts, put = set_PDC_RadarWorkSts)) double PDC_RadarWorkSts;
  double get_PDC_RFSensorDistance(void) { return com.get_can_signal_value((TCANSignal* const)&PDC_RFSensorDistance_PDC_1_1, FCAN.FData);}
  void set_PDC_RFSensorDistance(const double value) { com.set_can_signal_value((TCANSignal* const)&PDC_RFSensorDistance_PDC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_PDC_RFSensorDistance, put = set_PDC_RFSensorDistance)) double PDC_RFSensorDistance;
  void init() { FCAN = create().FCAN; }
  TPDC_1_1 create() { CANMsgDecl(_PDC_1_1, cPDC_1_1, 0, 0, 8, 936) return cPDC_1_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message PDC_2_1
extern const TCANSignal PDC_RearObjectDistance_PDC_2_1;
extern const TCANSignal PDC_FrontObjectDistance_PDC_2_1;
struct _PDC_2_1;
typedef struct _PDC_2_1 TPDC_2_1;
struct _PDC_2_1{
  TCAN FCAN;
  double get_PDC_RearObjectDistance(void) { return com.get_can_signal_value((TCANSignal* const)&PDC_RearObjectDistance_PDC_2_1, FCAN.FData);}
  void set_PDC_RearObjectDistance(const double value) { com.set_can_signal_value((TCANSignal* const)&PDC_RearObjectDistance_PDC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_PDC_RearObjectDistance, put = set_PDC_RearObjectDistance)) double PDC_RearObjectDistance;
  double get_PDC_FrontObjectDistance(void) { return com.get_can_signal_value((TCANSignal* const)&PDC_FrontObjectDistance_PDC_2_1, FCAN.FData);}
  void set_PDC_FrontObjectDistance(const double value) { com.set_can_signal_value((TCANSignal* const)&PDC_FrontObjectDistance_PDC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_PDC_FrontObjectDistance, put = set_PDC_FrontObjectDistance)) double PDC_FrontObjectDistance;
  void init() { FCAN = create().FCAN; }
  TPDC_2_1 create() { CANMsgDecl(_PDC_2_1, cPDC_2_1, 0, 0, 8, 937) return cPDC_2_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message TBOX_1_1
extern const TCANSignal TBOX_DateTimeSecond_TBOX_1_1;
extern const TCANSignal TBOX_DateTimeMinute_TBOX_1_1;
extern const TCANSignal TBOX_DateTimeHour_TBOX_1_1;
extern const TCANSignal TBOX_DateTimeDay_TBOX_1_1;
extern const TCANSignal TBOX_DateTimeMonth_TBOX_1_1;
extern const TCANSignal TBOX_DateTimeYear_TBOX_1_1;
extern const TCANSignal TBOX_BatteryErr_TBOX_1_1;
extern const TCANSignal TBOX_PowerOverSuply_TBOX_1_1;
extern const TCANSignal TBOX_BatteryUseUp_TBOX_1_1;
extern const TCANSignal TBOX_GSMErr_TBOX_1_1;
extern const TCANSignal TBOX_SIMErr_TBOX_1_1;
extern const TCANSignal TBOX_GPSErr_TBOX_1_1;
extern const TCANSignal TBOX_GPSAntennaShortCircuit_TBOX_1_1;
extern const TCANSignal TBOX_GPSAntennaTurnOff_TBOX_1_1;
extern const TCANSignal TBOX_ExternalMemoryErr_TBOX_1_1;
extern const TCANSignal TBOX_TempretureHigh_TBOX_1_1;
extern const TCANSignal TBOX_CANErr_TBOX_1_1;
struct _TBOX_1_1;
typedef struct _TBOX_1_1 TTBOX_1_1;
struct _TBOX_1_1{
  TCAN FCAN;
  double get_TBOX_DateTimeSecond(void) { return com.get_can_signal_value((TCANSignal* const)&TBOX_DateTimeSecond_TBOX_1_1, FCAN.FData);}
  void set_TBOX_DateTimeSecond(const double value) { com.set_can_signal_value((TCANSignal* const)&TBOX_DateTimeSecond_TBOX_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TBOX_DateTimeSecond, put = set_TBOX_DateTimeSecond)) double TBOX_DateTimeSecond;
  double get_TBOX_DateTimeMinute(void) { return com.get_can_signal_value((TCANSignal* const)&TBOX_DateTimeMinute_TBOX_1_1, FCAN.FData);}
  void set_TBOX_DateTimeMinute(const double value) { com.set_can_signal_value((TCANSignal* const)&TBOX_DateTimeMinute_TBOX_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TBOX_DateTimeMinute, put = set_TBOX_DateTimeMinute)) double TBOX_DateTimeMinute;
  double get_TBOX_DateTimeHour(void) { return com.get_can_signal_value((TCANSignal* const)&TBOX_DateTimeHour_TBOX_1_1, FCAN.FData);}
  void set_TBOX_DateTimeHour(const double value) { com.set_can_signal_value((TCANSignal* const)&TBOX_DateTimeHour_TBOX_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TBOX_DateTimeHour, put = set_TBOX_DateTimeHour)) double TBOX_DateTimeHour;
  double get_TBOX_DateTimeDay(void) { return com.get_can_signal_value((TCANSignal* const)&TBOX_DateTimeDay_TBOX_1_1, FCAN.FData);}
  void set_TBOX_DateTimeDay(const double value) { com.set_can_signal_value((TCANSignal* const)&TBOX_DateTimeDay_TBOX_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TBOX_DateTimeDay, put = set_TBOX_DateTimeDay)) double TBOX_DateTimeDay;
  double get_TBOX_DateTimeMonth(void) { return com.get_can_signal_value((TCANSignal* const)&TBOX_DateTimeMonth_TBOX_1_1, FCAN.FData);}
  void set_TBOX_DateTimeMonth(const double value) { com.set_can_signal_value((TCANSignal* const)&TBOX_DateTimeMonth_TBOX_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TBOX_DateTimeMonth, put = set_TBOX_DateTimeMonth)) double TBOX_DateTimeMonth;
  double get_TBOX_DateTimeYear(void) { return com.get_can_signal_value((TCANSignal* const)&TBOX_DateTimeYear_TBOX_1_1, FCAN.FData);}
  void set_TBOX_DateTimeYear(const double value) { com.set_can_signal_value((TCANSignal* const)&TBOX_DateTimeYear_TBOX_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TBOX_DateTimeYear, put = set_TBOX_DateTimeYear)) double TBOX_DateTimeYear;
  double get_TBOX_BatteryErr(void) { return com.get_can_signal_value((TCANSignal* const)&TBOX_BatteryErr_TBOX_1_1, FCAN.FData);}
  void set_TBOX_BatteryErr(const double value) { com.set_can_signal_value((TCANSignal* const)&TBOX_BatteryErr_TBOX_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TBOX_BatteryErr, put = set_TBOX_BatteryErr)) double TBOX_BatteryErr;
  double get_TBOX_PowerOverSuply(void) { return com.get_can_signal_value((TCANSignal* const)&TBOX_PowerOverSuply_TBOX_1_1, FCAN.FData);}
  void set_TBOX_PowerOverSuply(const double value) { com.set_can_signal_value((TCANSignal* const)&TBOX_PowerOverSuply_TBOX_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TBOX_PowerOverSuply, put = set_TBOX_PowerOverSuply)) double TBOX_PowerOverSuply;
  double get_TBOX_BatteryUseUp(void) { return com.get_can_signal_value((TCANSignal* const)&TBOX_BatteryUseUp_TBOX_1_1, FCAN.FData);}
  void set_TBOX_BatteryUseUp(const double value) { com.set_can_signal_value((TCANSignal* const)&TBOX_BatteryUseUp_TBOX_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TBOX_BatteryUseUp, put = set_TBOX_BatteryUseUp)) double TBOX_BatteryUseUp;
  double get_TBOX_GSMErr(void) { return com.get_can_signal_value((TCANSignal* const)&TBOX_GSMErr_TBOX_1_1, FCAN.FData);}
  void set_TBOX_GSMErr(const double value) { com.set_can_signal_value((TCANSignal* const)&TBOX_GSMErr_TBOX_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TBOX_GSMErr, put = set_TBOX_GSMErr)) double TBOX_GSMErr;
  double get_TBOX_SIMErr(void) { return com.get_can_signal_value((TCANSignal* const)&TBOX_SIMErr_TBOX_1_1, FCAN.FData);}
  void set_TBOX_SIMErr(const double value) { com.set_can_signal_value((TCANSignal* const)&TBOX_SIMErr_TBOX_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TBOX_SIMErr, put = set_TBOX_SIMErr)) double TBOX_SIMErr;
  double get_TBOX_GPSErr(void) { return com.get_can_signal_value((TCANSignal* const)&TBOX_GPSErr_TBOX_1_1, FCAN.FData);}
  void set_TBOX_GPSErr(const double value) { com.set_can_signal_value((TCANSignal* const)&TBOX_GPSErr_TBOX_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TBOX_GPSErr, put = set_TBOX_GPSErr)) double TBOX_GPSErr;
  double get_TBOX_GPSAntennaShortCircuit(void) { return com.get_can_signal_value((TCANSignal* const)&TBOX_GPSAntennaShortCircuit_TBOX_1_1, FCAN.FData);}
  void set_TBOX_GPSAntennaShortCircuit(const double value) { com.set_can_signal_value((TCANSignal* const)&TBOX_GPSAntennaShortCircuit_TBOX_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TBOX_GPSAntennaShortCircuit, put = set_TBOX_GPSAntennaShortCircuit)) double TBOX_GPSAntennaShortCircuit;
  double get_TBOX_GPSAntennaTurnOff(void) { return com.get_can_signal_value((TCANSignal* const)&TBOX_GPSAntennaTurnOff_TBOX_1_1, FCAN.FData);}
  void set_TBOX_GPSAntennaTurnOff(const double value) { com.set_can_signal_value((TCANSignal* const)&TBOX_GPSAntennaTurnOff_TBOX_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TBOX_GPSAntennaTurnOff, put = set_TBOX_GPSAntennaTurnOff)) double TBOX_GPSAntennaTurnOff;
  double get_TBOX_ExternalMemoryErr(void) { return com.get_can_signal_value((TCANSignal* const)&TBOX_ExternalMemoryErr_TBOX_1_1, FCAN.FData);}
  void set_TBOX_ExternalMemoryErr(const double value) { com.set_can_signal_value((TCANSignal* const)&TBOX_ExternalMemoryErr_TBOX_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TBOX_ExternalMemoryErr, put = set_TBOX_ExternalMemoryErr)) double TBOX_ExternalMemoryErr;
  double get_TBOX_TempretureHigh(void) { return com.get_can_signal_value((TCANSignal* const)&TBOX_TempretureHigh_TBOX_1_1, FCAN.FData);}
  void set_TBOX_TempretureHigh(const double value) { com.set_can_signal_value((TCANSignal* const)&TBOX_TempretureHigh_TBOX_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TBOX_TempretureHigh, put = set_TBOX_TempretureHigh)) double TBOX_TempretureHigh;
  double get_TBOX_CANErr(void) { return com.get_can_signal_value((TCANSignal* const)&TBOX_CANErr_TBOX_1_1, FCAN.FData);}
  void set_TBOX_CANErr(const double value) { com.set_can_signal_value((TCANSignal* const)&TBOX_CANErr_TBOX_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TBOX_CANErr, put = set_TBOX_CANErr)) double TBOX_CANErr;
  void init() { FCAN = create().FCAN; }
  TTBOX_1_1 create() { CANMsgDecl(_TBOX_1_1, cTBOX_1_1, 0, 0, 8, 1432) return cTBOX_1_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message TBOX_2_1
extern const TCANSignal TBOX_CommSignalVail_TBOX_2_1;
extern const TCANSignal TBOX_EcallStatus_TBOX_2_1;
extern const TCANSignal TBOX_EcallErr_TBOX_2_1;
struct _TBOX_2_1;
typedef struct _TBOX_2_1 TTBOX_2_1;
struct _TBOX_2_1{
  TCAN FCAN;
  double get_TBOX_CommSignalVail(void) { return com.get_can_signal_value((TCANSignal* const)&TBOX_CommSignalVail_TBOX_2_1, FCAN.FData);}
  void set_TBOX_CommSignalVail(const double value) { com.set_can_signal_value((TCANSignal* const)&TBOX_CommSignalVail_TBOX_2_1, FCAN.FData, value);}
  __declspec(property(get = get_TBOX_CommSignalVail, put = set_TBOX_CommSignalVail)) double TBOX_CommSignalVail;
  double get_TBOX_EcallStatus(void) { return com.get_can_signal_value((TCANSignal* const)&TBOX_EcallStatus_TBOX_2_1, FCAN.FData);}
  void set_TBOX_EcallStatus(const double value) { com.set_can_signal_value((TCANSignal* const)&TBOX_EcallStatus_TBOX_2_1, FCAN.FData, value);}
  __declspec(property(get = get_TBOX_EcallStatus, put = set_TBOX_EcallStatus)) double TBOX_EcallStatus;
  double get_TBOX_EcallErr(void) { return com.get_can_signal_value((TCANSignal* const)&TBOX_EcallErr_TBOX_2_1, FCAN.FData);}
  void set_TBOX_EcallErr(const double value) { com.set_can_signal_value((TCANSignal* const)&TBOX_EcallErr_TBOX_2_1, FCAN.FData, value);}
  __declspec(property(get = get_TBOX_EcallErr, put = set_TBOX_EcallErr)) double TBOX_EcallErr;
  void init() { FCAN = create().FCAN; }
  TTBOX_2_1 create() { CANMsgDecl(_TBOX_2_1, cTBOX_2_1, 0, 0, 8, 1433) return cTBOX_2_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message TBOX_4_1
extern const TCANSignal TBOX_AudioMuteRequest_TBOX_4_1;
struct _TBOX_4_1;
typedef struct _TBOX_4_1 TTBOX_4_1;
struct _TBOX_4_1{
  TCAN FCAN;
  double get_TBOX_AudioMuteRequest(void) { return com.get_can_signal_value((TCANSignal* const)&TBOX_AudioMuteRequest_TBOX_4_1, FCAN.FData);}
  void set_TBOX_AudioMuteRequest(const double value) { com.set_can_signal_value((TCANSignal* const)&TBOX_AudioMuteRequest_TBOX_4_1, FCAN.FData, value);}
  __declspec(property(get = get_TBOX_AudioMuteRequest, put = set_TBOX_AudioMuteRequest)) double TBOX_AudioMuteRequest;
  void init() { FCAN = create().FCAN; }
  TTBOX_4_1 create() { CANMsgDecl(_TBOX_4_1, cTBOX_4_1, 0, 0, 8, 791) return cTBOX_4_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message FCM_3_1
extern const TCANSignal FCM_AEBONOFFSts_FCM_3_1;
extern const TCANSignal FCM_AEBMode_FCM_3_1;
extern const TCANSignal FCM_FCWONOFFSts_FCM_3_1;
extern const TCANSignal FCM_FCWMode_FCM_3_1;
extern const TCANSignal FCM_FCWSnvtySts_FCM_3_1;
extern const TCANSignal FCM_DistanceWarning_FCM_3_1;
extern const TCANSignal FCM_FCWpreWarning_FCM_3_1;
extern const TCANSignal FCM_TimeGapSetICM_FCM_3_1;
extern const TCANSignal FCM_ACCMode_FCM_3_1;
extern const TCANSignal FCM_ACCTakeOverReq_FCM_3_1;
extern const TCANSignal FCM_ACCVSetDis_FCM_3_1;
extern const TCANSignal FCM_AEBTextInfo_FCM_3_1;
extern const TCANSignal FCM_ACCTextInfo_FCM_3_1;
extern const TCANSignal FCM_CameraTextInfo_FCM_3_1;
extern const TCANSignal FCM_DVMode_FCM_3_1;
struct _FCM_3_1;
typedef struct _FCM_3_1 TFCM_3_1;
struct _FCM_3_1{
  TCAN FCAN;
  double get_FCM_AEBONOFFSts(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_AEBONOFFSts_FCM_3_1, FCAN.FData);}
  void set_FCM_AEBONOFFSts(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_AEBONOFFSts_FCM_3_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_AEBONOFFSts, put = set_FCM_AEBONOFFSts)) double FCM_AEBONOFFSts;
  double get_FCM_AEBMode(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_AEBMode_FCM_3_1, FCAN.FData);}
  void set_FCM_AEBMode(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_AEBMode_FCM_3_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_AEBMode, put = set_FCM_AEBMode)) double FCM_AEBMode;
  double get_FCM_FCWONOFFSts(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_FCWONOFFSts_FCM_3_1, FCAN.FData);}
  void set_FCM_FCWONOFFSts(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_FCWONOFFSts_FCM_3_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_FCWONOFFSts, put = set_FCM_FCWONOFFSts)) double FCM_FCWONOFFSts;
  double get_FCM_FCWMode(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_FCWMode_FCM_3_1, FCAN.FData);}
  void set_FCM_FCWMode(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_FCWMode_FCM_3_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_FCWMode, put = set_FCM_FCWMode)) double FCM_FCWMode;
  double get_FCM_FCWSnvtySts(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_FCWSnvtySts_FCM_3_1, FCAN.FData);}
  void set_FCM_FCWSnvtySts(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_FCWSnvtySts_FCM_3_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_FCWSnvtySts, put = set_FCM_FCWSnvtySts)) double FCM_FCWSnvtySts;
  double get_FCM_DistanceWarning(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_DistanceWarning_FCM_3_1, FCAN.FData);}
  void set_FCM_DistanceWarning(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_DistanceWarning_FCM_3_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_DistanceWarning, put = set_FCM_DistanceWarning)) double FCM_DistanceWarning;
  double get_FCM_FCWpreWarning(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_FCWpreWarning_FCM_3_1, FCAN.FData);}
  void set_FCM_FCWpreWarning(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_FCWpreWarning_FCM_3_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_FCWpreWarning, put = set_FCM_FCWpreWarning)) double FCM_FCWpreWarning;
  double get_FCM_TimeGapSetICM(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_TimeGapSetICM_FCM_3_1, FCAN.FData);}
  void set_FCM_TimeGapSetICM(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_TimeGapSetICM_FCM_3_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_TimeGapSetICM, put = set_FCM_TimeGapSetICM)) double FCM_TimeGapSetICM;
  double get_FCM_ACCMode(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_ACCMode_FCM_3_1, FCAN.FData);}
  void set_FCM_ACCMode(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_ACCMode_FCM_3_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_ACCMode, put = set_FCM_ACCMode)) double FCM_ACCMode;
  double get_FCM_ACCTakeOverReq(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_ACCTakeOverReq_FCM_3_1, FCAN.FData);}
  void set_FCM_ACCTakeOverReq(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_ACCTakeOverReq_FCM_3_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_ACCTakeOverReq, put = set_FCM_ACCTakeOverReq)) double FCM_ACCTakeOverReq;
  double get_FCM_ACCVSetDis(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_ACCVSetDis_FCM_3_1, FCAN.FData);}
  void set_FCM_ACCVSetDis(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_ACCVSetDis_FCM_3_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_ACCVSetDis, put = set_FCM_ACCVSetDis)) double FCM_ACCVSetDis;
  double get_FCM_AEBTextInfo(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_AEBTextInfo_FCM_3_1, FCAN.FData);}
  void set_FCM_AEBTextInfo(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_AEBTextInfo_FCM_3_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_AEBTextInfo, put = set_FCM_AEBTextInfo)) double FCM_AEBTextInfo;
  double get_FCM_ACCTextInfo(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_ACCTextInfo_FCM_3_1, FCAN.FData);}
  void set_FCM_ACCTextInfo(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_ACCTextInfo_FCM_3_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_ACCTextInfo, put = set_FCM_ACCTextInfo)) double FCM_ACCTextInfo;
  double get_FCM_CameraTextInfo(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_CameraTextInfo_FCM_3_1, FCAN.FData);}
  void set_FCM_CameraTextInfo(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_CameraTextInfo_FCM_3_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_CameraTextInfo, put = set_FCM_CameraTextInfo)) double FCM_CameraTextInfo;
  double get_FCM_DVMode(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_DVMode_FCM_3_1, FCAN.FData);}
  void set_FCM_DVMode(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_DVMode_FCM_3_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_DVMode, put = set_FCM_DVMode)) double FCM_DVMode;
  void init() { FCAN = create().FCAN; }
  TFCM_3_1 create() { CANMsgDecl(_FCM_3_1, cFCM_3_1, 0, 0, 8, 770) return cFCM_3_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message FCM_4_1
extern const TCANSignal FCM_LDWONOFFSts_FCM_4_1;
extern const TCANSignal FCM_LDWSysSts_FCM_4_1;
extern const TCANSignal FCM_LDWLKATypefeedback_FCM_4_1;
extern const TCANSignal FCM_LDWLDPSnvtySts_FCM_4_1;
extern const TCANSignal FCM_LDWWarnModSts_FCM_4_1;
extern const TCANSignal FCM_LDP_TJA_ELKTakeoverReq_FCM_4_1;
extern const TCANSignal FCM_LDW_ELK_TJA_LDPLeftVisuali_FCM_4_1;
extern const TCANSignal FCM_LDW_ELK_TJA_LDPRightVisuali_FCM_4_1;
extern const TCANSignal FCM_TSRONOFFSts_FCM_4_1;
extern const TCANSignal FCM_TSROverSpeedONOFFSts_FCM_4_1;
extern const TCANSignal FCM_TSROverSpeedAcousticONOFFSts_FCM_4_1;
extern const TCANSignal FCM_TSRState_FCM_4_1;
extern const TCANSignal FCM_TSRDisplay_FCM_4_1;
extern const TCANSignal FCM_SLASpdlimitUnits_FCM_4_1;
extern const TCANSignal FCM_TSROverSpdWarning_FCM_4_1;
extern const TCANSignal FCM_IHBCONOFFSts_FCM_4_1;
extern const TCANSignal FCM_IHBCStatus_FCM_4_1;
extern const TCANSignal FCM_LDWTextInfo_FCM_4_1;
extern const TCANSignal FCM_TSRTextInfo_FCM_4_1;
extern const TCANSignal FCM_IHBCTextInfo_FCM_4_1;
extern const TCANSignal FCM_LDWVoiceWarning_FCM_4_1;
struct _FCM_4_1;
typedef struct _FCM_4_1 TFCM_4_1;
struct _FCM_4_1{
  TCAN FCAN;
  double get_FCM_LDWONOFFSts(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_LDWONOFFSts_FCM_4_1, FCAN.FData);}
  void set_FCM_LDWONOFFSts(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_LDWONOFFSts_FCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_LDWONOFFSts, put = set_FCM_LDWONOFFSts)) double FCM_LDWONOFFSts;
  double get_FCM_LDWSysSts(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_LDWSysSts_FCM_4_1, FCAN.FData);}
  void set_FCM_LDWSysSts(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_LDWSysSts_FCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_LDWSysSts, put = set_FCM_LDWSysSts)) double FCM_LDWSysSts;
  double get_FCM_LDWLKATypefeedback(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_LDWLKATypefeedback_FCM_4_1, FCAN.FData);}
  void set_FCM_LDWLKATypefeedback(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_LDWLKATypefeedback_FCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_LDWLKATypefeedback, put = set_FCM_LDWLKATypefeedback)) double FCM_LDWLKATypefeedback;
  double get_FCM_LDWLDPSnvtySts(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_LDWLDPSnvtySts_FCM_4_1, FCAN.FData);}
  void set_FCM_LDWLDPSnvtySts(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_LDWLDPSnvtySts_FCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_LDWLDPSnvtySts, put = set_FCM_LDWLDPSnvtySts)) double FCM_LDWLDPSnvtySts;
  double get_FCM_LDWWarnModSts(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_LDWWarnModSts_FCM_4_1, FCAN.FData);}
  void set_FCM_LDWWarnModSts(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_LDWWarnModSts_FCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_LDWWarnModSts, put = set_FCM_LDWWarnModSts)) double FCM_LDWWarnModSts;
  double get_FCM_LDP_TJA_ELKTakeoverReq(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_LDP_TJA_ELKTakeoverReq_FCM_4_1, FCAN.FData);}
  void set_FCM_LDP_TJA_ELKTakeoverReq(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_LDP_TJA_ELKTakeoverReq_FCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_LDP_TJA_ELKTakeoverReq, put = set_FCM_LDP_TJA_ELKTakeoverReq)) double FCM_LDP_TJA_ELKTakeoverReq;
  double get_FCM_LDW_ELK_TJA_LDPLeftVisuali(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_LDW_ELK_TJA_LDPLeftVisuali_FCM_4_1, FCAN.FData);}
  void set_FCM_LDW_ELK_TJA_LDPLeftVisuali(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_LDW_ELK_TJA_LDPLeftVisuali_FCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_LDW_ELK_TJA_LDPLeftVisuali, put = set_FCM_LDW_ELK_TJA_LDPLeftVisuali)) double FCM_LDW_ELK_TJA_LDPLeftVisuali;
  double get_FCM_LDW_ELK_TJA_LDPRightVisuali(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_LDW_ELK_TJA_LDPRightVisuali_FCM_4_1, FCAN.FData);}
  void set_FCM_LDW_ELK_TJA_LDPRightVisuali(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_LDW_ELK_TJA_LDPRightVisuali_FCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_LDW_ELK_TJA_LDPRightVisuali, put = set_FCM_LDW_ELK_TJA_LDPRightVisuali)) double FCM_LDW_ELK_TJA_LDPRightVisuali;
  double get_FCM_TSRONOFFSts(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_TSRONOFFSts_FCM_4_1, FCAN.FData);}
  void set_FCM_TSRONOFFSts(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_TSRONOFFSts_FCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_TSRONOFFSts, put = set_FCM_TSRONOFFSts)) double FCM_TSRONOFFSts;
  double get_FCM_TSROverSpeedONOFFSts(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_TSROverSpeedONOFFSts_FCM_4_1, FCAN.FData);}
  void set_FCM_TSROverSpeedONOFFSts(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_TSROverSpeedONOFFSts_FCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_TSROverSpeedONOFFSts, put = set_FCM_TSROverSpeedONOFFSts)) double FCM_TSROverSpeedONOFFSts;
  double get_FCM_TSROverSpeedAcousticONOFFSts(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_TSROverSpeedAcousticONOFFSts_FCM_4_1, FCAN.FData);}
  void set_FCM_TSROverSpeedAcousticONOFFSts(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_TSROverSpeedAcousticONOFFSts_FCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_TSROverSpeedAcousticONOFFSts, put = set_FCM_TSROverSpeedAcousticONOFFSts)) double FCM_TSROverSpeedAcousticONOFFSts;
  double get_FCM_TSRState(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_TSRState_FCM_4_1, FCAN.FData);}
  void set_FCM_TSRState(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_TSRState_FCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_TSRState, put = set_FCM_TSRState)) double FCM_TSRState;
  double get_FCM_TSRDisplay(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_TSRDisplay_FCM_4_1, FCAN.FData);}
  void set_FCM_TSRDisplay(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_TSRDisplay_FCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_TSRDisplay, put = set_FCM_TSRDisplay)) double FCM_TSRDisplay;
  double get_FCM_SLASpdlimitUnits(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_SLASpdlimitUnits_FCM_4_1, FCAN.FData);}
  void set_FCM_SLASpdlimitUnits(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_SLASpdlimitUnits_FCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_SLASpdlimitUnits, put = set_FCM_SLASpdlimitUnits)) double FCM_SLASpdlimitUnits;
  double get_FCM_TSROverSpdWarning(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_TSROverSpdWarning_FCM_4_1, FCAN.FData);}
  void set_FCM_TSROverSpdWarning(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_TSROverSpdWarning_FCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_TSROverSpdWarning, put = set_FCM_TSROverSpdWarning)) double FCM_TSROverSpdWarning;
  double get_FCM_IHBCONOFFSts(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_IHBCONOFFSts_FCM_4_1, FCAN.FData);}
  void set_FCM_IHBCONOFFSts(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_IHBCONOFFSts_FCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_IHBCONOFFSts, put = set_FCM_IHBCONOFFSts)) double FCM_IHBCONOFFSts;
  double get_FCM_IHBCStatus(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_IHBCStatus_FCM_4_1, FCAN.FData);}
  void set_FCM_IHBCStatus(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_IHBCStatus_FCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_IHBCStatus, put = set_FCM_IHBCStatus)) double FCM_IHBCStatus;
  double get_FCM_LDWTextInfo(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_LDWTextInfo_FCM_4_1, FCAN.FData);}
  void set_FCM_LDWTextInfo(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_LDWTextInfo_FCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_LDWTextInfo, put = set_FCM_LDWTextInfo)) double FCM_LDWTextInfo;
  double get_FCM_TSRTextInfo(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_TSRTextInfo_FCM_4_1, FCAN.FData);}
  void set_FCM_TSRTextInfo(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_TSRTextInfo_FCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_TSRTextInfo, put = set_FCM_TSRTextInfo)) double FCM_TSRTextInfo;
  double get_FCM_IHBCTextInfo(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_IHBCTextInfo_FCM_4_1, FCAN.FData);}
  void set_FCM_IHBCTextInfo(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_IHBCTextInfo_FCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_IHBCTextInfo, put = set_FCM_IHBCTextInfo)) double FCM_IHBCTextInfo;
  double get_FCM_LDWVoiceWarning(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_LDWVoiceWarning_FCM_4_1, FCAN.FData);}
  void set_FCM_LDWVoiceWarning(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_LDWVoiceWarning_FCM_4_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_LDWVoiceWarning, put = set_FCM_LDWVoiceWarning)) double FCM_LDWVoiceWarning;
  void init() { FCAN = create().FCAN; }
  TFCM_4_1 create() { CANMsgDecl(_FCM_4_1, cFCM_4_1, 0, 0, 8, 771) return cFCM_4_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message FCM_5_1
extern const TCANSignal FCM_EgoLeLineTyp_FCM_5_1;
extern const TCANSignal FCM_EgoLeLineColor_FCM_5_1;
extern const TCANSignal FCM_EgoLeLineID_FCM_5_1;
extern const TCANSignal FCM_EgoLeLineHozlDst_FCM_5_1;
extern const TCANSignal FCM_EgoLeLineCrvt_FCM_5_1;
extern const TCANSignal FCM_EgoRiLineTyp_FCM_5_1;
extern const TCANSignal FCM_EgoRiLineColor_FCM_5_1;
extern const TCANSignal FCM_EgoRiLineID_FCM_5_1;
extern const TCANSignal FCM_EgoRiLineHozlDst_FCM_5_1;
extern const TCANSignal FCM_EgoRiLineCrvt_FCM_5_1;
extern const TCANSignal FCM_5_RollingCounter_FCM_5_1;
extern const TCANSignal FCM_5_Checksum_FCM_5_1;
struct _FCM_5_1;
typedef struct _FCM_5_1 TFCM_5_1;
struct _FCM_5_1{
  TCAN FCAN;
  double get_FCM_EgoLeLineTyp(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_EgoLeLineTyp_FCM_5_1, FCAN.FData);}
  void set_FCM_EgoLeLineTyp(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_EgoLeLineTyp_FCM_5_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_EgoLeLineTyp, put = set_FCM_EgoLeLineTyp)) double FCM_EgoLeLineTyp;
  double get_FCM_EgoLeLineColor(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_EgoLeLineColor_FCM_5_1, FCAN.FData);}
  void set_FCM_EgoLeLineColor(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_EgoLeLineColor_FCM_5_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_EgoLeLineColor, put = set_FCM_EgoLeLineColor)) double FCM_EgoLeLineColor;
  double get_FCM_EgoLeLineID(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_EgoLeLineID_FCM_5_1, FCAN.FData);}
  void set_FCM_EgoLeLineID(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_EgoLeLineID_FCM_5_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_EgoLeLineID, put = set_FCM_EgoLeLineID)) double FCM_EgoLeLineID;
  double get_FCM_EgoLeLineHozlDst(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_EgoLeLineHozlDst_FCM_5_1, FCAN.FData);}
  void set_FCM_EgoLeLineHozlDst(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_EgoLeLineHozlDst_FCM_5_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_EgoLeLineHozlDst, put = set_FCM_EgoLeLineHozlDst)) double FCM_EgoLeLineHozlDst;
  double get_FCM_EgoLeLineCrvt(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_EgoLeLineCrvt_FCM_5_1, FCAN.FData);}
  void set_FCM_EgoLeLineCrvt(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_EgoLeLineCrvt_FCM_5_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_EgoLeLineCrvt, put = set_FCM_EgoLeLineCrvt)) double FCM_EgoLeLineCrvt;
  double get_FCM_EgoRiLineTyp(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_EgoRiLineTyp_FCM_5_1, FCAN.FData);}
  void set_FCM_EgoRiLineTyp(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_EgoRiLineTyp_FCM_5_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_EgoRiLineTyp, put = set_FCM_EgoRiLineTyp)) double FCM_EgoRiLineTyp;
  double get_FCM_EgoRiLineColor(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_EgoRiLineColor_FCM_5_1, FCAN.FData);}
  void set_FCM_EgoRiLineColor(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_EgoRiLineColor_FCM_5_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_EgoRiLineColor, put = set_FCM_EgoRiLineColor)) double FCM_EgoRiLineColor;
  double get_FCM_EgoRiLineID(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_EgoRiLineID_FCM_5_1, FCAN.FData);}
  void set_FCM_EgoRiLineID(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_EgoRiLineID_FCM_5_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_EgoRiLineID, put = set_FCM_EgoRiLineID)) double FCM_EgoRiLineID;
  double get_FCM_EgoRiLineHozlDst(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_EgoRiLineHozlDst_FCM_5_1, FCAN.FData);}
  void set_FCM_EgoRiLineHozlDst(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_EgoRiLineHozlDst_FCM_5_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_EgoRiLineHozlDst, put = set_FCM_EgoRiLineHozlDst)) double FCM_EgoRiLineHozlDst;
  double get_FCM_EgoRiLineCrvt(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_EgoRiLineCrvt_FCM_5_1, FCAN.FData);}
  void set_FCM_EgoRiLineCrvt(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_EgoRiLineCrvt_FCM_5_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_EgoRiLineCrvt, put = set_FCM_EgoRiLineCrvt)) double FCM_EgoRiLineCrvt;
  double get_FCM_5_RollingCounter(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_5_RollingCounter_FCM_5_1, FCAN.FData);}
  void set_FCM_5_RollingCounter(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_5_RollingCounter_FCM_5_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_5_RollingCounter, put = set_FCM_5_RollingCounter)) double FCM_5_RollingCounter;
  double get_FCM_5_Checksum(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_5_Checksum_FCM_5_1, FCAN.FData);}
  void set_FCM_5_Checksum(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_5_Checksum_FCM_5_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_5_Checksum, put = set_FCM_5_Checksum)) double FCM_5_Checksum;
  void init() { FCAN = create().FCAN; }
  TFCM_5_1 create() { CANMsgDecl(_FCM_5_1, cFCM_5_1, 0, 0, 8, 772) return cFCM_5_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message FCM_6_1
extern const TCANSignal FCM_NeborLeLineTyp_FCM_6_1;
extern const TCANSignal FCM_NeborLeLineColor_FCM_6_1;
extern const TCANSignal FCM_NeborLeLineID_FCM_6_1;
extern const TCANSignal FCM_NeborLeLineHozlDst_FCM_6_1;
extern const TCANSignal FCM_NeborLeLineCrvt_FCM_6_1;
extern const TCANSignal FCM_NeborRiLineTyp_FCM_6_1;
extern const TCANSignal FCM_NeborRiLineColor_FCM_6_1;
extern const TCANSignal FCM_NeborRiLineID_FCM_6_1;
extern const TCANSignal FCM_NeborRiLineHozlDst_FCM_6_1;
extern const TCANSignal FCM_NeborRiLineCrvt_FCM_6_1;
extern const TCANSignal FCM_6_RollingCounter_FCM_6_1;
extern const TCANSignal FCM_6_Checksum_FCM_6_1;
struct _FCM_6_1;
typedef struct _FCM_6_1 TFCM_6_1;
struct _FCM_6_1{
  TCAN FCAN;
  double get_FCM_NeborLeLineTyp(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_NeborLeLineTyp_FCM_6_1, FCAN.FData);}
  void set_FCM_NeborLeLineTyp(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_NeborLeLineTyp_FCM_6_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_NeborLeLineTyp, put = set_FCM_NeborLeLineTyp)) double FCM_NeborLeLineTyp;
  double get_FCM_NeborLeLineColor(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_NeborLeLineColor_FCM_6_1, FCAN.FData);}
  void set_FCM_NeborLeLineColor(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_NeborLeLineColor_FCM_6_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_NeborLeLineColor, put = set_FCM_NeborLeLineColor)) double FCM_NeborLeLineColor;
  double get_FCM_NeborLeLineID(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_NeborLeLineID_FCM_6_1, FCAN.FData);}
  void set_FCM_NeborLeLineID(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_NeborLeLineID_FCM_6_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_NeborLeLineID, put = set_FCM_NeborLeLineID)) double FCM_NeborLeLineID;
  double get_FCM_NeborLeLineHozlDst(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_NeborLeLineHozlDst_FCM_6_1, FCAN.FData);}
  void set_FCM_NeborLeLineHozlDst(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_NeborLeLineHozlDst_FCM_6_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_NeborLeLineHozlDst, put = set_FCM_NeborLeLineHozlDst)) double FCM_NeborLeLineHozlDst;
  double get_FCM_NeborLeLineCrvt(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_NeborLeLineCrvt_FCM_6_1, FCAN.FData);}
  void set_FCM_NeborLeLineCrvt(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_NeborLeLineCrvt_FCM_6_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_NeborLeLineCrvt, put = set_FCM_NeborLeLineCrvt)) double FCM_NeborLeLineCrvt;
  double get_FCM_NeborRiLineTyp(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_NeborRiLineTyp_FCM_6_1, FCAN.FData);}
  void set_FCM_NeborRiLineTyp(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_NeborRiLineTyp_FCM_6_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_NeborRiLineTyp, put = set_FCM_NeborRiLineTyp)) double FCM_NeborRiLineTyp;
  double get_FCM_NeborRiLineColor(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_NeborRiLineColor_FCM_6_1, FCAN.FData);}
  void set_FCM_NeborRiLineColor(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_NeborRiLineColor_FCM_6_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_NeborRiLineColor, put = set_FCM_NeborRiLineColor)) double FCM_NeborRiLineColor;
  double get_FCM_NeborRiLineID(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_NeborRiLineID_FCM_6_1, FCAN.FData);}
  void set_FCM_NeborRiLineID(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_NeborRiLineID_FCM_6_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_NeborRiLineID, put = set_FCM_NeborRiLineID)) double FCM_NeborRiLineID;
  double get_FCM_NeborRiLineHozlDst(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_NeborRiLineHozlDst_FCM_6_1, FCAN.FData);}
  void set_FCM_NeborRiLineHozlDst(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_NeborRiLineHozlDst_FCM_6_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_NeborRiLineHozlDst, put = set_FCM_NeborRiLineHozlDst)) double FCM_NeborRiLineHozlDst;
  double get_FCM_NeborRiLineCrvt(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_NeborRiLineCrvt_FCM_6_1, FCAN.FData);}
  void set_FCM_NeborRiLineCrvt(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_NeborRiLineCrvt_FCM_6_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_NeborRiLineCrvt, put = set_FCM_NeborRiLineCrvt)) double FCM_NeborRiLineCrvt;
  double get_FCM_6_RollingCounter(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_6_RollingCounter_FCM_6_1, FCAN.FData);}
  void set_FCM_6_RollingCounter(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_6_RollingCounter_FCM_6_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_6_RollingCounter, put = set_FCM_6_RollingCounter)) double FCM_6_RollingCounter;
  double get_FCM_6_Checksum(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_6_Checksum_FCM_6_1, FCAN.FData);}
  void set_FCM_6_Checksum(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_6_Checksum_FCM_6_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_6_Checksum, put = set_FCM_6_Checksum)) double FCM_6_Checksum;
  void init() { FCAN = create().FCAN; }
  TFCM_6_1 create() { CANMsgDecl(_FCM_6_1, cFCM_6_1, 0, 0, 8, 773) return cFCM_6_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message FCM_7_1
extern const TCANSignal FCM_ACC_TargetVehicleSubType_FCM_7_1;
extern const TCANSignal FCM_ACCObjTyp_FCM_7_1;
extern const TCANSignal FCM_dxTarObjcolor_FCM_7_1;
extern const TCANSignal FCM_ACCObjHozDstY_FCM_7_1;
extern const TCANSignal FCM_FrntFarObjTyp_FCM_7_1;
extern const TCANSignal FCM_7_RollingCounter_FCM_7_1;
extern const TCANSignal FCM_FrntFarObjHozDstY_FCM_7_1;
extern const TCANSignal FCM_7_Checksum_FCM_7_1;
struct _FCM_7_1;
typedef struct _FCM_7_1 TFCM_7_1;
struct _FCM_7_1{
  TCAN FCAN;
  double get_FCM_ACC_TargetVehicleSubType(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_ACC_TargetVehicleSubType_FCM_7_1, FCAN.FData);}
  void set_FCM_ACC_TargetVehicleSubType(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_ACC_TargetVehicleSubType_FCM_7_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_ACC_TargetVehicleSubType, put = set_FCM_ACC_TargetVehicleSubType)) double FCM_ACC_TargetVehicleSubType;
  double get_FCM_ACCObjTyp(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_ACCObjTyp_FCM_7_1, FCAN.FData);}
  void set_FCM_ACCObjTyp(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_ACCObjTyp_FCM_7_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_ACCObjTyp, put = set_FCM_ACCObjTyp)) double FCM_ACCObjTyp;
  double get_FCM_dxTarObjcolor(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_dxTarObjcolor_FCM_7_1, FCAN.FData);}
  void set_FCM_dxTarObjcolor(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_dxTarObjcolor_FCM_7_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_dxTarObjcolor, put = set_FCM_dxTarObjcolor)) double FCM_dxTarObjcolor;
  double get_FCM_ACCObjHozDstY(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_ACCObjHozDstY_FCM_7_1, FCAN.FData);}
  void set_FCM_ACCObjHozDstY(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_ACCObjHozDstY_FCM_7_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_ACCObjHozDstY, put = set_FCM_ACCObjHozDstY)) double FCM_ACCObjHozDstY;
  double get_FCM_FrntFarObjTyp(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_FrntFarObjTyp_FCM_7_1, FCAN.FData);}
  void set_FCM_FrntFarObjTyp(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_FrntFarObjTyp_FCM_7_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_FrntFarObjTyp, put = set_FCM_FrntFarObjTyp)) double FCM_FrntFarObjTyp;
  double get_FCM_7_RollingCounter(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_7_RollingCounter_FCM_7_1, FCAN.FData);}
  void set_FCM_7_RollingCounter(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_7_RollingCounter_FCM_7_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_7_RollingCounter, put = set_FCM_7_RollingCounter)) double FCM_7_RollingCounter;
  double get_FCM_FrntFarObjHozDstY(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_FrntFarObjHozDstY_FCM_7_1, FCAN.FData);}
  void set_FCM_FrntFarObjHozDstY(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_FrntFarObjHozDstY_FCM_7_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_FrntFarObjHozDstY, put = set_FCM_FrntFarObjHozDstY)) double FCM_FrntFarObjHozDstY;
  double get_FCM_7_Checksum(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_7_Checksum_FCM_7_1, FCAN.FData);}
  void set_FCM_7_Checksum(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_7_Checksum_FCM_7_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_7_Checksum, put = set_FCM_7_Checksum)) double FCM_7_Checksum;
  void init() { FCAN = create().FCAN; }
  TFCM_7_1 create() { CANMsgDecl(_FCM_7_1, cFCM_7_1, 0, 0, 8, 774) return cFCM_7_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message FCM_8_1
extern const TCANSignal FCM_ACC_LeftTargetVehicleSubType_FCM_8_1;
extern const TCANSignal FCM_LeObjTyp_FCM_8_1;
extern const TCANSignal FCM_ACC_RightTargetVehicleSubTyp_FCM_8_1;
extern const TCANSignal FCM_RiObjTyp_FCM_8_1;
extern const TCANSignal FCM_LeObjHozDstY_FCM_8_1;
extern const TCANSignal FCM_8_RollingCounter_FCM_8_1;
extern const TCANSignal FCM_RiObjHozDstY_FCM_8_1;
extern const TCANSignal FCM_8_Checksum_FCM_8_1;
struct _FCM_8_1;
typedef struct _FCM_8_1 TFCM_8_1;
struct _FCM_8_1{
  TCAN FCAN;
  double get_FCM_ACC_LeftTargetVehicleSubType(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_ACC_LeftTargetVehicleSubType_FCM_8_1, FCAN.FData);}
  void set_FCM_ACC_LeftTargetVehicleSubType(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_ACC_LeftTargetVehicleSubType_FCM_8_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_ACC_LeftTargetVehicleSubType, put = set_FCM_ACC_LeftTargetVehicleSubType)) double FCM_ACC_LeftTargetVehicleSubType;
  double get_FCM_LeObjTyp(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_LeObjTyp_FCM_8_1, FCAN.FData);}
  void set_FCM_LeObjTyp(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_LeObjTyp_FCM_8_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_LeObjTyp, put = set_FCM_LeObjTyp)) double FCM_LeObjTyp;
  double get_FCM_ACC_RightTargetVehicleSubTyp(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_ACC_RightTargetVehicleSubTyp_FCM_8_1, FCAN.FData);}
  void set_FCM_ACC_RightTargetVehicleSubTyp(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_ACC_RightTargetVehicleSubTyp_FCM_8_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_ACC_RightTargetVehicleSubTyp, put = set_FCM_ACC_RightTargetVehicleSubTyp)) double FCM_ACC_RightTargetVehicleSubTyp;
  double get_FCM_RiObjTyp(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_RiObjTyp_FCM_8_1, FCAN.FData);}
  void set_FCM_RiObjTyp(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_RiObjTyp_FCM_8_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_RiObjTyp, put = set_FCM_RiObjTyp)) double FCM_RiObjTyp;
  double get_FCM_LeObjHozDstY(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_LeObjHozDstY_FCM_8_1, FCAN.FData);}
  void set_FCM_LeObjHozDstY(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_LeObjHozDstY_FCM_8_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_LeObjHozDstY, put = set_FCM_LeObjHozDstY)) double FCM_LeObjHozDstY;
  double get_FCM_8_RollingCounter(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_8_RollingCounter_FCM_8_1, FCAN.FData);}
  void set_FCM_8_RollingCounter(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_8_RollingCounter_FCM_8_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_8_RollingCounter, put = set_FCM_8_RollingCounter)) double FCM_8_RollingCounter;
  double get_FCM_RiObjHozDstY(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_RiObjHozDstY_FCM_8_1, FCAN.FData);}
  void set_FCM_RiObjHozDstY(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_RiObjHozDstY_FCM_8_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_RiObjHozDstY, put = set_FCM_RiObjHozDstY)) double FCM_RiObjHozDstY;
  double get_FCM_8_Checksum(void) { return com.get_can_signal_value((TCANSignal* const)&FCM_8_Checksum_FCM_8_1, FCAN.FData);}
  void set_FCM_8_Checksum(const double value) { com.set_can_signal_value((TCANSignal* const)&FCM_8_Checksum_FCM_8_1, FCAN.FData, value);}
  __declspec(property(get = get_FCM_8_Checksum, put = set_FCM_8_Checksum)) double FCM_8_Checksum;
  void init() { FCAN = create().FCAN; }
  TFCM_8_1 create() { CANMsgDecl(_FCM_8_1, cFCM_8_1, 0, 0, 8, 775) return cFCM_8_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message GW_PC_2_1
extern const TCANSignal ESP_1_ESPOff_GW_PC_2_1;
extern const TCANSignal ESP_1_ESPActive_GW_PC_2_1;
extern const TCANSignal ESP_1_TCSActive_GW_PC_2_1;
extern const TCANSignal ESP_1_ESPFault_GW_PC_2_1;
extern const TCANSignal ESP_1_TCSFault_GW_PC_2_1;
extern const TCANSignal ESP_1_DVTSessionFlag_GW_PC_2_1;
extern const TCANSignal ESP_1_HDCControl_GW_PC_2_1;
extern const TCANSignal ESP_1_HDCFault_GW_PC_2_1;
extern const TCANSignal EPB_1_AutoHold_Standby_GW_PC_2_1;
extern const TCANSignal EPB_1_WarningLamp_GW_PC_2_1;
extern const TCANSignal EPB_1_ActiveLamp_GW_PC_2_1;
extern const TCANSignal EPB_1_AutoholdActive_GW_PC_2_1;
extern const TCANSignal EPB_1_AutoholdValid_GW_PC_2_1;
extern const TCANSignal ABS_3_AbsActive_GW_PC_2_1;
extern const TCANSignal ABS_3_AbsFault_GW_PC_2_1;
extern const TCANSignal ABS_3_VehicleSpeedValid_GW_PC_2_1;
extern const TCANSignal ABS_3_VehicleSpeed_GW_PC_2_1;
extern const TCANSignal ABS_3_EbdActive_GW_PC_2_1;
extern const TCANSignal ABS_3_EbdFault_GW_PC_2_1;
extern const TCANSignal SAS_1_SteeringAngleValid_GW_PC_2_1;
extern const TCANSignal SAS_1_FailureSts_GW_PC_2_1;
extern const TCANSignal SAS_1_CalibratedSt_GW_PC_2_1;
extern const TCANSignal SAS_1_SteeringAngle_GW_PC_2_1;
extern const TCANSignal ESP_1_Timeout_Flag_GW_PC_2_1;
extern const TCANSignal EPB_1_Timeout_Flag_GW_PC_2_1;
extern const TCANSignal ABS_3_Timeout_Flag_GW_PC_2_1;
extern const TCANSignal SAS_1_Timeout_Flag_GW_PC_2_1;
extern const TCANSignal EPB_1_InhibitDriveOffNotice_GW_PC_2_1;
struct _GW_PC_2_1;
typedef struct _GW_PC_2_1 TGW_PC_2_1;
struct _GW_PC_2_1{
  TCAN FCAN;
  double get_ESP_1_ESPOff(void) { return com.get_can_signal_value((TCANSignal* const)&ESP_1_ESPOff_GW_PC_2_1, FCAN.FData);}
  void set_ESP_1_ESPOff(const double value) { com.set_can_signal_value((TCANSignal* const)&ESP_1_ESPOff_GW_PC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_ESP_1_ESPOff, put = set_ESP_1_ESPOff)) double ESP_1_ESPOff;
  double get_ESP_1_ESPActive(void) { return com.get_can_signal_value((TCANSignal* const)&ESP_1_ESPActive_GW_PC_2_1, FCAN.FData);}
  void set_ESP_1_ESPActive(const double value) { com.set_can_signal_value((TCANSignal* const)&ESP_1_ESPActive_GW_PC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_ESP_1_ESPActive, put = set_ESP_1_ESPActive)) double ESP_1_ESPActive;
  double get_ESP_1_TCSActive(void) { return com.get_can_signal_value((TCANSignal* const)&ESP_1_TCSActive_GW_PC_2_1, FCAN.FData);}
  void set_ESP_1_TCSActive(const double value) { com.set_can_signal_value((TCANSignal* const)&ESP_1_TCSActive_GW_PC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_ESP_1_TCSActive, put = set_ESP_1_TCSActive)) double ESP_1_TCSActive;
  double get_ESP_1_ESPFault(void) { return com.get_can_signal_value((TCANSignal* const)&ESP_1_ESPFault_GW_PC_2_1, FCAN.FData);}
  void set_ESP_1_ESPFault(const double value) { com.set_can_signal_value((TCANSignal* const)&ESP_1_ESPFault_GW_PC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_ESP_1_ESPFault, put = set_ESP_1_ESPFault)) double ESP_1_ESPFault;
  double get_ESP_1_TCSFault(void) { return com.get_can_signal_value((TCANSignal* const)&ESP_1_TCSFault_GW_PC_2_1, FCAN.FData);}
  void set_ESP_1_TCSFault(const double value) { com.set_can_signal_value((TCANSignal* const)&ESP_1_TCSFault_GW_PC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_ESP_1_TCSFault, put = set_ESP_1_TCSFault)) double ESP_1_TCSFault;
  double get_ESP_1_DVTSessionFlag(void) { return com.get_can_signal_value((TCANSignal* const)&ESP_1_DVTSessionFlag_GW_PC_2_1, FCAN.FData);}
  void set_ESP_1_DVTSessionFlag(const double value) { com.set_can_signal_value((TCANSignal* const)&ESP_1_DVTSessionFlag_GW_PC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_ESP_1_DVTSessionFlag, put = set_ESP_1_DVTSessionFlag)) double ESP_1_DVTSessionFlag;
  double get_ESP_1_HDCControl(void) { return com.get_can_signal_value((TCANSignal* const)&ESP_1_HDCControl_GW_PC_2_1, FCAN.FData);}
  void set_ESP_1_HDCControl(const double value) { com.set_can_signal_value((TCANSignal* const)&ESP_1_HDCControl_GW_PC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_ESP_1_HDCControl, put = set_ESP_1_HDCControl)) double ESP_1_HDCControl;
  double get_ESP_1_HDCFault(void) { return com.get_can_signal_value((TCANSignal* const)&ESP_1_HDCFault_GW_PC_2_1, FCAN.FData);}
  void set_ESP_1_HDCFault(const double value) { com.set_can_signal_value((TCANSignal* const)&ESP_1_HDCFault_GW_PC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_ESP_1_HDCFault, put = set_ESP_1_HDCFault)) double ESP_1_HDCFault;
  double get_EPB_1_AutoHold_Standby(void) { return com.get_can_signal_value((TCANSignal* const)&EPB_1_AutoHold_Standby_GW_PC_2_1, FCAN.FData);}
  void set_EPB_1_AutoHold_Standby(const double value) { com.set_can_signal_value((TCANSignal* const)&EPB_1_AutoHold_Standby_GW_PC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_EPB_1_AutoHold_Standby, put = set_EPB_1_AutoHold_Standby)) double EPB_1_AutoHold_Standby;
  double get_EPB_1_WarningLamp(void) { return com.get_can_signal_value((TCANSignal* const)&EPB_1_WarningLamp_GW_PC_2_1, FCAN.FData);}
  void set_EPB_1_WarningLamp(const double value) { com.set_can_signal_value((TCANSignal* const)&EPB_1_WarningLamp_GW_PC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_EPB_1_WarningLamp, put = set_EPB_1_WarningLamp)) double EPB_1_WarningLamp;
  double get_EPB_1_ActiveLamp(void) { return com.get_can_signal_value((TCANSignal* const)&EPB_1_ActiveLamp_GW_PC_2_1, FCAN.FData);}
  void set_EPB_1_ActiveLamp(const double value) { com.set_can_signal_value((TCANSignal* const)&EPB_1_ActiveLamp_GW_PC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_EPB_1_ActiveLamp, put = set_EPB_1_ActiveLamp)) double EPB_1_ActiveLamp;
  double get_EPB_1_AutoholdActive(void) { return com.get_can_signal_value((TCANSignal* const)&EPB_1_AutoholdActive_GW_PC_2_1, FCAN.FData);}
  void set_EPB_1_AutoholdActive(const double value) { com.set_can_signal_value((TCANSignal* const)&EPB_1_AutoholdActive_GW_PC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_EPB_1_AutoholdActive, put = set_EPB_1_AutoholdActive)) double EPB_1_AutoholdActive;
  double get_EPB_1_AutoholdValid(void) { return com.get_can_signal_value((TCANSignal* const)&EPB_1_AutoholdValid_GW_PC_2_1, FCAN.FData);}
  void set_EPB_1_AutoholdValid(const double value) { com.set_can_signal_value((TCANSignal* const)&EPB_1_AutoholdValid_GW_PC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_EPB_1_AutoholdValid, put = set_EPB_1_AutoholdValid)) double EPB_1_AutoholdValid;
  double get_ABS_3_AbsActive(void) { return com.get_can_signal_value((TCANSignal* const)&ABS_3_AbsActive_GW_PC_2_1, FCAN.FData);}
  void set_ABS_3_AbsActive(const double value) { com.set_can_signal_value((TCANSignal* const)&ABS_3_AbsActive_GW_PC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_ABS_3_AbsActive, put = set_ABS_3_AbsActive)) double ABS_3_AbsActive;
  double get_ABS_3_AbsFault(void) { return com.get_can_signal_value((TCANSignal* const)&ABS_3_AbsFault_GW_PC_2_1, FCAN.FData);}
  void set_ABS_3_AbsFault(const double value) { com.set_can_signal_value((TCANSignal* const)&ABS_3_AbsFault_GW_PC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_ABS_3_AbsFault, put = set_ABS_3_AbsFault)) double ABS_3_AbsFault;
  double get_ABS_3_VehicleSpeedValid(void) { return com.get_can_signal_value((TCANSignal* const)&ABS_3_VehicleSpeedValid_GW_PC_2_1, FCAN.FData);}
  void set_ABS_3_VehicleSpeedValid(const double value) { com.set_can_signal_value((TCANSignal* const)&ABS_3_VehicleSpeedValid_GW_PC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_ABS_3_VehicleSpeedValid, put = set_ABS_3_VehicleSpeedValid)) double ABS_3_VehicleSpeedValid;
  double get_ABS_3_VehicleSpeed(void) { return com.get_can_signal_value((TCANSignal* const)&ABS_3_VehicleSpeed_GW_PC_2_1, FCAN.FData);}
  void set_ABS_3_VehicleSpeed(const double value) { com.set_can_signal_value((TCANSignal* const)&ABS_3_VehicleSpeed_GW_PC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_ABS_3_VehicleSpeed, put = set_ABS_3_VehicleSpeed)) double ABS_3_VehicleSpeed;
  double get_ABS_3_EbdActive(void) { return com.get_can_signal_value((TCANSignal* const)&ABS_3_EbdActive_GW_PC_2_1, FCAN.FData);}
  void set_ABS_3_EbdActive(const double value) { com.set_can_signal_value((TCANSignal* const)&ABS_3_EbdActive_GW_PC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_ABS_3_EbdActive, put = set_ABS_3_EbdActive)) double ABS_3_EbdActive;
  double get_ABS_3_EbdFault(void) { return com.get_can_signal_value((TCANSignal* const)&ABS_3_EbdFault_GW_PC_2_1, FCAN.FData);}
  void set_ABS_3_EbdFault(const double value) { com.set_can_signal_value((TCANSignal* const)&ABS_3_EbdFault_GW_PC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_ABS_3_EbdFault, put = set_ABS_3_EbdFault)) double ABS_3_EbdFault;
  double get_SAS_1_SteeringAngleValid(void) { return com.get_can_signal_value((TCANSignal* const)&SAS_1_SteeringAngleValid_GW_PC_2_1, FCAN.FData);}
  void set_SAS_1_SteeringAngleValid(const double value) { com.set_can_signal_value((TCANSignal* const)&SAS_1_SteeringAngleValid_GW_PC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_SAS_1_SteeringAngleValid, put = set_SAS_1_SteeringAngleValid)) double SAS_1_SteeringAngleValid;
  double get_SAS_1_FailureSts(void) { return com.get_can_signal_value((TCANSignal* const)&SAS_1_FailureSts_GW_PC_2_1, FCAN.FData);}
  void set_SAS_1_FailureSts(const double value) { com.set_can_signal_value((TCANSignal* const)&SAS_1_FailureSts_GW_PC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_SAS_1_FailureSts, put = set_SAS_1_FailureSts)) double SAS_1_FailureSts;
  double get_SAS_1_CalibratedSt(void) { return com.get_can_signal_value((TCANSignal* const)&SAS_1_CalibratedSt_GW_PC_2_1, FCAN.FData);}
  void set_SAS_1_CalibratedSt(const double value) { com.set_can_signal_value((TCANSignal* const)&SAS_1_CalibratedSt_GW_PC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_SAS_1_CalibratedSt, put = set_SAS_1_CalibratedSt)) double SAS_1_CalibratedSt;
  double get_SAS_1_SteeringAngle(void) { return com.get_can_signal_value((TCANSignal* const)&SAS_1_SteeringAngle_GW_PC_2_1, FCAN.FData);}
  void set_SAS_1_SteeringAngle(const double value) { com.set_can_signal_value((TCANSignal* const)&SAS_1_SteeringAngle_GW_PC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_SAS_1_SteeringAngle, put = set_SAS_1_SteeringAngle)) double SAS_1_SteeringAngle;
  double get_ESP_1_Timeout_Flag(void) { return com.get_can_signal_value((TCANSignal* const)&ESP_1_Timeout_Flag_GW_PC_2_1, FCAN.FData);}
  void set_ESP_1_Timeout_Flag(const double value) { com.set_can_signal_value((TCANSignal* const)&ESP_1_Timeout_Flag_GW_PC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_ESP_1_Timeout_Flag, put = set_ESP_1_Timeout_Flag)) double ESP_1_Timeout_Flag;
  double get_EPB_1_Timeout_Flag(void) { return com.get_can_signal_value((TCANSignal* const)&EPB_1_Timeout_Flag_GW_PC_2_1, FCAN.FData);}
  void set_EPB_1_Timeout_Flag(const double value) { com.set_can_signal_value((TCANSignal* const)&EPB_1_Timeout_Flag_GW_PC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_EPB_1_Timeout_Flag, put = set_EPB_1_Timeout_Flag)) double EPB_1_Timeout_Flag;
  double get_ABS_3_Timeout_Flag(void) { return com.get_can_signal_value((TCANSignal* const)&ABS_3_Timeout_Flag_GW_PC_2_1, FCAN.FData);}
  void set_ABS_3_Timeout_Flag(const double value) { com.set_can_signal_value((TCANSignal* const)&ABS_3_Timeout_Flag_GW_PC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_ABS_3_Timeout_Flag, put = set_ABS_3_Timeout_Flag)) double ABS_3_Timeout_Flag;
  double get_SAS_1_Timeout_Flag(void) { return com.get_can_signal_value((TCANSignal* const)&SAS_1_Timeout_Flag_GW_PC_2_1, FCAN.FData);}
  void set_SAS_1_Timeout_Flag(const double value) { com.set_can_signal_value((TCANSignal* const)&SAS_1_Timeout_Flag_GW_PC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_SAS_1_Timeout_Flag, put = set_SAS_1_Timeout_Flag)) double SAS_1_Timeout_Flag;
  double get_EPB_1_InhibitDriveOffNotice(void) { return com.get_can_signal_value((TCANSignal* const)&EPB_1_InhibitDriveOffNotice_GW_PC_2_1, FCAN.FData);}
  void set_EPB_1_InhibitDriveOffNotice(const double value) { com.set_can_signal_value((TCANSignal* const)&EPB_1_InhibitDriveOffNotice_GW_PC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_EPB_1_InhibitDriveOffNotice, put = set_EPB_1_InhibitDriveOffNotice)) double EPB_1_InhibitDriveOffNotice;
  void init() { FCAN = create().FCAN; }
  TGW_PC_2_1 create() { CANMsgDecl(_GW_PC_2_1, cGW_PC_2_1, 0, 0, 8, 592) return cGW_PC_2_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message GW_PC_7_1
extern const TCANSignal AWD_1_SystemOperatingMode_GW_PC_7_1;
extern const TCANSignal AWD_1_ShiftSystemActuatorFault_GW_PC_7_1;
extern const TCANSignal AWD_1_ShiftSystemStuckinLow_GW_PC_7_1;
extern const TCANSignal AWD_1_ShiftSystemEncoderFault_GW_PC_7_1;
extern const TCANSignal AWD_1_DiagnosticLampRequest_GW_PC_7_1;
extern const TCANSignal AWD_1_ClutchCircuitFaultStatus_GW_PC_7_1;
extern const TCANSignal AWD_1_Lamp2WD_GW_PC_7_1;
extern const TCANSignal AWD_1_Lamp4WDLock_GW_PC_7_1;
extern const TCANSignal AWD_1_Lamp4WDLow_GW_PC_7_1;
extern const TCANSignal AWD_1_OpreationNotice_GW_PC_7_1;
extern const TCANSignal EDL_1_FrontDiffLockGreenLamp_GW_PC_7_1;
extern const TCANSignal EDL_1_FrontDiffLockYellowLamp_GW_PC_7_1;
extern const TCANSignal EDL_1_RearDiffLockGreenLamp_GW_PC_7_1;
extern const TCANSignal EDL_1_RearDiffLockYellowLamp_GW_PC_7_1;
extern const TCANSignal EDL_1_StatusNotice_GW_PC_7_1;
extern const TCANSignal AWD_1_Lamp4WDAuto_GW_PC_7_1;
extern const TCANSignal AWD_1_Timeout_Flag_GW_PC_7_1;
extern const TCANSignal EDL_1_Timeout_Flag_GW_PC_7_1;
struct _GW_PC_7_1;
typedef struct _GW_PC_7_1 TGW_PC_7_1;
struct _GW_PC_7_1{
  TCAN FCAN;
  double get_AWD_1_SystemOperatingMode(void) { return com.get_can_signal_value((TCANSignal* const)&AWD_1_SystemOperatingMode_GW_PC_7_1, FCAN.FData);}
  void set_AWD_1_SystemOperatingMode(const double value) { com.set_can_signal_value((TCANSignal* const)&AWD_1_SystemOperatingMode_GW_PC_7_1, FCAN.FData, value);}
  __declspec(property(get = get_AWD_1_SystemOperatingMode, put = set_AWD_1_SystemOperatingMode)) double AWD_1_SystemOperatingMode;
  double get_AWD_1_ShiftSystemActuatorFault(void) { return com.get_can_signal_value((TCANSignal* const)&AWD_1_ShiftSystemActuatorFault_GW_PC_7_1, FCAN.FData);}
  void set_AWD_1_ShiftSystemActuatorFault(const double value) { com.set_can_signal_value((TCANSignal* const)&AWD_1_ShiftSystemActuatorFault_GW_PC_7_1, FCAN.FData, value);}
  __declspec(property(get = get_AWD_1_ShiftSystemActuatorFault, put = set_AWD_1_ShiftSystemActuatorFault)) double AWD_1_ShiftSystemActuatorFault;
  double get_AWD_1_ShiftSystemStuckinLow(void) { return com.get_can_signal_value((TCANSignal* const)&AWD_1_ShiftSystemStuckinLow_GW_PC_7_1, FCAN.FData);}
  void set_AWD_1_ShiftSystemStuckinLow(const double value) { com.set_can_signal_value((TCANSignal* const)&AWD_1_ShiftSystemStuckinLow_GW_PC_7_1, FCAN.FData, value);}
  __declspec(property(get = get_AWD_1_ShiftSystemStuckinLow, put = set_AWD_1_ShiftSystemStuckinLow)) double AWD_1_ShiftSystemStuckinLow;
  double get_AWD_1_ShiftSystemEncoderFault(void) { return com.get_can_signal_value((TCANSignal* const)&AWD_1_ShiftSystemEncoderFault_GW_PC_7_1, FCAN.FData);}
  void set_AWD_1_ShiftSystemEncoderFault(const double value) { com.set_can_signal_value((TCANSignal* const)&AWD_1_ShiftSystemEncoderFault_GW_PC_7_1, FCAN.FData, value);}
  __declspec(property(get = get_AWD_1_ShiftSystemEncoderFault, put = set_AWD_1_ShiftSystemEncoderFault)) double AWD_1_ShiftSystemEncoderFault;
  double get_AWD_1_DiagnosticLampRequest(void) { return com.get_can_signal_value((TCANSignal* const)&AWD_1_DiagnosticLampRequest_GW_PC_7_1, FCAN.FData);}
  void set_AWD_1_DiagnosticLampRequest(const double value) { com.set_can_signal_value((TCANSignal* const)&AWD_1_DiagnosticLampRequest_GW_PC_7_1, FCAN.FData, value);}
  __declspec(property(get = get_AWD_1_DiagnosticLampRequest, put = set_AWD_1_DiagnosticLampRequest)) double AWD_1_DiagnosticLampRequest;
  double get_AWD_1_ClutchCircuitFaultStatus(void) { return com.get_can_signal_value((TCANSignal* const)&AWD_1_ClutchCircuitFaultStatus_GW_PC_7_1, FCAN.FData);}
  void set_AWD_1_ClutchCircuitFaultStatus(const double value) { com.set_can_signal_value((TCANSignal* const)&AWD_1_ClutchCircuitFaultStatus_GW_PC_7_1, FCAN.FData, value);}
  __declspec(property(get = get_AWD_1_ClutchCircuitFaultStatus, put = set_AWD_1_ClutchCircuitFaultStatus)) double AWD_1_ClutchCircuitFaultStatus;
  double get_AWD_1_Lamp2WD(void) { return com.get_can_signal_value((TCANSignal* const)&AWD_1_Lamp2WD_GW_PC_7_1, FCAN.FData);}
  void set_AWD_1_Lamp2WD(const double value) { com.set_can_signal_value((TCANSignal* const)&AWD_1_Lamp2WD_GW_PC_7_1, FCAN.FData, value);}
  __declspec(property(get = get_AWD_1_Lamp2WD, put = set_AWD_1_Lamp2WD)) double AWD_1_Lamp2WD;
  double get_AWD_1_Lamp4WDLock(void) { return com.get_can_signal_value((TCANSignal* const)&AWD_1_Lamp4WDLock_GW_PC_7_1, FCAN.FData);}
  void set_AWD_1_Lamp4WDLock(const double value) { com.set_can_signal_value((TCANSignal* const)&AWD_1_Lamp4WDLock_GW_PC_7_1, FCAN.FData, value);}
  __declspec(property(get = get_AWD_1_Lamp4WDLock, put = set_AWD_1_Lamp4WDLock)) double AWD_1_Lamp4WDLock;
  double get_AWD_1_Lamp4WDLow(void) { return com.get_can_signal_value((TCANSignal* const)&AWD_1_Lamp4WDLow_GW_PC_7_1, FCAN.FData);}
  void set_AWD_1_Lamp4WDLow(const double value) { com.set_can_signal_value((TCANSignal* const)&AWD_1_Lamp4WDLow_GW_PC_7_1, FCAN.FData, value);}
  __declspec(property(get = get_AWD_1_Lamp4WDLow, put = set_AWD_1_Lamp4WDLow)) double AWD_1_Lamp4WDLow;
  double get_AWD_1_OpreationNotice(void) { return com.get_can_signal_value((TCANSignal* const)&AWD_1_OpreationNotice_GW_PC_7_1, FCAN.FData);}
  void set_AWD_1_OpreationNotice(const double value) { com.set_can_signal_value((TCANSignal* const)&AWD_1_OpreationNotice_GW_PC_7_1, FCAN.FData, value);}
  __declspec(property(get = get_AWD_1_OpreationNotice, put = set_AWD_1_OpreationNotice)) double AWD_1_OpreationNotice;
  double get_EDL_1_FrontDiffLockGreenLamp(void) { return com.get_can_signal_value((TCANSignal* const)&EDL_1_FrontDiffLockGreenLamp_GW_PC_7_1, FCAN.FData);}
  void set_EDL_1_FrontDiffLockGreenLamp(const double value) { com.set_can_signal_value((TCANSignal* const)&EDL_1_FrontDiffLockGreenLamp_GW_PC_7_1, FCAN.FData, value);}
  __declspec(property(get = get_EDL_1_FrontDiffLockGreenLamp, put = set_EDL_1_FrontDiffLockGreenLamp)) double EDL_1_FrontDiffLockGreenLamp;
  double get_EDL_1_FrontDiffLockYellowLamp(void) { return com.get_can_signal_value((TCANSignal* const)&EDL_1_FrontDiffLockYellowLamp_GW_PC_7_1, FCAN.FData);}
  void set_EDL_1_FrontDiffLockYellowLamp(const double value) { com.set_can_signal_value((TCANSignal* const)&EDL_1_FrontDiffLockYellowLamp_GW_PC_7_1, FCAN.FData, value);}
  __declspec(property(get = get_EDL_1_FrontDiffLockYellowLamp, put = set_EDL_1_FrontDiffLockYellowLamp)) double EDL_1_FrontDiffLockYellowLamp;
  double get_EDL_1_RearDiffLockGreenLamp(void) { return com.get_can_signal_value((TCANSignal* const)&EDL_1_RearDiffLockGreenLamp_GW_PC_7_1, FCAN.FData);}
  void set_EDL_1_RearDiffLockGreenLamp(const double value) { com.set_can_signal_value((TCANSignal* const)&EDL_1_RearDiffLockGreenLamp_GW_PC_7_1, FCAN.FData, value);}
  __declspec(property(get = get_EDL_1_RearDiffLockGreenLamp, put = set_EDL_1_RearDiffLockGreenLamp)) double EDL_1_RearDiffLockGreenLamp;
  double get_EDL_1_RearDiffLockYellowLamp(void) { return com.get_can_signal_value((TCANSignal* const)&EDL_1_RearDiffLockYellowLamp_GW_PC_7_1, FCAN.FData);}
  void set_EDL_1_RearDiffLockYellowLamp(const double value) { com.set_can_signal_value((TCANSignal* const)&EDL_1_RearDiffLockYellowLamp_GW_PC_7_1, FCAN.FData, value);}
  __declspec(property(get = get_EDL_1_RearDiffLockYellowLamp, put = set_EDL_1_RearDiffLockYellowLamp)) double EDL_1_RearDiffLockYellowLamp;
  double get_EDL_1_StatusNotice(void) { return com.get_can_signal_value((TCANSignal* const)&EDL_1_StatusNotice_GW_PC_7_1, FCAN.FData);}
  void set_EDL_1_StatusNotice(const double value) { com.set_can_signal_value((TCANSignal* const)&EDL_1_StatusNotice_GW_PC_7_1, FCAN.FData, value);}
  __declspec(property(get = get_EDL_1_StatusNotice, put = set_EDL_1_StatusNotice)) double EDL_1_StatusNotice;
  double get_AWD_1_Lamp4WDAuto(void) { return com.get_can_signal_value((TCANSignal* const)&AWD_1_Lamp4WDAuto_GW_PC_7_1, FCAN.FData);}
  void set_AWD_1_Lamp4WDAuto(const double value) { com.set_can_signal_value((TCANSignal* const)&AWD_1_Lamp4WDAuto_GW_PC_7_1, FCAN.FData, value);}
  __declspec(property(get = get_AWD_1_Lamp4WDAuto, put = set_AWD_1_Lamp4WDAuto)) double AWD_1_Lamp4WDAuto;
  double get_AWD_1_Timeout_Flag(void) { return com.get_can_signal_value((TCANSignal* const)&AWD_1_Timeout_Flag_GW_PC_7_1, FCAN.FData);}
  void set_AWD_1_Timeout_Flag(const double value) { com.set_can_signal_value((TCANSignal* const)&AWD_1_Timeout_Flag_GW_PC_7_1, FCAN.FData, value);}
  __declspec(property(get = get_AWD_1_Timeout_Flag, put = set_AWD_1_Timeout_Flag)) double AWD_1_Timeout_Flag;
  double get_EDL_1_Timeout_Flag(void) { return com.get_can_signal_value((TCANSignal* const)&EDL_1_Timeout_Flag_GW_PC_7_1, FCAN.FData);}
  void set_EDL_1_Timeout_Flag(const double value) { com.set_can_signal_value((TCANSignal* const)&EDL_1_Timeout_Flag_GW_PC_7_1, FCAN.FData, value);}
  __declspec(property(get = get_EDL_1_Timeout_Flag, put = set_EDL_1_Timeout_Flag)) double EDL_1_Timeout_Flag;
  void init() { FCAN = create().FCAN; }
  TGW_PC_7_1 create() { CANMsgDecl(_GW_PC_7_1, cGW_PC_7_1, 0, 0, 8, 597) return cGW_PC_7_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message GW_PC_4_1
extern const TCANSignal EHPS_1_FaultStatus_GW_PC_4_1;
extern const TCANSignal Swaybar_1_FrontSwaybarGreenLamp_GW_PC_4_1;
extern const TCANSignal Swaybar_1_FrontSwaybarYellowLamp_GW_PC_4_1;
extern const TCANSignal Swaybar_1_StatusNotice_GW_PC_4_1;
extern const TCANSignal EHPS_1_Timeout_Flag_GW_PC_4_1;
extern const TCANSignal Swaybar_1_Timeout_Flag_GW_PC_4_1;
struct _GW_PC_4_1;
typedef struct _GW_PC_4_1 TGW_PC_4_1;
struct _GW_PC_4_1{
  TCAN FCAN;
  double get_EHPS_1_FaultStatus(void) { return com.get_can_signal_value((TCANSignal* const)&EHPS_1_FaultStatus_GW_PC_4_1, FCAN.FData);}
  void set_EHPS_1_FaultStatus(const double value) { com.set_can_signal_value((TCANSignal* const)&EHPS_1_FaultStatus_GW_PC_4_1, FCAN.FData, value);}
  __declspec(property(get = get_EHPS_1_FaultStatus, put = set_EHPS_1_FaultStatus)) double EHPS_1_FaultStatus;
  double get_Swaybar_1_FrontSwaybarGreenLamp(void) { return com.get_can_signal_value((TCANSignal* const)&Swaybar_1_FrontSwaybarGreenLamp_GW_PC_4_1, FCAN.FData);}
  void set_Swaybar_1_FrontSwaybarGreenLamp(const double value) { com.set_can_signal_value((TCANSignal* const)&Swaybar_1_FrontSwaybarGreenLamp_GW_PC_4_1, FCAN.FData, value);}
  __declspec(property(get = get_Swaybar_1_FrontSwaybarGreenLamp, put = set_Swaybar_1_FrontSwaybarGreenLamp)) double Swaybar_1_FrontSwaybarGreenLamp;
  double get_Swaybar_1_FrontSwaybarYellowLamp(void) { return com.get_can_signal_value((TCANSignal* const)&Swaybar_1_FrontSwaybarYellowLamp_GW_PC_4_1, FCAN.FData);}
  void set_Swaybar_1_FrontSwaybarYellowLamp(const double value) { com.set_can_signal_value((TCANSignal* const)&Swaybar_1_FrontSwaybarYellowLamp_GW_PC_4_1, FCAN.FData, value);}
  __declspec(property(get = get_Swaybar_1_FrontSwaybarYellowLamp, put = set_Swaybar_1_FrontSwaybarYellowLamp)) double Swaybar_1_FrontSwaybarYellowLamp;
  double get_Swaybar_1_StatusNotice(void) { return com.get_can_signal_value((TCANSignal* const)&Swaybar_1_StatusNotice_GW_PC_4_1, FCAN.FData);}
  void set_Swaybar_1_StatusNotice(const double value) { com.set_can_signal_value((TCANSignal* const)&Swaybar_1_StatusNotice_GW_PC_4_1, FCAN.FData, value);}
  __declspec(property(get = get_Swaybar_1_StatusNotice, put = set_Swaybar_1_StatusNotice)) double Swaybar_1_StatusNotice;
  double get_EHPS_1_Timeout_Flag(void) { return com.get_can_signal_value((TCANSignal* const)&EHPS_1_Timeout_Flag_GW_PC_4_1, FCAN.FData);}
  void set_EHPS_1_Timeout_Flag(const double value) { com.set_can_signal_value((TCANSignal* const)&EHPS_1_Timeout_Flag_GW_PC_4_1, FCAN.FData, value);}
  __declspec(property(get = get_EHPS_1_Timeout_Flag, put = set_EHPS_1_Timeout_Flag)) double EHPS_1_Timeout_Flag;
  double get_Swaybar_1_Timeout_Flag(void) { return com.get_can_signal_value((TCANSignal* const)&Swaybar_1_Timeout_Flag_GW_PC_4_1, FCAN.FData);}
  void set_Swaybar_1_Timeout_Flag(const double value) { com.set_can_signal_value((TCANSignal* const)&Swaybar_1_Timeout_Flag_GW_PC_4_1, FCAN.FData, value);}
  __declspec(property(get = get_Swaybar_1_Timeout_Flag, put = set_Swaybar_1_Timeout_Flag)) double Swaybar_1_Timeout_Flag;
  void init() { FCAN = create().FCAN; }
  TGW_PC_4_1 create() { CANMsgDecl(_GW_PC_4_1, cGW_PC_4_1, 0, 0, 8, 928) return cGW_PC_4_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message GW_BD_14_1
extern const TCANSignal AC_1_TemperatureLevel_GW_BD_14_1;
extern const TCANSignal AC_1_AirDistributeMode_GW_BD_14_1;
extern const TCANSignal AC_1_AirCirculationMode_GW_BD_14_1;
extern const TCANSignal AC_1_BlowerSpeedLevel_GW_BD_14_1;
extern const TCANSignal AC_1_ACButtonSts_GW_BD_14_1;
extern const TCANSignal AC_1_FrontDefrostButtonSts_GW_BD_14_1;
extern const TCANSignal AC_1_RearDefrostButtonSts_GW_BD_14_1;
extern const TCANSignal AC_1_ACSystemSts_GW_BD_14_1;
extern const TCANSignal AC_1_PTCButtonSts_GW_BD_14_1;
extern const TCANSignal AC_1_BlowerSpeedLevelRear_GW_BD_14_1;
extern const TCANSignal AC_1_ButtonTriggerStatus_GW_BD_14_1;
extern const TCANSignal AC_1_RearModeSts_GW_BD_14_1;
extern const TCANSignal AC_2_DriverSetTemperature_GW_BD_14_1;
extern const TCANSignal AC_2_PngSetTemperature_GW_BD_14_1;
extern const TCANSignal AC_2_OutsideTemperature_GW_BD_14_1;
extern const TCANSignal AC_2_OutsideTemperatureValid_GW_BD_14_1;
extern const TCANSignal AC_2_DualMode_GW_BD_14_1;
extern const TCANSignal AC_2_AUTOButtonSts_GW_BD_14_1;
extern const TCANSignal AC_2_AUTOPassengerButtonSts_GW_BD_14_1;
extern const TCANSignal AC_2_DualButtonSts_GW_BD_14_1;
extern const TCANSignal AC_1_ACSelfCleanModeSts_GW_BD_14_1;
extern const TCANSignal AC_1_ACMaxSwSts_GW_BD_14_1;
extern const TCANSignal AC_2_acAutoState_GW_BD_14_1;
extern const TCANSignal AC_2_ModeAutoState_GW_BD_14_1;
extern const TCANSignal AC_2_NcfAutoState_GW_BD_14_1;
extern const TCANSignal AC_2_FanAutoState_GW_BD_14_1;
extern const TCANSignal AC_1_Timeout_Flag_GW_BD_14_1;
extern const TCANSignal AC_2_Timeout_Flag_GW_BD_14_1;
struct _GW_BD_14_1;
typedef struct _GW_BD_14_1 TGW_BD_14_1;
struct _GW_BD_14_1{
  TCAN FCAN;
  double get_AC_1_TemperatureLevel(void) { return com.get_can_signal_value((TCANSignal* const)&AC_1_TemperatureLevel_GW_BD_14_1, FCAN.FData);}
  void set_AC_1_TemperatureLevel(const double value) { com.set_can_signal_value((TCANSignal* const)&AC_1_TemperatureLevel_GW_BD_14_1, FCAN.FData, value);}
  __declspec(property(get = get_AC_1_TemperatureLevel, put = set_AC_1_TemperatureLevel)) double AC_1_TemperatureLevel;
  double get_AC_1_AirDistributeMode(void) { return com.get_can_signal_value((TCANSignal* const)&AC_1_AirDistributeMode_GW_BD_14_1, FCAN.FData);}
  void set_AC_1_AirDistributeMode(const double value) { com.set_can_signal_value((TCANSignal* const)&AC_1_AirDistributeMode_GW_BD_14_1, FCAN.FData, value);}
  __declspec(property(get = get_AC_1_AirDistributeMode, put = set_AC_1_AirDistributeMode)) double AC_1_AirDistributeMode;
  double get_AC_1_AirCirculationMode(void) { return com.get_can_signal_value((TCANSignal* const)&AC_1_AirCirculationMode_GW_BD_14_1, FCAN.FData);}
  void set_AC_1_AirCirculationMode(const double value) { com.set_can_signal_value((TCANSignal* const)&AC_1_AirCirculationMode_GW_BD_14_1, FCAN.FData, value);}
  __declspec(property(get = get_AC_1_AirCirculationMode, put = set_AC_1_AirCirculationMode)) double AC_1_AirCirculationMode;
  double get_AC_1_BlowerSpeedLevel(void) { return com.get_can_signal_value((TCANSignal* const)&AC_1_BlowerSpeedLevel_GW_BD_14_1, FCAN.FData);}
  void set_AC_1_BlowerSpeedLevel(const double value) { com.set_can_signal_value((TCANSignal* const)&AC_1_BlowerSpeedLevel_GW_BD_14_1, FCAN.FData, value);}
  __declspec(property(get = get_AC_1_BlowerSpeedLevel, put = set_AC_1_BlowerSpeedLevel)) double AC_1_BlowerSpeedLevel;
  double get_AC_1_ACButtonSts(void) { return com.get_can_signal_value((TCANSignal* const)&AC_1_ACButtonSts_GW_BD_14_1, FCAN.FData);}
  void set_AC_1_ACButtonSts(const double value) { com.set_can_signal_value((TCANSignal* const)&AC_1_ACButtonSts_GW_BD_14_1, FCAN.FData, value);}
  __declspec(property(get = get_AC_1_ACButtonSts, put = set_AC_1_ACButtonSts)) double AC_1_ACButtonSts;
  double get_AC_1_FrontDefrostButtonSts(void) { return com.get_can_signal_value((TCANSignal* const)&AC_1_FrontDefrostButtonSts_GW_BD_14_1, FCAN.FData);}
  void set_AC_1_FrontDefrostButtonSts(const double value) { com.set_can_signal_value((TCANSignal* const)&AC_1_FrontDefrostButtonSts_GW_BD_14_1, FCAN.FData, value);}
  __declspec(property(get = get_AC_1_FrontDefrostButtonSts, put = set_AC_1_FrontDefrostButtonSts)) double AC_1_FrontDefrostButtonSts;
  double get_AC_1_RearDefrostButtonSts(void) { return com.get_can_signal_value((TCANSignal* const)&AC_1_RearDefrostButtonSts_GW_BD_14_1, FCAN.FData);}
  void set_AC_1_RearDefrostButtonSts(const double value) { com.set_can_signal_value((TCANSignal* const)&AC_1_RearDefrostButtonSts_GW_BD_14_1, FCAN.FData, value);}
  __declspec(property(get = get_AC_1_RearDefrostButtonSts, put = set_AC_1_RearDefrostButtonSts)) double AC_1_RearDefrostButtonSts;
  double get_AC_1_ACSystemSts(void) { return com.get_can_signal_value((TCANSignal* const)&AC_1_ACSystemSts_GW_BD_14_1, FCAN.FData);}
  void set_AC_1_ACSystemSts(const double value) { com.set_can_signal_value((TCANSignal* const)&AC_1_ACSystemSts_GW_BD_14_1, FCAN.FData, value);}
  __declspec(property(get = get_AC_1_ACSystemSts, put = set_AC_1_ACSystemSts)) double AC_1_ACSystemSts;
  double get_AC_1_PTCButtonSts(void) { return com.get_can_signal_value((TCANSignal* const)&AC_1_PTCButtonSts_GW_BD_14_1, FCAN.FData);}
  void set_AC_1_PTCButtonSts(const double value) { com.set_can_signal_value((TCANSignal* const)&AC_1_PTCButtonSts_GW_BD_14_1, FCAN.FData, value);}
  __declspec(property(get = get_AC_1_PTCButtonSts, put = set_AC_1_PTCButtonSts)) double AC_1_PTCButtonSts;
  double get_AC_1_BlowerSpeedLevelRear(void) { return com.get_can_signal_value((TCANSignal* const)&AC_1_BlowerSpeedLevelRear_GW_BD_14_1, FCAN.FData);}
  void set_AC_1_BlowerSpeedLevelRear(const double value) { com.set_can_signal_value((TCANSignal* const)&AC_1_BlowerSpeedLevelRear_GW_BD_14_1, FCAN.FData, value);}
  __declspec(property(get = get_AC_1_BlowerSpeedLevelRear, put = set_AC_1_BlowerSpeedLevelRear)) double AC_1_BlowerSpeedLevelRear;
  double get_AC_1_ButtonTriggerStatus(void) { return com.get_can_signal_value((TCANSignal* const)&AC_1_ButtonTriggerStatus_GW_BD_14_1, FCAN.FData);}
  void set_AC_1_ButtonTriggerStatus(const double value) { com.set_can_signal_value((TCANSignal* const)&AC_1_ButtonTriggerStatus_GW_BD_14_1, FCAN.FData, value);}
  __declspec(property(get = get_AC_1_ButtonTriggerStatus, put = set_AC_1_ButtonTriggerStatus)) double AC_1_ButtonTriggerStatus;
  double get_AC_1_RearModeSts(void) { return com.get_can_signal_value((TCANSignal* const)&AC_1_RearModeSts_GW_BD_14_1, FCAN.FData);}
  void set_AC_1_RearModeSts(const double value) { com.set_can_signal_value((TCANSignal* const)&AC_1_RearModeSts_GW_BD_14_1, FCAN.FData, value);}
  __declspec(property(get = get_AC_1_RearModeSts, put = set_AC_1_RearModeSts)) double AC_1_RearModeSts;
  double get_AC_2_DriverSetTemperature(void) { return com.get_can_signal_value((TCANSignal* const)&AC_2_DriverSetTemperature_GW_BD_14_1, FCAN.FData);}
  void set_AC_2_DriverSetTemperature(const double value) { com.set_can_signal_value((TCANSignal* const)&AC_2_DriverSetTemperature_GW_BD_14_1, FCAN.FData, value);}
  __declspec(property(get = get_AC_2_DriverSetTemperature, put = set_AC_2_DriverSetTemperature)) double AC_2_DriverSetTemperature;
  double get_AC_2_PngSetTemperature(void) { return com.get_can_signal_value((TCANSignal* const)&AC_2_PngSetTemperature_GW_BD_14_1, FCAN.FData);}
  void set_AC_2_PngSetTemperature(const double value) { com.set_can_signal_value((TCANSignal* const)&AC_2_PngSetTemperature_GW_BD_14_1, FCAN.FData, value);}
  __declspec(property(get = get_AC_2_PngSetTemperature, put = set_AC_2_PngSetTemperature)) double AC_2_PngSetTemperature;
  double get_AC_2_OutsideTemperature(void) { return com.get_can_signal_value((TCANSignal* const)&AC_2_OutsideTemperature_GW_BD_14_1, FCAN.FData);}
  void set_AC_2_OutsideTemperature(const double value) { com.set_can_signal_value((TCANSignal* const)&AC_2_OutsideTemperature_GW_BD_14_1, FCAN.FData, value);}
  __declspec(property(get = get_AC_2_OutsideTemperature, put = set_AC_2_OutsideTemperature)) double AC_2_OutsideTemperature;
  double get_AC_2_OutsideTemperatureValid(void) { return com.get_can_signal_value((TCANSignal* const)&AC_2_OutsideTemperatureValid_GW_BD_14_1, FCAN.FData);}
  void set_AC_2_OutsideTemperatureValid(const double value) { com.set_can_signal_value((TCANSignal* const)&AC_2_OutsideTemperatureValid_GW_BD_14_1, FCAN.FData, value);}
  __declspec(property(get = get_AC_2_OutsideTemperatureValid, put = set_AC_2_OutsideTemperatureValid)) double AC_2_OutsideTemperatureValid;
  double get_AC_2_DualMode(void) { return com.get_can_signal_value((TCANSignal* const)&AC_2_DualMode_GW_BD_14_1, FCAN.FData);}
  void set_AC_2_DualMode(const double value) { com.set_can_signal_value((TCANSignal* const)&AC_2_DualMode_GW_BD_14_1, FCAN.FData, value);}
  __declspec(property(get = get_AC_2_DualMode, put = set_AC_2_DualMode)) double AC_2_DualMode;
  double get_AC_2_AUTOButtonSts(void) { return com.get_can_signal_value((TCANSignal* const)&AC_2_AUTOButtonSts_GW_BD_14_1, FCAN.FData);}
  void set_AC_2_AUTOButtonSts(const double value) { com.set_can_signal_value((TCANSignal* const)&AC_2_AUTOButtonSts_GW_BD_14_1, FCAN.FData, value);}
  __declspec(property(get = get_AC_2_AUTOButtonSts, put = set_AC_2_AUTOButtonSts)) double AC_2_AUTOButtonSts;
  double get_AC_2_AUTOPassengerButtonSts(void) { return com.get_can_signal_value((TCANSignal* const)&AC_2_AUTOPassengerButtonSts_GW_BD_14_1, FCAN.FData);}
  void set_AC_2_AUTOPassengerButtonSts(const double value) { com.set_can_signal_value((TCANSignal* const)&AC_2_AUTOPassengerButtonSts_GW_BD_14_1, FCAN.FData, value);}
  __declspec(property(get = get_AC_2_AUTOPassengerButtonSts, put = set_AC_2_AUTOPassengerButtonSts)) double AC_2_AUTOPassengerButtonSts;
  double get_AC_2_DualButtonSts(void) { return com.get_can_signal_value((TCANSignal* const)&AC_2_DualButtonSts_GW_BD_14_1, FCAN.FData);}
  void set_AC_2_DualButtonSts(const double value) { com.set_can_signal_value((TCANSignal* const)&AC_2_DualButtonSts_GW_BD_14_1, FCAN.FData, value);}
  __declspec(property(get = get_AC_2_DualButtonSts, put = set_AC_2_DualButtonSts)) double AC_2_DualButtonSts;
  double get_AC_1_ACSelfCleanModeSts(void) { return com.get_can_signal_value((TCANSignal* const)&AC_1_ACSelfCleanModeSts_GW_BD_14_1, FCAN.FData);}
  void set_AC_1_ACSelfCleanModeSts(const double value) { com.set_can_signal_value((TCANSignal* const)&AC_1_ACSelfCleanModeSts_GW_BD_14_1, FCAN.FData, value);}
  __declspec(property(get = get_AC_1_ACSelfCleanModeSts, put = set_AC_1_ACSelfCleanModeSts)) double AC_1_ACSelfCleanModeSts;
  double get_AC_1_ACMaxSwSts(void) { return com.get_can_signal_value((TCANSignal* const)&AC_1_ACMaxSwSts_GW_BD_14_1, FCAN.FData);}
  void set_AC_1_ACMaxSwSts(const double value) { com.set_can_signal_value((TCANSignal* const)&AC_1_ACMaxSwSts_GW_BD_14_1, FCAN.FData, value);}
  __declspec(property(get = get_AC_1_ACMaxSwSts, put = set_AC_1_ACMaxSwSts)) double AC_1_ACMaxSwSts;
  double get_AC_2_acAutoState(void) { return com.get_can_signal_value((TCANSignal* const)&AC_2_acAutoState_GW_BD_14_1, FCAN.FData);}
  void set_AC_2_acAutoState(const double value) { com.set_can_signal_value((TCANSignal* const)&AC_2_acAutoState_GW_BD_14_1, FCAN.FData, value);}
  __declspec(property(get = get_AC_2_acAutoState, put = set_AC_2_acAutoState)) double AC_2_acAutoState;
  double get_AC_2_ModeAutoState(void) { return com.get_can_signal_value((TCANSignal* const)&AC_2_ModeAutoState_GW_BD_14_1, FCAN.FData);}
  void set_AC_2_ModeAutoState(const double value) { com.set_can_signal_value((TCANSignal* const)&AC_2_ModeAutoState_GW_BD_14_1, FCAN.FData, value);}
  __declspec(property(get = get_AC_2_ModeAutoState, put = set_AC_2_ModeAutoState)) double AC_2_ModeAutoState;
  double get_AC_2_NcfAutoState(void) { return com.get_can_signal_value((TCANSignal* const)&AC_2_NcfAutoState_GW_BD_14_1, FCAN.FData);}
  void set_AC_2_NcfAutoState(const double value) { com.set_can_signal_value((TCANSignal* const)&AC_2_NcfAutoState_GW_BD_14_1, FCAN.FData, value);}
  __declspec(property(get = get_AC_2_NcfAutoState, put = set_AC_2_NcfAutoState)) double AC_2_NcfAutoState;
  double get_AC_2_FanAutoState(void) { return com.get_can_signal_value((TCANSignal* const)&AC_2_FanAutoState_GW_BD_14_1, FCAN.FData);}
  void set_AC_2_FanAutoState(const double value) { com.set_can_signal_value((TCANSignal* const)&AC_2_FanAutoState_GW_BD_14_1, FCAN.FData, value);}
  __declspec(property(get = get_AC_2_FanAutoState, put = set_AC_2_FanAutoState)) double AC_2_FanAutoState;
  double get_AC_1_Timeout_Flag(void) { return com.get_can_signal_value((TCANSignal* const)&AC_1_Timeout_Flag_GW_BD_14_1, FCAN.FData);}
  void set_AC_1_Timeout_Flag(const double value) { com.set_can_signal_value((TCANSignal* const)&AC_1_Timeout_Flag_GW_BD_14_1, FCAN.FData, value);}
  __declspec(property(get = get_AC_1_Timeout_Flag, put = set_AC_1_Timeout_Flag)) double AC_1_Timeout_Flag;
  double get_AC_2_Timeout_Flag(void) { return com.get_can_signal_value((TCANSignal* const)&AC_2_Timeout_Flag_GW_BD_14_1, FCAN.FData);}
  void set_AC_2_Timeout_Flag(const double value) { com.set_can_signal_value((TCANSignal* const)&AC_2_Timeout_Flag_GW_BD_14_1, FCAN.FData, value);}
  __declspec(property(get = get_AC_2_Timeout_Flag, put = set_AC_2_Timeout_Flag)) double AC_2_Timeout_Flag;
  void init() { FCAN = create().FCAN; }
  TGW_BD_14_1 create() { CANMsgDecl(_GW_BD_14_1, cGW_BD_14_1, 0, 0, 8, 940) return cGW_BD_14_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message GW_BD_29_1
extern const TCANSignal SCU_1_FLSeatHeatLvlSts_GW_BD_29_1;
extern const TCANSignal SCU_1_FRSeatHeatLvlSts_GW_BD_29_1;
extern const TCANSignal SCU_1_FLSeatMassgLvlSts_GW_BD_29_1;
extern const TCANSignal SCU_1_FLSeatMassgModSts_GW_BD_29_1;
extern const TCANSignal SCU_1_FaultsStatus_GW_BD_29_1;
extern const TCANSignal WCM_1_ChargingSts_GW_BD_29_1;
extern const TCANSignal WCM_1_FailureSts_GW_BD_29_1;
extern const TCANSignal WCM_1_WirelessChargeSwtSts_GW_BD_29_1;
extern const TCANSignal WCM_1_PhoneReminder_GW_BD_29_1;
extern const TCANSignal EPM_1_EPMModSts_GW_BD_29_1;
extern const TCANSignal SCU_1_FLSeatVentLvlSts_GW_BD_29_1;
extern const TCANSignal SCU_1_FRSeatVentLvlSts_GW_BD_29_1;
extern const TCANSignal SCU_1_Timeout_Flag_GW_BD_29_1;
extern const TCANSignal WCM_1_Timeout_Flag_GW_BD_29_1;
extern const TCANSignal EPM_1_Timeout_Flag_GW_BD_29_1;
struct _GW_BD_29_1;
typedef struct _GW_BD_29_1 TGW_BD_29_1;
struct _GW_BD_29_1{
  TCAN FCAN;
  double get_SCU_1_FLSeatHeatLvlSts(void) { return com.get_can_signal_value((TCANSignal* const)&SCU_1_FLSeatHeatLvlSts_GW_BD_29_1, FCAN.FData);}
  void set_SCU_1_FLSeatHeatLvlSts(const double value) { com.set_can_signal_value((TCANSignal* const)&SCU_1_FLSeatHeatLvlSts_GW_BD_29_1, FCAN.FData, value);}
  __declspec(property(get = get_SCU_1_FLSeatHeatLvlSts, put = set_SCU_1_FLSeatHeatLvlSts)) double SCU_1_FLSeatHeatLvlSts;
  double get_SCU_1_FRSeatHeatLvlSts(void) { return com.get_can_signal_value((TCANSignal* const)&SCU_1_FRSeatHeatLvlSts_GW_BD_29_1, FCAN.FData);}
  void set_SCU_1_FRSeatHeatLvlSts(const double value) { com.set_can_signal_value((TCANSignal* const)&SCU_1_FRSeatHeatLvlSts_GW_BD_29_1, FCAN.FData, value);}
  __declspec(property(get = get_SCU_1_FRSeatHeatLvlSts, put = set_SCU_1_FRSeatHeatLvlSts)) double SCU_1_FRSeatHeatLvlSts;
  double get_SCU_1_FLSeatMassgLvlSts(void) { return com.get_can_signal_value((TCANSignal* const)&SCU_1_FLSeatMassgLvlSts_GW_BD_29_1, FCAN.FData);}
  void set_SCU_1_FLSeatMassgLvlSts(const double value) { com.set_can_signal_value((TCANSignal* const)&SCU_1_FLSeatMassgLvlSts_GW_BD_29_1, FCAN.FData, value);}
  __declspec(property(get = get_SCU_1_FLSeatMassgLvlSts, put = set_SCU_1_FLSeatMassgLvlSts)) double SCU_1_FLSeatMassgLvlSts;
  double get_SCU_1_FLSeatMassgModSts(void) { return com.get_can_signal_value((TCANSignal* const)&SCU_1_FLSeatMassgModSts_GW_BD_29_1, FCAN.FData);}
  void set_SCU_1_FLSeatMassgModSts(const double value) { com.set_can_signal_value((TCANSignal* const)&SCU_1_FLSeatMassgModSts_GW_BD_29_1, FCAN.FData, value);}
  __declspec(property(get = get_SCU_1_FLSeatMassgModSts, put = set_SCU_1_FLSeatMassgModSts)) double SCU_1_FLSeatMassgModSts;
  double get_SCU_1_FaultsStatus(void) { return com.get_can_signal_value((TCANSignal* const)&SCU_1_FaultsStatus_GW_BD_29_1, FCAN.FData);}
  void set_SCU_1_FaultsStatus(const double value) { com.set_can_signal_value((TCANSignal* const)&SCU_1_FaultsStatus_GW_BD_29_1, FCAN.FData, value);}
  __declspec(property(get = get_SCU_1_FaultsStatus, put = set_SCU_1_FaultsStatus)) double SCU_1_FaultsStatus;
  double get_WCM_1_ChargingSts(void) { return com.get_can_signal_value((TCANSignal* const)&WCM_1_ChargingSts_GW_BD_29_1, FCAN.FData);}
  void set_WCM_1_ChargingSts(const double value) { com.set_can_signal_value((TCANSignal* const)&WCM_1_ChargingSts_GW_BD_29_1, FCAN.FData, value);}
  __declspec(property(get = get_WCM_1_ChargingSts, put = set_WCM_1_ChargingSts)) double WCM_1_ChargingSts;
  double get_WCM_1_FailureSts(void) { return com.get_can_signal_value((TCANSignal* const)&WCM_1_FailureSts_GW_BD_29_1, FCAN.FData);}
  void set_WCM_1_FailureSts(const double value) { com.set_can_signal_value((TCANSignal* const)&WCM_1_FailureSts_GW_BD_29_1, FCAN.FData, value);}
  __declspec(property(get = get_WCM_1_FailureSts, put = set_WCM_1_FailureSts)) double WCM_1_FailureSts;
  double get_WCM_1_WirelessChargeSwtSts(void) { return com.get_can_signal_value((TCANSignal* const)&WCM_1_WirelessChargeSwtSts_GW_BD_29_1, FCAN.FData);}
  void set_WCM_1_WirelessChargeSwtSts(const double value) { com.set_can_signal_value((TCANSignal* const)&WCM_1_WirelessChargeSwtSts_GW_BD_29_1, FCAN.FData, value);}
  __declspec(property(get = get_WCM_1_WirelessChargeSwtSts, put = set_WCM_1_WirelessChargeSwtSts)) double WCM_1_WirelessChargeSwtSts;
  double get_WCM_1_PhoneReminder(void) { return com.get_can_signal_value((TCANSignal* const)&WCM_1_PhoneReminder_GW_BD_29_1, FCAN.FData);}
  void set_WCM_1_PhoneReminder(const double value) { com.set_can_signal_value((TCANSignal* const)&WCM_1_PhoneReminder_GW_BD_29_1, FCAN.FData, value);}
  __declspec(property(get = get_WCM_1_PhoneReminder, put = set_WCM_1_PhoneReminder)) double WCM_1_PhoneReminder;
  double get_EPM_1_EPMModSts(void) { return com.get_can_signal_value((TCANSignal* const)&EPM_1_EPMModSts_GW_BD_29_1, FCAN.FData);}
  void set_EPM_1_EPMModSts(const double value) { com.set_can_signal_value((TCANSignal* const)&EPM_1_EPMModSts_GW_BD_29_1, FCAN.FData, value);}
  __declspec(property(get = get_EPM_1_EPMModSts, put = set_EPM_1_EPMModSts)) double EPM_1_EPMModSts;
  double get_SCU_1_FLSeatVentLvlSts(void) { return com.get_can_signal_value((TCANSignal* const)&SCU_1_FLSeatVentLvlSts_GW_BD_29_1, FCAN.FData);}
  void set_SCU_1_FLSeatVentLvlSts(const double value) { com.set_can_signal_value((TCANSignal* const)&SCU_1_FLSeatVentLvlSts_GW_BD_29_1, FCAN.FData, value);}
  __declspec(property(get = get_SCU_1_FLSeatVentLvlSts, put = set_SCU_1_FLSeatVentLvlSts)) double SCU_1_FLSeatVentLvlSts;
  double get_SCU_1_FRSeatVentLvlSts(void) { return com.get_can_signal_value((TCANSignal* const)&SCU_1_FRSeatVentLvlSts_GW_BD_29_1, FCAN.FData);}
  void set_SCU_1_FRSeatVentLvlSts(const double value) { com.set_can_signal_value((TCANSignal* const)&SCU_1_FRSeatVentLvlSts_GW_BD_29_1, FCAN.FData, value);}
  __declspec(property(get = get_SCU_1_FRSeatVentLvlSts, put = set_SCU_1_FRSeatVentLvlSts)) double SCU_1_FRSeatVentLvlSts;
  double get_SCU_1_Timeout_Flag(void) { return com.get_can_signal_value((TCANSignal* const)&SCU_1_Timeout_Flag_GW_BD_29_1, FCAN.FData);}
  void set_SCU_1_Timeout_Flag(const double value) { com.set_can_signal_value((TCANSignal* const)&SCU_1_Timeout_Flag_GW_BD_29_1, FCAN.FData, value);}
  __declspec(property(get = get_SCU_1_Timeout_Flag, put = set_SCU_1_Timeout_Flag)) double SCU_1_Timeout_Flag;
  double get_WCM_1_Timeout_Flag(void) { return com.get_can_signal_value((TCANSignal* const)&WCM_1_Timeout_Flag_GW_BD_29_1, FCAN.FData);}
  void set_WCM_1_Timeout_Flag(const double value) { com.set_can_signal_value((TCANSignal* const)&WCM_1_Timeout_Flag_GW_BD_29_1, FCAN.FData, value);}
  __declspec(property(get = get_WCM_1_Timeout_Flag, put = set_WCM_1_Timeout_Flag)) double WCM_1_Timeout_Flag;
  double get_EPM_1_Timeout_Flag(void) { return com.get_can_signal_value((TCANSignal* const)&EPM_1_Timeout_Flag_GW_BD_29_1, FCAN.FData);}
  void set_EPM_1_Timeout_Flag(const double value) { com.set_can_signal_value((TCANSignal* const)&EPM_1_Timeout_Flag_GW_BD_29_1, FCAN.FData, value);}
  __declspec(property(get = get_EPM_1_Timeout_Flag, put = set_EPM_1_Timeout_Flag)) double EPM_1_Timeout_Flag;
  void init() { FCAN = create().FCAN; }
  TGW_BD_29_1 create() { CANMsgDecl(_GW_BD_29_1, cGW_BD_29_1, 0, 0, 8, 972) return cGW_BD_29_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message GW_PC_26_1
extern const TCANSignal EMS_11_EngSpd_GW_PC_26_1;
extern const TCANSignal EMS_11_EngSpdValid_GW_PC_26_1;
extern const TCANSignal EMS_11_SVS_GW_PC_26_1;
extern const TCANSignal EMS_11_MIL_GW_PC_26_1;
extern const TCANSignal EMS_11_PressureRelief_Textinfo_GW_PC_26_1;
extern const TCANSignal EMS_14_OilPressureLamp_GW_PC_26_1;
extern const TCANSignal EMS_14_GPFState_GW_PC_26_1;
extern const TCANSignal EMS_14_engCoolantTempValid_GW_PC_26_1;
extern const TCANSignal EMS_14_engCoolantTemp_GW_PC_26_1;
extern const TCANSignal EMS_14_FuelConsumption_GW_PC_26_1;
extern const TCANSignal EMS_14_OilPressure_GW_PC_26_1;
extern const TCANSignal EMS_11_Timeout_Flag_GW_PC_26_1;
extern const TCANSignal EMS_14_Timeout_Flag_GW_PC_26_1;
struct _GW_PC_26_1;
typedef struct _GW_PC_26_1 TGW_PC_26_1;
struct _GW_PC_26_1{
  TCAN FCAN;
  double get_EMS_11_EngSpd(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_11_EngSpd_GW_PC_26_1, FCAN.FData);}
  void set_EMS_11_EngSpd(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_11_EngSpd_GW_PC_26_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_11_EngSpd, put = set_EMS_11_EngSpd)) double EMS_11_EngSpd;
  double get_EMS_11_EngSpdValid(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_11_EngSpdValid_GW_PC_26_1, FCAN.FData);}
  void set_EMS_11_EngSpdValid(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_11_EngSpdValid_GW_PC_26_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_11_EngSpdValid, put = set_EMS_11_EngSpdValid)) double EMS_11_EngSpdValid;
  double get_EMS_11_SVS(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_11_SVS_GW_PC_26_1, FCAN.FData);}
  void set_EMS_11_SVS(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_11_SVS_GW_PC_26_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_11_SVS, put = set_EMS_11_SVS)) double EMS_11_SVS;
  double get_EMS_11_MIL(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_11_MIL_GW_PC_26_1, FCAN.FData);}
  void set_EMS_11_MIL(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_11_MIL_GW_PC_26_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_11_MIL, put = set_EMS_11_MIL)) double EMS_11_MIL;
  double get_EMS_11_PressureRelief_Textinfo(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_11_PressureRelief_Textinfo_GW_PC_26_1, FCAN.FData);}
  void set_EMS_11_PressureRelief_Textinfo(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_11_PressureRelief_Textinfo_GW_PC_26_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_11_PressureRelief_Textinfo, put = set_EMS_11_PressureRelief_Textinfo)) double EMS_11_PressureRelief_Textinfo;
  double get_EMS_14_OilPressureLamp(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_14_OilPressureLamp_GW_PC_26_1, FCAN.FData);}
  void set_EMS_14_OilPressureLamp(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_14_OilPressureLamp_GW_PC_26_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_14_OilPressureLamp, put = set_EMS_14_OilPressureLamp)) double EMS_14_OilPressureLamp;
  double get_EMS_14_GPFState(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_14_GPFState_GW_PC_26_1, FCAN.FData);}
  void set_EMS_14_GPFState(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_14_GPFState_GW_PC_26_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_14_GPFState, put = set_EMS_14_GPFState)) double EMS_14_GPFState;
  double get_EMS_14_engCoolantTempValid(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_14_engCoolantTempValid_GW_PC_26_1, FCAN.FData);}
  void set_EMS_14_engCoolantTempValid(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_14_engCoolantTempValid_GW_PC_26_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_14_engCoolantTempValid, put = set_EMS_14_engCoolantTempValid)) double EMS_14_engCoolantTempValid;
  double get_EMS_14_engCoolantTemp(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_14_engCoolantTemp_GW_PC_26_1, FCAN.FData);}
  void set_EMS_14_engCoolantTemp(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_14_engCoolantTemp_GW_PC_26_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_14_engCoolantTemp, put = set_EMS_14_engCoolantTemp)) double EMS_14_engCoolantTemp;
  double get_EMS_14_FuelConsumption(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_14_FuelConsumption_GW_PC_26_1, FCAN.FData);}
  void set_EMS_14_FuelConsumption(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_14_FuelConsumption_GW_PC_26_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_14_FuelConsumption, put = set_EMS_14_FuelConsumption)) double EMS_14_FuelConsumption;
  double get_EMS_14_OilPressure(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_14_OilPressure_GW_PC_26_1, FCAN.FData);}
  void set_EMS_14_OilPressure(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_14_OilPressure_GW_PC_26_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_14_OilPressure, put = set_EMS_14_OilPressure)) double EMS_14_OilPressure;
  double get_EMS_11_Timeout_Flag(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_11_Timeout_Flag_GW_PC_26_1, FCAN.FData);}
  void set_EMS_11_Timeout_Flag(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_11_Timeout_Flag_GW_PC_26_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_11_Timeout_Flag, put = set_EMS_11_Timeout_Flag)) double EMS_11_Timeout_Flag;
  double get_EMS_14_Timeout_Flag(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_14_Timeout_Flag_GW_PC_26_1, FCAN.FData);}
  void set_EMS_14_Timeout_Flag(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_14_Timeout_Flag_GW_PC_26_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_14_Timeout_Flag, put = set_EMS_14_Timeout_Flag)) double EMS_14_Timeout_Flag;
  void init() { FCAN = create().FCAN; }
  TGW_PC_26_1 create() { CANMsgDecl(_GW_PC_26_1, cGW_PC_26_1, 0, 0, 8, 373) return cGW_PC_26_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message GW_PC_31_1
extern const TCANSignal GCU_12_StaFaultOut_GW_PC_31_1;
extern const TCANSignal MCU_11_Motor_TempFault_GW_PC_31_1;
extern const TCANSignal MCU_11_Motor_ContrlTempFault_GW_PC_31_1;
extern const TCANSignal MCU_11_StaFaultOut_GW_PC_31_1;
extern const TCANSignal GCU_12_Timeout_Flag_GW_PC_31_1;
extern const TCANSignal MCU_11_Timeout_Flag_GW_PC_31_1;
struct _GW_PC_31_1;
typedef struct _GW_PC_31_1 TGW_PC_31_1;
struct _GW_PC_31_1{
  TCAN FCAN;
  double get_GCU_12_StaFaultOut(void) { return com.get_can_signal_value((TCANSignal* const)&GCU_12_StaFaultOut_GW_PC_31_1, FCAN.FData);}
  void set_GCU_12_StaFaultOut(const double value) { com.set_can_signal_value((TCANSignal* const)&GCU_12_StaFaultOut_GW_PC_31_1, FCAN.FData, value);}
  __declspec(property(get = get_GCU_12_StaFaultOut, put = set_GCU_12_StaFaultOut)) double GCU_12_StaFaultOut;
  double get_MCU_11_Motor_TempFault(void) { return com.get_can_signal_value((TCANSignal* const)&MCU_11_Motor_TempFault_GW_PC_31_1, FCAN.FData);}
  void set_MCU_11_Motor_TempFault(const double value) { com.set_can_signal_value((TCANSignal* const)&MCU_11_Motor_TempFault_GW_PC_31_1, FCAN.FData, value);}
  __declspec(property(get = get_MCU_11_Motor_TempFault, put = set_MCU_11_Motor_TempFault)) double MCU_11_Motor_TempFault;
  double get_MCU_11_Motor_ContrlTempFault(void) { return com.get_can_signal_value((TCANSignal* const)&MCU_11_Motor_ContrlTempFault_GW_PC_31_1, FCAN.FData);}
  void set_MCU_11_Motor_ContrlTempFault(const double value) { com.set_can_signal_value((TCANSignal* const)&MCU_11_Motor_ContrlTempFault_GW_PC_31_1, FCAN.FData, value);}
  __declspec(property(get = get_MCU_11_Motor_ContrlTempFault, put = set_MCU_11_Motor_ContrlTempFault)) double MCU_11_Motor_ContrlTempFault;
  double get_MCU_11_StaFaultOut(void) { return com.get_can_signal_value((TCANSignal* const)&MCU_11_StaFaultOut_GW_PC_31_1, FCAN.FData);}
  void set_MCU_11_StaFaultOut(const double value) { com.set_can_signal_value((TCANSignal* const)&MCU_11_StaFaultOut_GW_PC_31_1, FCAN.FData, value);}
  __declspec(property(get = get_MCU_11_StaFaultOut, put = set_MCU_11_StaFaultOut)) double MCU_11_StaFaultOut;
  double get_GCU_12_Timeout_Flag(void) { return com.get_can_signal_value((TCANSignal* const)&GCU_12_Timeout_Flag_GW_PC_31_1, FCAN.FData);}
  void set_GCU_12_Timeout_Flag(const double value) { com.set_can_signal_value((TCANSignal* const)&GCU_12_Timeout_Flag_GW_PC_31_1, FCAN.FData, value);}
  __declspec(property(get = get_GCU_12_Timeout_Flag, put = set_GCU_12_Timeout_Flag)) double GCU_12_Timeout_Flag;
  double get_MCU_11_Timeout_Flag(void) { return com.get_can_signal_value((TCANSignal* const)&MCU_11_Timeout_Flag_GW_PC_31_1, FCAN.FData);}
  void set_MCU_11_Timeout_Flag(const double value) { com.set_can_signal_value((TCANSignal* const)&MCU_11_Timeout_Flag_GW_PC_31_1, FCAN.FData, value);}
  __declspec(property(get = get_MCU_11_Timeout_Flag, put = set_MCU_11_Timeout_Flag)) double MCU_11_Timeout_Flag;
  void init() { FCAN = create().FCAN; }
  TGW_PC_31_1 create() { CANMsgDecl(_GW_PC_31_1, cGW_PC_31_1, 0, 0, 8, 384) return cGW_PC_31_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message VCU_31_1
extern const TCANSignal VCU_VehRunSta_VCU_31_1;
extern const TCANSignal VCU_VehModDisply_VCU_31_1;
extern const TCANSignal VCU_HYBModDisply_VCU_31_1;
extern const TCANSignal VCU_VehFauLamp_VCU_31_1;
extern const TCANSignal VCU_MILLamp_VCU_31_1;
extern const TCANSignal VCU_TurtleLamp_VCU_31_1;
extern const TCANSignal VCU_HVILFauSta_VCU_31_1;
extern const TCANSignal VCU_LvBat_ERR_MIL_VCU_31_1;
extern const TCANSignal VCU_GearPGenerationStaDisply_VCU_31_1;
struct _VCU_31_1;
typedef struct _VCU_31_1 TVCU_31_1;
struct _VCU_31_1{
  TCAN FCAN;
  double get_VCU_VehRunSta(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_VehRunSta_VCU_31_1, FCAN.FData);}
  void set_VCU_VehRunSta(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_VehRunSta_VCU_31_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_VehRunSta, put = set_VCU_VehRunSta)) double VCU_VehRunSta;
  double get_VCU_VehModDisply(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_VehModDisply_VCU_31_1, FCAN.FData);}
  void set_VCU_VehModDisply(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_VehModDisply_VCU_31_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_VehModDisply, put = set_VCU_VehModDisply)) double VCU_VehModDisply;
  double get_VCU_HYBModDisply(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_HYBModDisply_VCU_31_1, FCAN.FData);}
  void set_VCU_HYBModDisply(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_HYBModDisply_VCU_31_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_HYBModDisply, put = set_VCU_HYBModDisply)) double VCU_HYBModDisply;
  double get_VCU_VehFauLamp(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_VehFauLamp_VCU_31_1, FCAN.FData);}
  void set_VCU_VehFauLamp(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_VehFauLamp_VCU_31_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_VehFauLamp, put = set_VCU_VehFauLamp)) double VCU_VehFauLamp;
  double get_VCU_MILLamp(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_MILLamp_VCU_31_1, FCAN.FData);}
  void set_VCU_MILLamp(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_MILLamp_VCU_31_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_MILLamp, put = set_VCU_MILLamp)) double VCU_MILLamp;
  double get_VCU_TurtleLamp(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_TurtleLamp_VCU_31_1, FCAN.FData);}
  void set_VCU_TurtleLamp(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_TurtleLamp_VCU_31_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_TurtleLamp, put = set_VCU_TurtleLamp)) double VCU_TurtleLamp;
  double get_VCU_HVILFauSta(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_HVILFauSta_VCU_31_1, FCAN.FData);}
  void set_VCU_HVILFauSta(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_HVILFauSta_VCU_31_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_HVILFauSta, put = set_VCU_HVILFauSta)) double VCU_HVILFauSta;
  double get_VCU_LvBat_ERR_MIL(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_LvBat_ERR_MIL_VCU_31_1, FCAN.FData);}
  void set_VCU_LvBat_ERR_MIL(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_LvBat_ERR_MIL_VCU_31_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_LvBat_ERR_MIL, put = set_VCU_LvBat_ERR_MIL)) double VCU_LvBat_ERR_MIL;
  double get_VCU_GearPGenerationStaDisply(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_GearPGenerationStaDisply_VCU_31_1, FCAN.FData);}
  void set_VCU_GearPGenerationStaDisply(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_GearPGenerationStaDisply_VCU_31_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_GearPGenerationStaDisply, put = set_VCU_GearPGenerationStaDisply)) double VCU_GearPGenerationStaDisply;
  void init() { FCAN = create().FCAN; }
  TVCU_31_1 create() { CANMsgDecl(_VCU_31_1, cVCU_31_1, 0, 0, 8, 289) return cVCU_31_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message VCU_32_1
extern const TCANSignal VCU_ReleaseSig_VCU_32_1;
extern const TCANSignal VCU_Drivemode_VCU_32_1;
extern const TCANSignal VCU_ActualOperatingMode_VCU_32_1;
extern const TCANSignal VCU_TargetGear_VCU_32_1;
extern const TCANSignal VCU_GearShiftPosition_VCU_32_1;
extern const TCANSignal VCU_TargetGearValid_VCU_32_1;
extern const TCANSignal VCU_GearShiftPositionValid_VCU_32_1;
extern const TCANSignal VCU_DrivemodeOperationNotice_VCU_32_1;
extern const TCANSignal VCU_DriverWarningsDisply_VCU_32_1;
struct _VCU_32_1;
typedef struct _VCU_32_1 TVCU_32_1;
struct _VCU_32_1{
  TCAN FCAN;
  double get_VCU_ReleaseSig(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_ReleaseSig_VCU_32_1, FCAN.FData);}
  void set_VCU_ReleaseSig(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_ReleaseSig_VCU_32_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_ReleaseSig, put = set_VCU_ReleaseSig)) double VCU_ReleaseSig;
  double get_VCU_Drivemode(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_Drivemode_VCU_32_1, FCAN.FData);}
  void set_VCU_Drivemode(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_Drivemode_VCU_32_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_Drivemode, put = set_VCU_Drivemode)) double VCU_Drivemode;
  double get_VCU_ActualOperatingMode(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_ActualOperatingMode_VCU_32_1, FCAN.FData);}
  void set_VCU_ActualOperatingMode(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_ActualOperatingMode_VCU_32_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_ActualOperatingMode, put = set_VCU_ActualOperatingMode)) double VCU_ActualOperatingMode;
  double get_VCU_TargetGear(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_TargetGear_VCU_32_1, FCAN.FData);}
  void set_VCU_TargetGear(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_TargetGear_VCU_32_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_TargetGear, put = set_VCU_TargetGear)) double VCU_TargetGear;
  double get_VCU_GearShiftPosition(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_GearShiftPosition_VCU_32_1, FCAN.FData);}
  void set_VCU_GearShiftPosition(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_GearShiftPosition_VCU_32_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_GearShiftPosition, put = set_VCU_GearShiftPosition)) double VCU_GearShiftPosition;
  double get_VCU_TargetGearValid(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_TargetGearValid_VCU_32_1, FCAN.FData);}
  void set_VCU_TargetGearValid(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_TargetGearValid_VCU_32_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_TargetGearValid, put = set_VCU_TargetGearValid)) double VCU_TargetGearValid;
  double get_VCU_GearShiftPositionValid(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_GearShiftPositionValid_VCU_32_1, FCAN.FData);}
  void set_VCU_GearShiftPositionValid(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_GearShiftPositionValid_VCU_32_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_GearShiftPositionValid, put = set_VCU_GearShiftPositionValid)) double VCU_GearShiftPositionValid;
  double get_VCU_DrivemodeOperationNotice(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_DrivemodeOperationNotice_VCU_32_1, FCAN.FData);}
  void set_VCU_DrivemodeOperationNotice(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_DrivemodeOperationNotice_VCU_32_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_DrivemodeOperationNotice, put = set_VCU_DrivemodeOperationNotice)) double VCU_DrivemodeOperationNotice;
  double get_VCU_DriverWarningsDisply(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_DriverWarningsDisply_VCU_32_1, FCAN.FData);}
  void set_VCU_DriverWarningsDisply(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_DriverWarningsDisply_VCU_32_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_DriverWarningsDisply, put = set_VCU_DriverWarningsDisply)) double VCU_DriverWarningsDisply;
  void init() { FCAN = create().FCAN; }
  TVCU_32_1 create() { CANMsgDecl(_VCU_32_1, cVCU_32_1, 0, 0, 8, 290) return cVCU_32_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message VCU_37_1
extern const TCANSignal VCU_DrvInstantPower_VCU_37_1;
extern const TCANSignal VCU_DrvOutputSurplusPower_VCU_37_1;
extern const TCANSignal VCU_DrvChargeSurplusPower_VCU_37_1;
extern const TCANSignal VCU_EnergyFlowDisply_VCU_37_1;
struct _VCU_37_1;
typedef struct _VCU_37_1 TVCU_37_1;
struct _VCU_37_1{
  TCAN FCAN;
  double get_VCU_DrvInstantPower(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_DrvInstantPower_VCU_37_1, FCAN.FData);}
  void set_VCU_DrvInstantPower(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_DrvInstantPower_VCU_37_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_DrvInstantPower, put = set_VCU_DrvInstantPower)) double VCU_DrvInstantPower;
  double get_VCU_DrvOutputSurplusPower(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_DrvOutputSurplusPower_VCU_37_1, FCAN.FData);}
  void set_VCU_DrvOutputSurplusPower(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_DrvOutputSurplusPower_VCU_37_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_DrvOutputSurplusPower, put = set_VCU_DrvOutputSurplusPower)) double VCU_DrvOutputSurplusPower;
  double get_VCU_DrvChargeSurplusPower(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_DrvChargeSurplusPower_VCU_37_1, FCAN.FData);}
  void set_VCU_DrvChargeSurplusPower(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_DrvChargeSurplusPower_VCU_37_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_DrvChargeSurplusPower, put = set_VCU_DrvChargeSurplusPower)) double VCU_DrvChargeSurplusPower;
  double get_VCU_EnergyFlowDisply(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_EnergyFlowDisply_VCU_37_1, FCAN.FData);}
  void set_VCU_EnergyFlowDisply(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_EnergyFlowDisply_VCU_37_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_EnergyFlowDisply, put = set_VCU_EnergyFlowDisply)) double VCU_EnergyFlowDisply;
  void init() { FCAN = create().FCAN; }
  TVCU_37_1 create() { CANMsgDecl(_VCU_37_1, cVCU_37_1, 0, 0, 8, 801) return cVCU_37_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message VCU_38_1
extern const TCANSignal VCU_CruiseControlStatus_VCU_38_1;
extern const TCANSignal VCU_CruiseValid_VCU_38_1;
extern const TCANSignal VCU_CruiseActiveStatus_VCU_38_1;
extern const TCANSignal VCU_CruiseMainLamp_VCU_38_1;
extern const TCANSignal VCU_CruiseTargetSpeed_VCU_38_1;
extern const TCANSignal VCU_SOCHoldHEVSts_VCU_38_1;
extern const TCANSignal VCU_SOCHoldHEVTgtSOC_VCU_38_1;
extern const TCANSignal VCU_GearPGenerationSts_VCU_38_1;
extern const TCANSignal VCU_GearPGenerationTgtSOC_VCU_38_1;
extern const TCANSignal VCU_GearPGenerationPwLvl_VCU_38_1;
extern const TCANSignal VCU_CoastdwnRegDepthLvl_VCU_38_1;
extern const TCANSignal VCU_V2LAllow_VCU_38_1;
extern const TCANSignal VCU_V2LSwtSts_VCU_38_1;
extern const TCANSignal VCU_V2LLowSOCStrtSwtSts_VCU_38_1;
extern const TCANSignal VCU_V2LFailRsn_VCU_38_1;
struct _VCU_38_1;
typedef struct _VCU_38_1 TVCU_38_1;
struct _VCU_38_1{
  TCAN FCAN;
  double get_VCU_CruiseControlStatus(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_CruiseControlStatus_VCU_38_1, FCAN.FData);}
  void set_VCU_CruiseControlStatus(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_CruiseControlStatus_VCU_38_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_CruiseControlStatus, put = set_VCU_CruiseControlStatus)) double VCU_CruiseControlStatus;
  double get_VCU_CruiseValid(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_CruiseValid_VCU_38_1, FCAN.FData);}
  void set_VCU_CruiseValid(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_CruiseValid_VCU_38_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_CruiseValid, put = set_VCU_CruiseValid)) double VCU_CruiseValid;
  double get_VCU_CruiseActiveStatus(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_CruiseActiveStatus_VCU_38_1, FCAN.FData);}
  void set_VCU_CruiseActiveStatus(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_CruiseActiveStatus_VCU_38_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_CruiseActiveStatus, put = set_VCU_CruiseActiveStatus)) double VCU_CruiseActiveStatus;
  double get_VCU_CruiseMainLamp(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_CruiseMainLamp_VCU_38_1, FCAN.FData);}
  void set_VCU_CruiseMainLamp(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_CruiseMainLamp_VCU_38_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_CruiseMainLamp, put = set_VCU_CruiseMainLamp)) double VCU_CruiseMainLamp;
  double get_VCU_CruiseTargetSpeed(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_CruiseTargetSpeed_VCU_38_1, FCAN.FData);}
  void set_VCU_CruiseTargetSpeed(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_CruiseTargetSpeed_VCU_38_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_CruiseTargetSpeed, put = set_VCU_CruiseTargetSpeed)) double VCU_CruiseTargetSpeed;
  double get_VCU_SOCHoldHEVSts(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_SOCHoldHEVSts_VCU_38_1, FCAN.FData);}
  void set_VCU_SOCHoldHEVSts(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_SOCHoldHEVSts_VCU_38_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_SOCHoldHEVSts, put = set_VCU_SOCHoldHEVSts)) double VCU_SOCHoldHEVSts;
  double get_VCU_SOCHoldHEVTgtSOC(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_SOCHoldHEVTgtSOC_VCU_38_1, FCAN.FData);}
  void set_VCU_SOCHoldHEVTgtSOC(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_SOCHoldHEVTgtSOC_VCU_38_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_SOCHoldHEVTgtSOC, put = set_VCU_SOCHoldHEVTgtSOC)) double VCU_SOCHoldHEVTgtSOC;
  double get_VCU_GearPGenerationSts(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_GearPGenerationSts_VCU_38_1, FCAN.FData);}
  void set_VCU_GearPGenerationSts(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_GearPGenerationSts_VCU_38_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_GearPGenerationSts, put = set_VCU_GearPGenerationSts)) double VCU_GearPGenerationSts;
  double get_VCU_GearPGenerationTgtSOC(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_GearPGenerationTgtSOC_VCU_38_1, FCAN.FData);}
  void set_VCU_GearPGenerationTgtSOC(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_GearPGenerationTgtSOC_VCU_38_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_GearPGenerationTgtSOC, put = set_VCU_GearPGenerationTgtSOC)) double VCU_GearPGenerationTgtSOC;
  double get_VCU_GearPGenerationPwLvl(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_GearPGenerationPwLvl_VCU_38_1, FCAN.FData);}
  void set_VCU_GearPGenerationPwLvl(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_GearPGenerationPwLvl_VCU_38_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_GearPGenerationPwLvl, put = set_VCU_GearPGenerationPwLvl)) double VCU_GearPGenerationPwLvl;
  double get_VCU_CoastdwnRegDepthLvl(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_CoastdwnRegDepthLvl_VCU_38_1, FCAN.FData);}
  void set_VCU_CoastdwnRegDepthLvl(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_CoastdwnRegDepthLvl_VCU_38_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_CoastdwnRegDepthLvl, put = set_VCU_CoastdwnRegDepthLvl)) double VCU_CoastdwnRegDepthLvl;
  double get_VCU_V2LAllow(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_V2LAllow_VCU_38_1, FCAN.FData);}
  void set_VCU_V2LAllow(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_V2LAllow_VCU_38_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_V2LAllow, put = set_VCU_V2LAllow)) double VCU_V2LAllow;
  double get_VCU_V2LSwtSts(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_V2LSwtSts_VCU_38_1, FCAN.FData);}
  void set_VCU_V2LSwtSts(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_V2LSwtSts_VCU_38_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_V2LSwtSts, put = set_VCU_V2LSwtSts)) double VCU_V2LSwtSts;
  double get_VCU_V2LLowSOCStrtSwtSts(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_V2LLowSOCStrtSwtSts_VCU_38_1, FCAN.FData);}
  void set_VCU_V2LLowSOCStrtSwtSts(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_V2LLowSOCStrtSwtSts_VCU_38_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_V2LLowSOCStrtSwtSts, put = set_VCU_V2LLowSOCStrtSwtSts)) double VCU_V2LLowSOCStrtSwtSts;
  double get_VCU_V2LFailRsn(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_V2LFailRsn_VCU_38_1, FCAN.FData);}
  void set_VCU_V2LFailRsn(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_V2LFailRsn_VCU_38_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_V2LFailRsn, put = set_VCU_V2LFailRsn)) double VCU_V2LFailRsn;
  void init() { FCAN = create().FCAN; }
  TVCU_38_1 create() { CANMsgDecl(_VCU_38_1, cVCU_38_1, 0, 0, 8, 802) return cVCU_38_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message VCU_41_1
extern const TCANSignal VCU_AvgFuelConslast100km_VCU_41_1;
extern const TCANSignal VCU_AvgPwrConslast100km_VCU_41_1;
extern const TCANSignal VCU_AvgEgyConslast100km_VCU_41_1;
extern const TCANSignal VCU_InsAvgFuelCons_VCU_41_1;
extern const TCANSignal VCU_InsAvgPwrCons_VCU_41_1;
extern const TCANSignal VCU_InsPwrConsumption_VCU_41_1;
struct _VCU_41_1;
typedef struct _VCU_41_1 TVCU_41_1;
struct _VCU_41_1{
  TCAN FCAN;
  double get_VCU_AvgFuelConslast100km(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_AvgFuelConslast100km_VCU_41_1, FCAN.FData);}
  void set_VCU_AvgFuelConslast100km(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_AvgFuelConslast100km_VCU_41_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_AvgFuelConslast100km, put = set_VCU_AvgFuelConslast100km)) double VCU_AvgFuelConslast100km;
  double get_VCU_AvgPwrConslast100km(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_AvgPwrConslast100km_VCU_41_1, FCAN.FData);}
  void set_VCU_AvgPwrConslast100km(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_AvgPwrConslast100km_VCU_41_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_AvgPwrConslast100km, put = set_VCU_AvgPwrConslast100km)) double VCU_AvgPwrConslast100km;
  double get_VCU_AvgEgyConslast100km(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_AvgEgyConslast100km_VCU_41_1, FCAN.FData);}
  void set_VCU_AvgEgyConslast100km(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_AvgEgyConslast100km_VCU_41_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_AvgEgyConslast100km, put = set_VCU_AvgEgyConslast100km)) double VCU_AvgEgyConslast100km;
  double get_VCU_InsAvgFuelCons(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_InsAvgFuelCons_VCU_41_1, FCAN.FData);}
  void set_VCU_InsAvgFuelCons(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_InsAvgFuelCons_VCU_41_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_InsAvgFuelCons, put = set_VCU_InsAvgFuelCons)) double VCU_InsAvgFuelCons;
  double get_VCU_InsAvgPwrCons(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_InsAvgPwrCons_VCU_41_1, FCAN.FData);}
  void set_VCU_InsAvgPwrCons(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_InsAvgPwrCons_VCU_41_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_InsAvgPwrCons, put = set_VCU_InsAvgPwrCons)) double VCU_InsAvgPwrCons;
  double get_VCU_InsPwrConsumption(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_InsPwrConsumption_VCU_41_1, FCAN.FData);}
  void set_VCU_InsPwrConsumption(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_InsPwrConsumption_VCU_41_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_InsPwrConsumption, put = set_VCU_InsPwrConsumption)) double VCU_InsPwrConsumption;
  void init() { FCAN = create().FCAN; }
  TVCU_41_1 create() { CANMsgDecl(_VCU_41_1, cVCU_41_1, 0, 0, 8, 804) return cVCU_41_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message TCU_13_1
extern const TCANSignal TCU_TrsmFalrSts_TCU_13_1;
extern const TCANSignal TCU_OilTempOverHi_TCU_13_1;
extern const TCANSignal TCU_TrsmFailLampReq_TCU_13_1;
struct _TCU_13_1;
typedef struct _TCU_13_1 TTCU_13_1;
struct _TCU_13_1{
  TCAN FCAN;
  double get_TCU_TrsmFalrSts(void) { return com.get_can_signal_value((TCANSignal* const)&TCU_TrsmFalrSts_TCU_13_1, FCAN.FData);}
  void set_TCU_TrsmFalrSts(const double value) { com.set_can_signal_value((TCANSignal* const)&TCU_TrsmFalrSts_TCU_13_1, FCAN.FData, value);}
  __declspec(property(get = get_TCU_TrsmFalrSts, put = set_TCU_TrsmFalrSts)) double TCU_TrsmFalrSts;
  double get_TCU_OilTempOverHi(void) { return com.get_can_signal_value((TCANSignal* const)&TCU_OilTempOverHi_TCU_13_1, FCAN.FData);}
  void set_TCU_OilTempOverHi(const double value) { com.set_can_signal_value((TCANSignal* const)&TCU_OilTempOverHi_TCU_13_1, FCAN.FData, value);}
  __declspec(property(get = get_TCU_OilTempOverHi, put = set_TCU_OilTempOverHi)) double TCU_OilTempOverHi;
  double get_TCU_TrsmFailLampReq(void) { return com.get_can_signal_value((TCANSignal* const)&TCU_TrsmFailLampReq_TCU_13_1, FCAN.FData);}
  void set_TCU_TrsmFailLampReq(const double value) { com.set_can_signal_value((TCANSignal* const)&TCU_TrsmFailLampReq_TCU_13_1, FCAN.FData, value);}
  __declspec(property(get = get_TCU_TrsmFailLampReq, put = set_TCU_TrsmFailLampReq)) double TCU_TrsmFailLampReq;
  void init() { FCAN = create().FCAN; }
  TTCU_13_1 create() { CANMsgDecl(_TCU_13_1, cTCU_13_1, 0, 0, 8, 299) return cTCU_13_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message BMS_3_1
extern const TCANSignal B2V_FaultInfo_32960_OverTemp_BMS_3_1;
extern const TCANSignal B2V_FaultInfo_32960_ThermalRunaw_BMS_3_1;
struct _BMS_3_1;
typedef struct _BMS_3_1 TBMS_3_1;
struct _BMS_3_1{
  TCAN FCAN;
  double get_B2V_FaultInfo_32960_OverTemp(void) { return com.get_can_signal_value((TCANSignal* const)&B2V_FaultInfo_32960_OverTemp_BMS_3_1, FCAN.FData);}
  void set_B2V_FaultInfo_32960_OverTemp(const double value) { com.set_can_signal_value((TCANSignal* const)&B2V_FaultInfo_32960_OverTemp_BMS_3_1, FCAN.FData, value);}
  __declspec(property(get = get_B2V_FaultInfo_32960_OverTemp, put = set_B2V_FaultInfo_32960_OverTemp)) double B2V_FaultInfo_32960_OverTemp;
  double get_B2V_FaultInfo_32960_ThermalRunaw(void) { return com.get_can_signal_value((TCANSignal* const)&B2V_FaultInfo_32960_ThermalRunaw_BMS_3_1, FCAN.FData);}
  void set_B2V_FaultInfo_32960_ThermalRunaw(const double value) { com.set_can_signal_value((TCANSignal* const)&B2V_FaultInfo_32960_ThermalRunaw_BMS_3_1, FCAN.FData, value);}
  __declspec(property(get = get_B2V_FaultInfo_32960_ThermalRunaw, put = set_B2V_FaultInfo_32960_ThermalRunaw)) double B2V_FaultInfo_32960_ThermalRunaw;
  void init() { FCAN = create().FCAN; }
  TBMS_3_1 create() { CANMsgDecl(_BMS_3_1, cBMS_3_1, 0, 0, 8, 912) return cBMS_3_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message BMS_33_1
extern const TCANSignal BMS_BatPackSOCDisply_BMS_33_1;
struct _BMS_33_1;
typedef struct _BMS_33_1 TBMS_33_1;
struct _BMS_33_1{
  TCAN FCAN;
  double get_BMS_BatPackSOCDisply(void) { return com.get_can_signal_value((TCANSignal* const)&BMS_BatPackSOCDisply_BMS_33_1, FCAN.FData);}
  void set_BMS_BatPackSOCDisply(const double value) { com.set_can_signal_value((TCANSignal* const)&BMS_BatPackSOCDisply_BMS_33_1, FCAN.FData, value);}
  __declspec(property(get = get_BMS_BatPackSOCDisply, put = set_BMS_BatPackSOCDisply)) double BMS_BatPackSOCDisply;
  void init() { FCAN = create().FCAN; }
  TBMS_33_1 create() { CANMsgDecl(_BMS_33_1, cBMS_33_1, 0, 0, 8, 925) return cBMS_33_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message BMS_40_1
extern const TCANSignal B2V_ST1_PackCurrent_BMS_40_1;
extern const TCANSignal B2V_ST1_PackPower_BMS_40_1;
extern const TCANSignal B2V_ST1_PackVolt_BMS_40_1;
struct _BMS_40_1;
typedef struct _BMS_40_1 TBMS_40_1;
struct _BMS_40_1{
  TCAN FCAN;
  double get_B2V_ST1_PackCurrent(void) { return com.get_can_signal_value((TCANSignal* const)&B2V_ST1_PackCurrent_BMS_40_1, FCAN.FData);}
  void set_B2V_ST1_PackCurrent(const double value) { com.set_can_signal_value((TCANSignal* const)&B2V_ST1_PackCurrent_BMS_40_1, FCAN.FData, value);}
  __declspec(property(get = get_B2V_ST1_PackCurrent, put = set_B2V_ST1_PackCurrent)) double B2V_ST1_PackCurrent;
  double get_B2V_ST1_PackPower(void) { return com.get_can_signal_value((TCANSignal* const)&B2V_ST1_PackPower_BMS_40_1, FCAN.FData);}
  void set_B2V_ST1_PackPower(const double value) { com.set_can_signal_value((TCANSignal* const)&B2V_ST1_PackPower_BMS_40_1, FCAN.FData, value);}
  __declspec(property(get = get_B2V_ST1_PackPower, put = set_B2V_ST1_PackPower)) double B2V_ST1_PackPower;
  double get_B2V_ST1_PackVolt(void) { return com.get_can_signal_value((TCANSignal* const)&B2V_ST1_PackVolt_BMS_40_1, FCAN.FData);}
  void set_B2V_ST1_PackVolt(const double value) { com.set_can_signal_value((TCANSignal* const)&B2V_ST1_PackVolt_BMS_40_1, FCAN.FData, value);}
  __declspec(property(get = get_B2V_ST1_PackVolt, put = set_B2V_ST1_PackVolt)) double B2V_ST1_PackVolt;
  void init() { FCAN = create().FCAN; }
  TBMS_40_1 create() { CANMsgDecl(_BMS_40_1, cBMS_40_1, 0, 0, 8, 316) return cBMS_40_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message BMS_46_1
extern const TCANSignal BMS_ChrgSysSta_BMS_46_1;
extern const TCANSignal BMS_ChrgConctSta_BMS_46_1;
extern const TCANSignal BMS_ChrgSta_BMS_46_1;
struct _BMS_46_1;
typedef struct _BMS_46_1 TBMS_46_1;
struct _BMS_46_1{
  TCAN FCAN;
  double get_BMS_ChrgSysSta(void) { return com.get_can_signal_value((TCANSignal* const)&BMS_ChrgSysSta_BMS_46_1, FCAN.FData);}
  void set_BMS_ChrgSysSta(const double value) { com.set_can_signal_value((TCANSignal* const)&BMS_ChrgSysSta_BMS_46_1, FCAN.FData, value);}
  __declspec(property(get = get_BMS_ChrgSysSta, put = set_BMS_ChrgSysSta)) double BMS_ChrgSysSta;
  double get_BMS_ChrgConctSta(void) { return com.get_can_signal_value((TCANSignal* const)&BMS_ChrgConctSta_BMS_46_1, FCAN.FData);}
  void set_BMS_ChrgConctSta(const double value) { com.set_can_signal_value((TCANSignal* const)&BMS_ChrgConctSta_BMS_46_1, FCAN.FData, value);}
  __declspec(property(get = get_BMS_ChrgConctSta, put = set_BMS_ChrgConctSta)) double BMS_ChrgConctSta;
  double get_BMS_ChrgSta(void) { return com.get_can_signal_value((TCANSignal* const)&BMS_ChrgSta_BMS_46_1, FCAN.FData);}
  void set_BMS_ChrgSta(const double value) { com.set_can_signal_value((TCANSignal* const)&BMS_ChrgSta_BMS_46_1, FCAN.FData, value);}
  __declspec(property(get = get_BMS_ChrgSta, put = set_BMS_ChrgSta)) double BMS_ChrgSta;
  void init() { FCAN = create().FCAN; }
  TBMS_46_1 create() { CANMsgDecl(_BMS_46_1, cBMS_46_1, 0, 0, 8, 955) return cBMS_46_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message BMS_23_1
extern const TCANSignal BMS_6C0_VEH_INSULATION_FAULT_IND_BMS_23_1;
extern const TCANSignal BMS_6C0_BATT_FAULT_IND_BMS_23_1;
extern const TCANSignal BMS_6C0_OBC_ERR_IND_BMS_23_1;
extern const TCANSignal BMS_6C0_OBC_REMIND_LAMP_BMS_23_1;
extern const TCANSignal BMS_6C0_BATT_TEMP_LAMP_BMS_23_1;
struct _BMS_23_1;
typedef struct _BMS_23_1 TBMS_23_1;
struct _BMS_23_1{
  TCAN FCAN;
  double get_BMS_6C0_VEH_INSULATION_FAULT_IND(void) { return com.get_can_signal_value((TCANSignal* const)&BMS_6C0_VEH_INSULATION_FAULT_IND_BMS_23_1, FCAN.FData);}
  void set_BMS_6C0_VEH_INSULATION_FAULT_IND(const double value) { com.set_can_signal_value((TCANSignal* const)&BMS_6C0_VEH_INSULATION_FAULT_IND_BMS_23_1, FCAN.FData, value);}
  __declspec(property(get = get_BMS_6C0_VEH_INSULATION_FAULT_IND, put = set_BMS_6C0_VEH_INSULATION_FAULT_IND)) double BMS_6C0_VEH_INSULATION_FAULT_IND;
  double get_BMS_6C0_BATT_FAULT_IND(void) { return com.get_can_signal_value((TCANSignal* const)&BMS_6C0_BATT_FAULT_IND_BMS_23_1, FCAN.FData);}
  void set_BMS_6C0_BATT_FAULT_IND(const double value) { com.set_can_signal_value((TCANSignal* const)&BMS_6C0_BATT_FAULT_IND_BMS_23_1, FCAN.FData, value);}
  __declspec(property(get = get_BMS_6C0_BATT_FAULT_IND, put = set_BMS_6C0_BATT_FAULT_IND)) double BMS_6C0_BATT_FAULT_IND;
  double get_BMS_6C0_OBC_ERR_IND(void) { return com.get_can_signal_value((TCANSignal* const)&BMS_6C0_OBC_ERR_IND_BMS_23_1, FCAN.FData);}
  void set_BMS_6C0_OBC_ERR_IND(const double value) { com.set_can_signal_value((TCANSignal* const)&BMS_6C0_OBC_ERR_IND_BMS_23_1, FCAN.FData, value);}
  __declspec(property(get = get_BMS_6C0_OBC_ERR_IND, put = set_BMS_6C0_OBC_ERR_IND)) double BMS_6C0_OBC_ERR_IND;
  double get_BMS_6C0_OBC_REMIND_LAMP(void) { return com.get_can_signal_value((TCANSignal* const)&BMS_6C0_OBC_REMIND_LAMP_BMS_23_1, FCAN.FData);}
  void set_BMS_6C0_OBC_REMIND_LAMP(const double value) { com.set_can_signal_value((TCANSignal* const)&BMS_6C0_OBC_REMIND_LAMP_BMS_23_1, FCAN.FData, value);}
  __declspec(property(get = get_BMS_6C0_OBC_REMIND_LAMP, put = set_BMS_6C0_OBC_REMIND_LAMP)) double BMS_6C0_OBC_REMIND_LAMP;
  double get_BMS_6C0_BATT_TEMP_LAMP(void) { return com.get_can_signal_value((TCANSignal* const)&BMS_6C0_BATT_TEMP_LAMP_BMS_23_1, FCAN.FData);}
  void set_BMS_6C0_BATT_TEMP_LAMP(const double value) { com.set_can_signal_value((TCANSignal* const)&BMS_6C0_BATT_TEMP_LAMP_BMS_23_1, FCAN.FData, value);}
  __declspec(property(get = get_BMS_6C0_BATT_TEMP_LAMP, put = set_BMS_6C0_BATT_TEMP_LAMP)) double BMS_6C0_BATT_TEMP_LAMP;
  void init() { FCAN = create().FCAN; }
  TBMS_23_1 create() { CANMsgDecl(_BMS_23_1, cBMS_23_1, 0, 0, 8, 1400) return cBMS_23_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message OBC_2_1
extern const TCANSignal OBC_ChargeStatus_OBC_2_1;
extern const TCANSignal OBC_ChargePlugStatus_OBC_2_1;
struct _OBC_2_1;
typedef struct _OBC_2_1 TOBC_2_1;
struct _OBC_2_1{
  TCAN FCAN;
  double get_OBC_ChargeStatus(void) { return com.get_can_signal_value((TCANSignal* const)&OBC_ChargeStatus_OBC_2_1, FCAN.FData);}
  void set_OBC_ChargeStatus(const double value) { com.set_can_signal_value((TCANSignal* const)&OBC_ChargeStatus_OBC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_OBC_ChargeStatus, put = set_OBC_ChargeStatus)) double OBC_ChargeStatus;
  double get_OBC_ChargePlugStatus(void) { return com.get_can_signal_value((TCANSignal* const)&OBC_ChargePlugStatus_OBC_2_1, FCAN.FData);}
  void set_OBC_ChargePlugStatus(const double value) { com.set_can_signal_value((TCANSignal* const)&OBC_ChargePlugStatus_OBC_2_1, FCAN.FData, value);}
  __declspec(property(get = get_OBC_ChargePlugStatus, put = set_OBC_ChargePlugStatus)) double OBC_ChargePlugStatus;
  void init() { FCAN = create().FCAN; }
  TOBC_2_1 create() { CANMsgDecl(_OBC_2_1, cOBC_2_1, 0, 0, 8, 1424) return cOBC_2_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message OBC_3_1
extern const TCANSignal C2V_N_ACVoltageOutput_OBC_3_1;
extern const TCANSignal C2V_N_AVCurrentOutput_OBC_3_1;
extern const TCANSignal C2V_N_AVPowerOutput_OBC_3_1;
extern const TCANSignal C2V_St_VTOLPlugStatus_OBC_3_1;
extern const TCANSignal C2V_VTOLStatus_OBC_3_1;
extern const TCANSignal C2V_F_VTOLOverfulRatedPower_OBC_3_1;
extern const TCANSignal C2V_F_VTOLHardware_OBC_3_1;
extern const TCANSignal C2V_F_VTOLOverTemp_OBC_3_1;
struct _OBC_3_1;
typedef struct _OBC_3_1 TOBC_3_1;
struct _OBC_3_1{
  TCAN FCAN;
  double get_C2V_N_ACVoltageOutput(void) { return com.get_can_signal_value((TCANSignal* const)&C2V_N_ACVoltageOutput_OBC_3_1, FCAN.FData);}
  void set_C2V_N_ACVoltageOutput(const double value) { com.set_can_signal_value((TCANSignal* const)&C2V_N_ACVoltageOutput_OBC_3_1, FCAN.FData, value);}
  __declspec(property(get = get_C2V_N_ACVoltageOutput, put = set_C2V_N_ACVoltageOutput)) double C2V_N_ACVoltageOutput;
  double get_C2V_N_AVCurrentOutput(void) { return com.get_can_signal_value((TCANSignal* const)&C2V_N_AVCurrentOutput_OBC_3_1, FCAN.FData);}
  void set_C2V_N_AVCurrentOutput(const double value) { com.set_can_signal_value((TCANSignal* const)&C2V_N_AVCurrentOutput_OBC_3_1, FCAN.FData, value);}
  __declspec(property(get = get_C2V_N_AVCurrentOutput, put = set_C2V_N_AVCurrentOutput)) double C2V_N_AVCurrentOutput;
  double get_C2V_N_AVPowerOutput(void) { return com.get_can_signal_value((TCANSignal* const)&C2V_N_AVPowerOutput_OBC_3_1, FCAN.FData);}
  void set_C2V_N_AVPowerOutput(const double value) { com.set_can_signal_value((TCANSignal* const)&C2V_N_AVPowerOutput_OBC_3_1, FCAN.FData, value);}
  __declspec(property(get = get_C2V_N_AVPowerOutput, put = set_C2V_N_AVPowerOutput)) double C2V_N_AVPowerOutput;
  double get_C2V_St_VTOLPlugStatus(void) { return com.get_can_signal_value((TCANSignal* const)&C2V_St_VTOLPlugStatus_OBC_3_1, FCAN.FData);}
  void set_C2V_St_VTOLPlugStatus(const double value) { com.set_can_signal_value((TCANSignal* const)&C2V_St_VTOLPlugStatus_OBC_3_1, FCAN.FData, value);}
  __declspec(property(get = get_C2V_St_VTOLPlugStatus, put = set_C2V_St_VTOLPlugStatus)) double C2V_St_VTOLPlugStatus;
  double get_C2V_VTOLStatus(void) { return com.get_can_signal_value((TCANSignal* const)&C2V_VTOLStatus_OBC_3_1, FCAN.FData);}
  void set_C2V_VTOLStatus(const double value) { com.set_can_signal_value((TCANSignal* const)&C2V_VTOLStatus_OBC_3_1, FCAN.FData, value);}
  __declspec(property(get = get_C2V_VTOLStatus, put = set_C2V_VTOLStatus)) double C2V_VTOLStatus;
  double get_C2V_F_VTOLOverfulRatedPower(void) { return com.get_can_signal_value((TCANSignal* const)&C2V_F_VTOLOverfulRatedPower_OBC_3_1, FCAN.FData);}
  void set_C2V_F_VTOLOverfulRatedPower(const double value) { com.set_can_signal_value((TCANSignal* const)&C2V_F_VTOLOverfulRatedPower_OBC_3_1, FCAN.FData, value);}
  __declspec(property(get = get_C2V_F_VTOLOverfulRatedPower, put = set_C2V_F_VTOLOverfulRatedPower)) double C2V_F_VTOLOverfulRatedPower;
  double get_C2V_F_VTOLHardware(void) { return com.get_can_signal_value((TCANSignal* const)&C2V_F_VTOLHardware_OBC_3_1, FCAN.FData);}
  void set_C2V_F_VTOLHardware(const double value) { com.set_can_signal_value((TCANSignal* const)&C2V_F_VTOLHardware_OBC_3_1, FCAN.FData, value);}
  __declspec(property(get = get_C2V_F_VTOLHardware, put = set_C2V_F_VTOLHardware)) double C2V_F_VTOLHardware;
  double get_C2V_F_VTOLOverTemp(void) { return com.get_can_signal_value((TCANSignal* const)&C2V_F_VTOLOverTemp_OBC_3_1, FCAN.FData);}
  void set_C2V_F_VTOLOverTemp(const double value) { com.set_can_signal_value((TCANSignal* const)&C2V_F_VTOLOverTemp_OBC_3_1, FCAN.FData, value);}
  __declspec(property(get = get_C2V_F_VTOLOverTemp, put = set_C2V_F_VTOLOverTemp)) double C2V_F_VTOLOverTemp;
  void init() { FCAN = create().FCAN; }
  TOBC_3_1 create() { CANMsgDecl(_OBC_3_1, cOBC_3_1, 0, 0, 8, 1361) return cOBC_3_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message DCDC_1_1
extern const TCANSignal DCDC_WorkStatus_DCDC_1_1;
extern const TCANSignal DCDC_HvLockErr_DCDC_1_1;
struct _DCDC_1_1;
typedef struct _DCDC_1_1 TDCDC_1_1;
struct _DCDC_1_1{
  TCAN FCAN;
  double get_DCDC_WorkStatus(void) { return com.get_can_signal_value((TCANSignal* const)&DCDC_WorkStatus_DCDC_1_1, FCAN.FData);}
  void set_DCDC_WorkStatus(const double value) { com.set_can_signal_value((TCANSignal* const)&DCDC_WorkStatus_DCDC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_DCDC_WorkStatus, put = set_DCDC_WorkStatus)) double DCDC_WorkStatus;
  double get_DCDC_HvLockErr(void) { return com.get_can_signal_value((TCANSignal* const)&DCDC_HvLockErr_DCDC_1_1, FCAN.FData);}
  void set_DCDC_HvLockErr(const double value) { com.set_can_signal_value((TCANSignal* const)&DCDC_HvLockErr_DCDC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_DCDC_HvLockErr, put = set_DCDC_HvLockErr)) double DCDC_HvLockErr;
  void init() { FCAN = create().FCAN; }
  TDCDC_1_1 create() { CANMsgDecl(_DCDC_1_1, cDCDC_1_1, 0, 0, 8, 1368) return cDCDC_1_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message GW_PC_1_1
extern const TCANSignal EMS_2_EngineSpeed_GW_PC_1_1;
extern const TCANSignal EMS_2_EngineSpeedValid_GW_PC_1_1;
extern const TCANSignal EMS_3_EngineReleaseSig_GW_PC_1_1;
extern const TCANSignal EMS_3_SS_Screen_tip_GW_PC_1_1;
extern const TCANSignal EMS_3_SS_Active_Lamp_GW_PC_1_1;
extern const TCANSignal EMS_3_SS_Fault_Lamp_GW_PC_1_1;
extern const TCANSignal TCU_1_TcuFaultLamp_GW_PC_1_1;
extern const TCANSignal EMS_3_SS_SetSts_GW_PC_1_1;
extern const TCANSignal TCU_3_Drivemode_GW_PC_1_1;
extern const TCANSignal TCU_1_TransOilWrnLmpReq_GW_PC_1_1;
extern const TCANSignal TCU_1_ActualGearValid_GW_PC_1_1;
extern const TCANSignal TCU_1_GearShiftPositionValid_GW_PC_1_1;
extern const TCANSignal TCU_1_ShiftRecommendation_GW_PC_1_1;
extern const TCANSignal TCU_1_ActualGear_GW_PC_1_1;
extern const TCANSignal TCU_1_IcInformaition_GW_PC_1_1;
extern const TCANSignal TCU_1_GearShiftPosition_GW_PC_1_1;
extern const TCANSignal EMS_2_Timeout_Flag_GW_PC_1_1;
extern const TCANSignal EMS_3_Timeout_Flag_GW_PC_1_1;
extern const TCANSignal TCU_1_Timeout_Flag_GW_PC_1_1;
extern const TCANSignal TCU_3_Timeout_Flag_GW_PC_1_1;
extern const TCANSignal EMS_3_EngineStatus_GW_PC_1_1;
struct _GW_PC_1_1;
typedef struct _GW_PC_1_1 TGW_PC_1_1;
struct _GW_PC_1_1{
  TCAN FCAN;
  double get_EMS_2_EngineSpeed(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_2_EngineSpeed_GW_PC_1_1, FCAN.FData);}
  void set_EMS_2_EngineSpeed(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_2_EngineSpeed_GW_PC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_2_EngineSpeed, put = set_EMS_2_EngineSpeed)) double EMS_2_EngineSpeed;
  double get_EMS_2_EngineSpeedValid(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_2_EngineSpeedValid_GW_PC_1_1, FCAN.FData);}
  void set_EMS_2_EngineSpeedValid(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_2_EngineSpeedValid_GW_PC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_2_EngineSpeedValid, put = set_EMS_2_EngineSpeedValid)) double EMS_2_EngineSpeedValid;
  double get_EMS_3_EngineReleaseSig(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_3_EngineReleaseSig_GW_PC_1_1, FCAN.FData);}
  void set_EMS_3_EngineReleaseSig(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_3_EngineReleaseSig_GW_PC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_3_EngineReleaseSig, put = set_EMS_3_EngineReleaseSig)) double EMS_3_EngineReleaseSig;
  double get_EMS_3_SS_Screen_tip(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_3_SS_Screen_tip_GW_PC_1_1, FCAN.FData);}
  void set_EMS_3_SS_Screen_tip(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_3_SS_Screen_tip_GW_PC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_3_SS_Screen_tip, put = set_EMS_3_SS_Screen_tip)) double EMS_3_SS_Screen_tip;
  double get_EMS_3_SS_Active_Lamp(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_3_SS_Active_Lamp_GW_PC_1_1, FCAN.FData);}
  void set_EMS_3_SS_Active_Lamp(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_3_SS_Active_Lamp_GW_PC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_3_SS_Active_Lamp, put = set_EMS_3_SS_Active_Lamp)) double EMS_3_SS_Active_Lamp;
  double get_EMS_3_SS_Fault_Lamp(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_3_SS_Fault_Lamp_GW_PC_1_1, FCAN.FData);}
  void set_EMS_3_SS_Fault_Lamp(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_3_SS_Fault_Lamp_GW_PC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_3_SS_Fault_Lamp, put = set_EMS_3_SS_Fault_Lamp)) double EMS_3_SS_Fault_Lamp;
  double get_TCU_1_TcuFaultLamp(void) { return com.get_can_signal_value((TCANSignal* const)&TCU_1_TcuFaultLamp_GW_PC_1_1, FCAN.FData);}
  void set_TCU_1_TcuFaultLamp(const double value) { com.set_can_signal_value((TCANSignal* const)&TCU_1_TcuFaultLamp_GW_PC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TCU_1_TcuFaultLamp, put = set_TCU_1_TcuFaultLamp)) double TCU_1_TcuFaultLamp;
  double get_EMS_3_SS_SetSts(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_3_SS_SetSts_GW_PC_1_1, FCAN.FData);}
  void set_EMS_3_SS_SetSts(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_3_SS_SetSts_GW_PC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_3_SS_SetSts, put = set_EMS_3_SS_SetSts)) double EMS_3_SS_SetSts;
  double get_TCU_3_Drivemode(void) { return com.get_can_signal_value((TCANSignal* const)&TCU_3_Drivemode_GW_PC_1_1, FCAN.FData);}
  void set_TCU_3_Drivemode(const double value) { com.set_can_signal_value((TCANSignal* const)&TCU_3_Drivemode_GW_PC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TCU_3_Drivemode, put = set_TCU_3_Drivemode)) double TCU_3_Drivemode;
  double get_TCU_1_TransOilWrnLmpReq(void) { return com.get_can_signal_value((TCANSignal* const)&TCU_1_TransOilWrnLmpReq_GW_PC_1_1, FCAN.FData);}
  void set_TCU_1_TransOilWrnLmpReq(const double value) { com.set_can_signal_value((TCANSignal* const)&TCU_1_TransOilWrnLmpReq_GW_PC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TCU_1_TransOilWrnLmpReq, put = set_TCU_1_TransOilWrnLmpReq)) double TCU_1_TransOilWrnLmpReq;
  double get_TCU_1_ActualGearValid(void) { return com.get_can_signal_value((TCANSignal* const)&TCU_1_ActualGearValid_GW_PC_1_1, FCAN.FData);}
  void set_TCU_1_ActualGearValid(const double value) { com.set_can_signal_value((TCANSignal* const)&TCU_1_ActualGearValid_GW_PC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TCU_1_ActualGearValid, put = set_TCU_1_ActualGearValid)) double TCU_1_ActualGearValid;
  double get_TCU_1_GearShiftPositionValid(void) { return com.get_can_signal_value((TCANSignal* const)&TCU_1_GearShiftPositionValid_GW_PC_1_1, FCAN.FData);}
  void set_TCU_1_GearShiftPositionValid(const double value) { com.set_can_signal_value((TCANSignal* const)&TCU_1_GearShiftPositionValid_GW_PC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TCU_1_GearShiftPositionValid, put = set_TCU_1_GearShiftPositionValid)) double TCU_1_GearShiftPositionValid;
  double get_TCU_1_ShiftRecommendation(void) { return com.get_can_signal_value((TCANSignal* const)&TCU_1_ShiftRecommendation_GW_PC_1_1, FCAN.FData);}
  void set_TCU_1_ShiftRecommendation(const double value) { com.set_can_signal_value((TCANSignal* const)&TCU_1_ShiftRecommendation_GW_PC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TCU_1_ShiftRecommendation, put = set_TCU_1_ShiftRecommendation)) double TCU_1_ShiftRecommendation;
  double get_TCU_1_ActualGear(void) { return com.get_can_signal_value((TCANSignal* const)&TCU_1_ActualGear_GW_PC_1_1, FCAN.FData);}
  void set_TCU_1_ActualGear(const double value) { com.set_can_signal_value((TCANSignal* const)&TCU_1_ActualGear_GW_PC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TCU_1_ActualGear, put = set_TCU_1_ActualGear)) double TCU_1_ActualGear;
  double get_TCU_1_IcInformaition(void) { return com.get_can_signal_value((TCANSignal* const)&TCU_1_IcInformaition_GW_PC_1_1, FCAN.FData);}
  void set_TCU_1_IcInformaition(const double value) { com.set_can_signal_value((TCANSignal* const)&TCU_1_IcInformaition_GW_PC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TCU_1_IcInformaition, put = set_TCU_1_IcInformaition)) double TCU_1_IcInformaition;
  double get_TCU_1_GearShiftPosition(void) { return com.get_can_signal_value((TCANSignal* const)&TCU_1_GearShiftPosition_GW_PC_1_1, FCAN.FData);}
  void set_TCU_1_GearShiftPosition(const double value) { com.set_can_signal_value((TCANSignal* const)&TCU_1_GearShiftPosition_GW_PC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TCU_1_GearShiftPosition, put = set_TCU_1_GearShiftPosition)) double TCU_1_GearShiftPosition;
  double get_EMS_2_Timeout_Flag(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_2_Timeout_Flag_GW_PC_1_1, FCAN.FData);}
  void set_EMS_2_Timeout_Flag(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_2_Timeout_Flag_GW_PC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_2_Timeout_Flag, put = set_EMS_2_Timeout_Flag)) double EMS_2_Timeout_Flag;
  double get_EMS_3_Timeout_Flag(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_3_Timeout_Flag_GW_PC_1_1, FCAN.FData);}
  void set_EMS_3_Timeout_Flag(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_3_Timeout_Flag_GW_PC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_3_Timeout_Flag, put = set_EMS_3_Timeout_Flag)) double EMS_3_Timeout_Flag;
  double get_TCU_1_Timeout_Flag(void) { return com.get_can_signal_value((TCANSignal* const)&TCU_1_Timeout_Flag_GW_PC_1_1, FCAN.FData);}
  void set_TCU_1_Timeout_Flag(const double value) { com.set_can_signal_value((TCANSignal* const)&TCU_1_Timeout_Flag_GW_PC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TCU_1_Timeout_Flag, put = set_TCU_1_Timeout_Flag)) double TCU_1_Timeout_Flag;
  double get_TCU_3_Timeout_Flag(void) { return com.get_can_signal_value((TCANSignal* const)&TCU_3_Timeout_Flag_GW_PC_1_1, FCAN.FData);}
  void set_TCU_3_Timeout_Flag(const double value) { com.set_can_signal_value((TCANSignal* const)&TCU_3_Timeout_Flag_GW_PC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_TCU_3_Timeout_Flag, put = set_TCU_3_Timeout_Flag)) double TCU_3_Timeout_Flag;
  double get_EMS_3_EngineStatus(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_3_EngineStatus_GW_PC_1_1, FCAN.FData);}
  void set_EMS_3_EngineStatus(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_3_EngineStatus_GW_PC_1_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_3_EngineStatus, put = set_EMS_3_EngineStatus)) double EMS_3_EngineStatus;
  void init() { FCAN = create().FCAN; }
  TGW_PC_1_1 create() { CANMsgDecl(_GW_PC_1_1, cGW_PC_1_1, 0, 0, 8, 336) return cGW_PC_1_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message GW_PC_6_1
extern const TCANSignal EMS_4_EngineCoolantTemp_GW_PC_6_1;
extern const TCANSignal EMS_4_FuelConsumption_GW_PC_6_1;
extern const TCANSignal EMS_4_SVS_GW_PC_6_1;
extern const TCANSignal EMS_4_MIL_GW_PC_6_1;
extern const TCANSignal EMS_4_CruiseControlStatus_GW_PC_6_1;
extern const TCANSignal EMS_4_EngineCoolantTempValid_GW_PC_6_1;
extern const TCANSignal EMS_4_CruiseActiveStatus_GW_PC_6_1;
extern const TCANSignal EMS_4_CruiseMainLamp_GW_PC_6_1;
extern const TCANSignal TCU_3_TargetGearValid_GW_PC_6_1;
extern const TCANSignal EMS_4_CruiseTargetSpeed_GW_PC_6_1;
extern const TCANSignal TCU_3_DrivemodeOprationNotice_GW_PC_6_1;
extern const TCANSignal TCU_3_TargetGear_GW_PC_6_1;
extern const TCANSignal EMS_6_OilPressure_GW_PC_6_1;
extern const TCANSignal EMS_4_Timeout_Flag_GW_PC_6_1;
extern const TCANSignal EMS_6_Timeout_Flag_GW_PC_6_1;
extern const TCANSignal TCU_3_Timeout_Flag1_GW_PC_6_1;
extern const TCANSignal EMS_6_GPFState_GW_PC_6_1;
extern const TCANSignal EMS_6_GeneratorFaultLamp_GW_PC_6_1;
extern const TCANSignal EMS_6_OilPressureLamp_GW_PC_6_1;
struct _GW_PC_6_1;
typedef struct _GW_PC_6_1 TGW_PC_6_1;
struct _GW_PC_6_1{
  TCAN FCAN;
  double get_EMS_4_EngineCoolantTemp(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_4_EngineCoolantTemp_GW_PC_6_1, FCAN.FData);}
  void set_EMS_4_EngineCoolantTemp(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_4_EngineCoolantTemp_GW_PC_6_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_4_EngineCoolantTemp, put = set_EMS_4_EngineCoolantTemp)) double EMS_4_EngineCoolantTemp;
  double get_EMS_4_FuelConsumption(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_4_FuelConsumption_GW_PC_6_1, FCAN.FData);}
  void set_EMS_4_FuelConsumption(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_4_FuelConsumption_GW_PC_6_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_4_FuelConsumption, put = set_EMS_4_FuelConsumption)) double EMS_4_FuelConsumption;
  double get_EMS_4_SVS(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_4_SVS_GW_PC_6_1, FCAN.FData);}
  void set_EMS_4_SVS(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_4_SVS_GW_PC_6_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_4_SVS, put = set_EMS_4_SVS)) double EMS_4_SVS;
  double get_EMS_4_MIL(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_4_MIL_GW_PC_6_1, FCAN.FData);}
  void set_EMS_4_MIL(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_4_MIL_GW_PC_6_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_4_MIL, put = set_EMS_4_MIL)) double EMS_4_MIL;
  double get_EMS_4_CruiseControlStatus(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_4_CruiseControlStatus_GW_PC_6_1, FCAN.FData);}
  void set_EMS_4_CruiseControlStatus(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_4_CruiseControlStatus_GW_PC_6_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_4_CruiseControlStatus, put = set_EMS_4_CruiseControlStatus)) double EMS_4_CruiseControlStatus;
  double get_EMS_4_EngineCoolantTempValid(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_4_EngineCoolantTempValid_GW_PC_6_1, FCAN.FData);}
  void set_EMS_4_EngineCoolantTempValid(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_4_EngineCoolantTempValid_GW_PC_6_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_4_EngineCoolantTempValid, put = set_EMS_4_EngineCoolantTempValid)) double EMS_4_EngineCoolantTempValid;
  double get_EMS_4_CruiseActiveStatus(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_4_CruiseActiveStatus_GW_PC_6_1, FCAN.FData);}
  void set_EMS_4_CruiseActiveStatus(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_4_CruiseActiveStatus_GW_PC_6_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_4_CruiseActiveStatus, put = set_EMS_4_CruiseActiveStatus)) double EMS_4_CruiseActiveStatus;
  double get_EMS_4_CruiseMainLamp(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_4_CruiseMainLamp_GW_PC_6_1, FCAN.FData);}
  void set_EMS_4_CruiseMainLamp(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_4_CruiseMainLamp_GW_PC_6_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_4_CruiseMainLamp, put = set_EMS_4_CruiseMainLamp)) double EMS_4_CruiseMainLamp;
  double get_TCU_3_TargetGearValid(void) { return com.get_can_signal_value((TCANSignal* const)&TCU_3_TargetGearValid_GW_PC_6_1, FCAN.FData);}
  void set_TCU_3_TargetGearValid(const double value) { com.set_can_signal_value((TCANSignal* const)&TCU_3_TargetGearValid_GW_PC_6_1, FCAN.FData, value);}
  __declspec(property(get = get_TCU_3_TargetGearValid, put = set_TCU_3_TargetGearValid)) double TCU_3_TargetGearValid;
  double get_EMS_4_CruiseTargetSpeed(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_4_CruiseTargetSpeed_GW_PC_6_1, FCAN.FData);}
  void set_EMS_4_CruiseTargetSpeed(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_4_CruiseTargetSpeed_GW_PC_6_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_4_CruiseTargetSpeed, put = set_EMS_4_CruiseTargetSpeed)) double EMS_4_CruiseTargetSpeed;
  double get_TCU_3_DrivemodeOprationNotice(void) { return com.get_can_signal_value((TCANSignal* const)&TCU_3_DrivemodeOprationNotice_GW_PC_6_1, FCAN.FData);}
  void set_TCU_3_DrivemodeOprationNotice(const double value) { com.set_can_signal_value((TCANSignal* const)&TCU_3_DrivemodeOprationNotice_GW_PC_6_1, FCAN.FData, value);}
  __declspec(property(get = get_TCU_3_DrivemodeOprationNotice, put = set_TCU_3_DrivemodeOprationNotice)) double TCU_3_DrivemodeOprationNotice;
  double get_TCU_3_TargetGear(void) { return com.get_can_signal_value((TCANSignal* const)&TCU_3_TargetGear_GW_PC_6_1, FCAN.FData);}
  void set_TCU_3_TargetGear(const double value) { com.set_can_signal_value((TCANSignal* const)&TCU_3_TargetGear_GW_PC_6_1, FCAN.FData, value);}
  __declspec(property(get = get_TCU_3_TargetGear, put = set_TCU_3_TargetGear)) double TCU_3_TargetGear;
  double get_EMS_6_OilPressure(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_6_OilPressure_GW_PC_6_1, FCAN.FData);}
  void set_EMS_6_OilPressure(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_6_OilPressure_GW_PC_6_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_6_OilPressure, put = set_EMS_6_OilPressure)) double EMS_6_OilPressure;
  double get_EMS_4_Timeout_Flag(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_4_Timeout_Flag_GW_PC_6_1, FCAN.FData);}
  void set_EMS_4_Timeout_Flag(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_4_Timeout_Flag_GW_PC_6_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_4_Timeout_Flag, put = set_EMS_4_Timeout_Flag)) double EMS_4_Timeout_Flag;
  double get_EMS_6_Timeout_Flag(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_6_Timeout_Flag_GW_PC_6_1, FCAN.FData);}
  void set_EMS_6_Timeout_Flag(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_6_Timeout_Flag_GW_PC_6_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_6_Timeout_Flag, put = set_EMS_6_Timeout_Flag)) double EMS_6_Timeout_Flag;
  double get_TCU_3_Timeout_Flag1(void) { return com.get_can_signal_value((TCANSignal* const)&TCU_3_Timeout_Flag1_GW_PC_6_1, FCAN.FData);}
  void set_TCU_3_Timeout_Flag1(const double value) { com.set_can_signal_value((TCANSignal* const)&TCU_3_Timeout_Flag1_GW_PC_6_1, FCAN.FData, value);}
  __declspec(property(get = get_TCU_3_Timeout_Flag1, put = set_TCU_3_Timeout_Flag1)) double TCU_3_Timeout_Flag1;
  double get_EMS_6_GPFState(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_6_GPFState_GW_PC_6_1, FCAN.FData);}
  void set_EMS_6_GPFState(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_6_GPFState_GW_PC_6_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_6_GPFState, put = set_EMS_6_GPFState)) double EMS_6_GPFState;
  double get_EMS_6_GeneratorFaultLamp(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_6_GeneratorFaultLamp_GW_PC_6_1, FCAN.FData);}
  void set_EMS_6_GeneratorFaultLamp(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_6_GeneratorFaultLamp_GW_PC_6_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_6_GeneratorFaultLamp, put = set_EMS_6_GeneratorFaultLamp)) double EMS_6_GeneratorFaultLamp;
  double get_EMS_6_OilPressureLamp(void) { return com.get_can_signal_value((TCANSignal* const)&EMS_6_OilPressureLamp_GW_PC_6_1, FCAN.FData);}
  void set_EMS_6_OilPressureLamp(const double value) { com.set_can_signal_value((TCANSignal* const)&EMS_6_OilPressureLamp_GW_PC_6_1, FCAN.FData, value);}
  __declspec(property(get = get_EMS_6_OilPressureLamp, put = set_EMS_6_OilPressureLamp)) double EMS_6_OilPressureLamp;
  void init() { FCAN = create().FCAN; }
  TGW_PC_6_1 create() { CANMsgDecl(_GW_PC_6_1, cGW_PC_6_1, 0, 0, 8, 341) return cGW_PC_6_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message ESP_2_1
extern const TCANSignal ESP_LongitAccel_ESP_2_1;
extern const TCANSignal ESP_LateralAccel_ESP_2_1;
extern const TCANSignal ESP_YawRate_ESP_2_1;
extern const TCANSignal ESP_LongitSensorValid_ESP_2_1;
extern const TCANSignal ESP_LateralSensorValid_ESP_2_1;
extern const TCANSignal ESP_YawRateSensorValid_ESP_2_1;
struct _ESP_2_1;
typedef struct _ESP_2_1 TESP_2_1;
struct _ESP_2_1{
  TCAN FCAN;
  double get_ESP_LongitAccel(void) { return com.get_can_signal_value((TCANSignal* const)&ESP_LongitAccel_ESP_2_1, FCAN.FData);}
  void set_ESP_LongitAccel(const double value) { com.set_can_signal_value((TCANSignal* const)&ESP_LongitAccel_ESP_2_1, FCAN.FData, value);}
  __declspec(property(get = get_ESP_LongitAccel, put = set_ESP_LongitAccel)) double ESP_LongitAccel;
  double get_ESP_LateralAccel(void) { return com.get_can_signal_value((TCANSignal* const)&ESP_LateralAccel_ESP_2_1, FCAN.FData);}
  void set_ESP_LateralAccel(const double value) { com.set_can_signal_value((TCANSignal* const)&ESP_LateralAccel_ESP_2_1, FCAN.FData, value);}
  __declspec(property(get = get_ESP_LateralAccel, put = set_ESP_LateralAccel)) double ESP_LateralAccel;
  double get_ESP_YawRate(void) { return com.get_can_signal_value((TCANSignal* const)&ESP_YawRate_ESP_2_1, FCAN.FData);}
  void set_ESP_YawRate(const double value) { com.set_can_signal_value((TCANSignal* const)&ESP_YawRate_ESP_2_1, FCAN.FData, value);}
  __declspec(property(get = get_ESP_YawRate, put = set_ESP_YawRate)) double ESP_YawRate;
  double get_ESP_LongitSensorValid(void) { return com.get_can_signal_value((TCANSignal* const)&ESP_LongitSensorValid_ESP_2_1, FCAN.FData);}
  void set_ESP_LongitSensorValid(const double value) { com.set_can_signal_value((TCANSignal* const)&ESP_LongitSensorValid_ESP_2_1, FCAN.FData, value);}
  __declspec(property(get = get_ESP_LongitSensorValid, put = set_ESP_LongitSensorValid)) double ESP_LongitSensorValid;
  double get_ESP_LateralSensorValid(void) { return com.get_can_signal_value((TCANSignal* const)&ESP_LateralSensorValid_ESP_2_1, FCAN.FData);}
  void set_ESP_LateralSensorValid(const double value) { com.set_can_signal_value((TCANSignal* const)&ESP_LateralSensorValid_ESP_2_1, FCAN.FData, value);}
  __declspec(property(get = get_ESP_LateralSensorValid, put = set_ESP_LateralSensorValid)) double ESP_LateralSensorValid;
  double get_ESP_YawRateSensorValid(void) { return com.get_can_signal_value((TCANSignal* const)&ESP_YawRateSensorValid_ESP_2_1, FCAN.FData);}
  void set_ESP_YawRateSensorValid(const double value) { com.set_can_signal_value((TCANSignal* const)&ESP_YawRateSensorValid_ESP_2_1, FCAN.FData, value);}
  __declspec(property(get = get_ESP_YawRateSensorValid, put = set_ESP_YawRateSensorValid)) double ESP_YawRateSensorValid;
  void init() { FCAN = create().FCAN; }
  TESP_2_1 create() { CANMsgDecl(_ESP_2_1, cESP_2_1, 0, 0, 8, 529) return cESP_2_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message BCM_3_1
extern const TCANSignal BCM_ConsoleBtn1TriggerSts_BCM_3_1;
extern const TCANSignal BCM_3_RollingCounter_BCM_3_1;
extern const TCANSignal BCM_3_Checksum_BCM_3_1;
struct _BCM_3_1;
typedef struct _BCM_3_1 TBCM_3_1;
struct _BCM_3_1{
  TCAN FCAN;
  double get_BCM_ConsoleBtn1TriggerSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_ConsoleBtn1TriggerSts_BCM_3_1, FCAN.FData);}
  void set_BCM_ConsoleBtn1TriggerSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_ConsoleBtn1TriggerSts_BCM_3_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_ConsoleBtn1TriggerSts, put = set_BCM_ConsoleBtn1TriggerSts)) double BCM_ConsoleBtn1TriggerSts;
  double get_BCM_3_RollingCounter(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_3_RollingCounter_BCM_3_1, FCAN.FData);}
  void set_BCM_3_RollingCounter(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_3_RollingCounter_BCM_3_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_3_RollingCounter, put = set_BCM_3_RollingCounter)) double BCM_3_RollingCounter;
  double get_BCM_3_Checksum(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_3_Checksum_BCM_3_1, FCAN.FData);}
  void set_BCM_3_Checksum(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_3_Checksum_BCM_3_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_3_Checksum, put = set_BCM_3_Checksum)) double BCM_3_Checksum;
  void init() { FCAN = create().FCAN; }
  TBCM_3_1 create() { CANMsgDecl(_BCM_3_1, cBCM_3_1, 0, 0, 8, 785) return cBCM_3_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message GW_BD_9_1
extern const TCANSignal BCM_1_PowerMode_GW_BD_9_1;
extern const TCANSignal BCM_1_LowBeamSts_GW_BD_9_1;
extern const TCANSignal BCM_1_HighBeamSts_GW_BD_9_1;
extern const TCANSignal BCM_1_LeftTurnLightSts_GW_BD_9_1;
extern const TCANSignal BCM_1_RightTurnLightSts_GW_BD_9_1;
extern const TCANSignal BCM_1_PositionLightSts_GW_BD_9_1;
extern const TCANSignal BCM_1_EmergencyLightSts_GW_BD_9_1;
extern const TCANSignal BCM_1_RearFogLightSts_GW_BD_9_1;
extern const TCANSignal BCM_1_FrontFogLightSts_GW_BD_9_1;
extern const TCANSignal BCM_1_DaytimeRunningLightSts_GW_BD_9_1;
extern const TCANSignal BCM_1_FrontLeftDoorSts_GW_BD_9_1;
extern const TCANSignal BCM_1_FrontRightDoorSts_GW_BD_9_1;
extern const TCANSignal BCM_1_RearLeftDoorSts_GW_BD_9_1;
extern const TCANSignal BCM_1_RearRightDoorSts_GW_BD_9_1;
extern const TCANSignal BCM_1_TailGateOpenSts_GW_BD_9_1;
extern const TCANSignal BCM_1_ACRearFrostSts_GW_BD_9_1;
extern const TCANSignal BCM_1_ReverseGearInfo_GW_BD_9_1;
extern const TCANSignal BCM_1_HoodSts_GW_BD_9_1;
extern const TCANSignal BCM_1_BackMirrorFolderSts_GW_BD_9_1;
extern const TCANSignal TCM_1_HighBeamSWSts_GW_BD_9_1;
extern const TCANSignal TCM_1_HighBeamSWStsValid_GW_BD_9_1;
extern const TCANSignal TCM_1_FlashLightSWSts_GW_BD_9_1;
extern const TCANSignal TCM_1_FlashLightSWStsValid_GW_BD_9_1;
extern const TCANSignal BCM_1_Timeout_Flag_GW_BD_9_1;
extern const TCANSignal TCM_1_Timeout_Flag_GW_BD_9_1;
extern const TCANSignal TCM_1_RightTurnLightSWStsValid_GW_BD_9_1;
extern const TCANSignal TCM_1_RightTurnLightSWSts_GW_BD_9_1;
extern const TCANSignal TCM_1_LeftTurnLightSWStsValid_GW_BD_9_1;
extern const TCANSignal TCM_1_LeftTurnLightSWSts_GW_BD_9_1;
struct _GW_BD_9_1;
typedef struct _GW_BD_9_1 TGW_BD_9_1;
struct _GW_BD_9_1{
  TCAN FCAN;
  double get_BCM_1_PowerMode(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_1_PowerMode_GW_BD_9_1, FCAN.FData);}
  void set_BCM_1_PowerMode(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_1_PowerMode_GW_BD_9_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_1_PowerMode, put = set_BCM_1_PowerMode)) double BCM_1_PowerMode;
  double get_BCM_1_LowBeamSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_1_LowBeamSts_GW_BD_9_1, FCAN.FData);}
  void set_BCM_1_LowBeamSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_1_LowBeamSts_GW_BD_9_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_1_LowBeamSts, put = set_BCM_1_LowBeamSts)) double BCM_1_LowBeamSts;
  double get_BCM_1_HighBeamSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_1_HighBeamSts_GW_BD_9_1, FCAN.FData);}
  void set_BCM_1_HighBeamSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_1_HighBeamSts_GW_BD_9_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_1_HighBeamSts, put = set_BCM_1_HighBeamSts)) double BCM_1_HighBeamSts;
  double get_BCM_1_LeftTurnLightSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_1_LeftTurnLightSts_GW_BD_9_1, FCAN.FData);}
  void set_BCM_1_LeftTurnLightSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_1_LeftTurnLightSts_GW_BD_9_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_1_LeftTurnLightSts, put = set_BCM_1_LeftTurnLightSts)) double BCM_1_LeftTurnLightSts;
  double get_BCM_1_RightTurnLightSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_1_RightTurnLightSts_GW_BD_9_1, FCAN.FData);}
  void set_BCM_1_RightTurnLightSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_1_RightTurnLightSts_GW_BD_9_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_1_RightTurnLightSts, put = set_BCM_1_RightTurnLightSts)) double BCM_1_RightTurnLightSts;
  double get_BCM_1_PositionLightSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_1_PositionLightSts_GW_BD_9_1, FCAN.FData);}
  void set_BCM_1_PositionLightSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_1_PositionLightSts_GW_BD_9_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_1_PositionLightSts, put = set_BCM_1_PositionLightSts)) double BCM_1_PositionLightSts;
  double get_BCM_1_EmergencyLightSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_1_EmergencyLightSts_GW_BD_9_1, FCAN.FData);}
  void set_BCM_1_EmergencyLightSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_1_EmergencyLightSts_GW_BD_9_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_1_EmergencyLightSts, put = set_BCM_1_EmergencyLightSts)) double BCM_1_EmergencyLightSts;
  double get_BCM_1_RearFogLightSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_1_RearFogLightSts_GW_BD_9_1, FCAN.FData);}
  void set_BCM_1_RearFogLightSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_1_RearFogLightSts_GW_BD_9_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_1_RearFogLightSts, put = set_BCM_1_RearFogLightSts)) double BCM_1_RearFogLightSts;
  double get_BCM_1_FrontFogLightSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_1_FrontFogLightSts_GW_BD_9_1, FCAN.FData);}
  void set_BCM_1_FrontFogLightSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_1_FrontFogLightSts_GW_BD_9_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_1_FrontFogLightSts, put = set_BCM_1_FrontFogLightSts)) double BCM_1_FrontFogLightSts;
  double get_BCM_1_DaytimeRunningLightSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_1_DaytimeRunningLightSts_GW_BD_9_1, FCAN.FData);}
  void set_BCM_1_DaytimeRunningLightSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_1_DaytimeRunningLightSts_GW_BD_9_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_1_DaytimeRunningLightSts, put = set_BCM_1_DaytimeRunningLightSts)) double BCM_1_DaytimeRunningLightSts;
  double get_BCM_1_FrontLeftDoorSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_1_FrontLeftDoorSts_GW_BD_9_1, FCAN.FData);}
  void set_BCM_1_FrontLeftDoorSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_1_FrontLeftDoorSts_GW_BD_9_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_1_FrontLeftDoorSts, put = set_BCM_1_FrontLeftDoorSts)) double BCM_1_FrontLeftDoorSts;
  double get_BCM_1_FrontRightDoorSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_1_FrontRightDoorSts_GW_BD_9_1, FCAN.FData);}
  void set_BCM_1_FrontRightDoorSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_1_FrontRightDoorSts_GW_BD_9_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_1_FrontRightDoorSts, put = set_BCM_1_FrontRightDoorSts)) double BCM_1_FrontRightDoorSts;
  double get_BCM_1_RearLeftDoorSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_1_RearLeftDoorSts_GW_BD_9_1, FCAN.FData);}
  void set_BCM_1_RearLeftDoorSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_1_RearLeftDoorSts_GW_BD_9_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_1_RearLeftDoorSts, put = set_BCM_1_RearLeftDoorSts)) double BCM_1_RearLeftDoorSts;
  double get_BCM_1_RearRightDoorSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_1_RearRightDoorSts_GW_BD_9_1, FCAN.FData);}
  void set_BCM_1_RearRightDoorSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_1_RearRightDoorSts_GW_BD_9_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_1_RearRightDoorSts, put = set_BCM_1_RearRightDoorSts)) double BCM_1_RearRightDoorSts;
  double get_BCM_1_TailGateOpenSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_1_TailGateOpenSts_GW_BD_9_1, FCAN.FData);}
  void set_BCM_1_TailGateOpenSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_1_TailGateOpenSts_GW_BD_9_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_1_TailGateOpenSts, put = set_BCM_1_TailGateOpenSts)) double BCM_1_TailGateOpenSts;
  double get_BCM_1_ACRearFrostSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_1_ACRearFrostSts_GW_BD_9_1, FCAN.FData);}
  void set_BCM_1_ACRearFrostSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_1_ACRearFrostSts_GW_BD_9_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_1_ACRearFrostSts, put = set_BCM_1_ACRearFrostSts)) double BCM_1_ACRearFrostSts;
  double get_BCM_1_ReverseGearInfo(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_1_ReverseGearInfo_GW_BD_9_1, FCAN.FData);}
  void set_BCM_1_ReverseGearInfo(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_1_ReverseGearInfo_GW_BD_9_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_1_ReverseGearInfo, put = set_BCM_1_ReverseGearInfo)) double BCM_1_ReverseGearInfo;
  double get_BCM_1_HoodSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_1_HoodSts_GW_BD_9_1, FCAN.FData);}
  void set_BCM_1_HoodSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_1_HoodSts_GW_BD_9_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_1_HoodSts, put = set_BCM_1_HoodSts)) double BCM_1_HoodSts;
  double get_BCM_1_BackMirrorFolderSts(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_1_BackMirrorFolderSts_GW_BD_9_1, FCAN.FData);}
  void set_BCM_1_BackMirrorFolderSts(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_1_BackMirrorFolderSts_GW_BD_9_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_1_BackMirrorFolderSts, put = set_BCM_1_BackMirrorFolderSts)) double BCM_1_BackMirrorFolderSts;
  double get_TCM_1_HighBeamSWSts(void) { return com.get_can_signal_value((TCANSignal* const)&TCM_1_HighBeamSWSts_GW_BD_9_1, FCAN.FData);}
  void set_TCM_1_HighBeamSWSts(const double value) { com.set_can_signal_value((TCANSignal* const)&TCM_1_HighBeamSWSts_GW_BD_9_1, FCAN.FData, value);}
  __declspec(property(get = get_TCM_1_HighBeamSWSts, put = set_TCM_1_HighBeamSWSts)) double TCM_1_HighBeamSWSts;
  double get_TCM_1_HighBeamSWStsValid(void) { return com.get_can_signal_value((TCANSignal* const)&TCM_1_HighBeamSWStsValid_GW_BD_9_1, FCAN.FData);}
  void set_TCM_1_HighBeamSWStsValid(const double value) { com.set_can_signal_value((TCANSignal* const)&TCM_1_HighBeamSWStsValid_GW_BD_9_1, FCAN.FData, value);}
  __declspec(property(get = get_TCM_1_HighBeamSWStsValid, put = set_TCM_1_HighBeamSWStsValid)) double TCM_1_HighBeamSWStsValid;
  double get_TCM_1_FlashLightSWSts(void) { return com.get_can_signal_value((TCANSignal* const)&TCM_1_FlashLightSWSts_GW_BD_9_1, FCAN.FData);}
  void set_TCM_1_FlashLightSWSts(const double value) { com.set_can_signal_value((TCANSignal* const)&TCM_1_FlashLightSWSts_GW_BD_9_1, FCAN.FData, value);}
  __declspec(property(get = get_TCM_1_FlashLightSWSts, put = set_TCM_1_FlashLightSWSts)) double TCM_1_FlashLightSWSts;
  double get_TCM_1_FlashLightSWStsValid(void) { return com.get_can_signal_value((TCANSignal* const)&TCM_1_FlashLightSWStsValid_GW_BD_9_1, FCAN.FData);}
  void set_TCM_1_FlashLightSWStsValid(const double value) { com.set_can_signal_value((TCANSignal* const)&TCM_1_FlashLightSWStsValid_GW_BD_9_1, FCAN.FData, value);}
  __declspec(property(get = get_TCM_1_FlashLightSWStsValid, put = set_TCM_1_FlashLightSWStsValid)) double TCM_1_FlashLightSWStsValid;
  double get_BCM_1_Timeout_Flag(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_1_Timeout_Flag_GW_BD_9_1, FCAN.FData);}
  void set_BCM_1_Timeout_Flag(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_1_Timeout_Flag_GW_BD_9_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_1_Timeout_Flag, put = set_BCM_1_Timeout_Flag)) double BCM_1_Timeout_Flag;
  double get_TCM_1_Timeout_Flag(void) { return com.get_can_signal_value((TCANSignal* const)&TCM_1_Timeout_Flag_GW_BD_9_1, FCAN.FData);}
  void set_TCM_1_Timeout_Flag(const double value) { com.set_can_signal_value((TCANSignal* const)&TCM_1_Timeout_Flag_GW_BD_9_1, FCAN.FData, value);}
  __declspec(property(get = get_TCM_1_Timeout_Flag, put = set_TCM_1_Timeout_Flag)) double TCM_1_Timeout_Flag;
  double get_TCM_1_RightTurnLightSWStsValid(void) { return com.get_can_signal_value((TCANSignal* const)&TCM_1_RightTurnLightSWStsValid_GW_BD_9_1, FCAN.FData);}
  void set_TCM_1_RightTurnLightSWStsValid(const double value) { com.set_can_signal_value((TCANSignal* const)&TCM_1_RightTurnLightSWStsValid_GW_BD_9_1, FCAN.FData, value);}
  __declspec(property(get = get_TCM_1_RightTurnLightSWStsValid, put = set_TCM_1_RightTurnLightSWStsValid)) double TCM_1_RightTurnLightSWStsValid;
  double get_TCM_1_RightTurnLightSWSts(void) { return com.get_can_signal_value((TCANSignal* const)&TCM_1_RightTurnLightSWSts_GW_BD_9_1, FCAN.FData);}
  void set_TCM_1_RightTurnLightSWSts(const double value) { com.set_can_signal_value((TCANSignal* const)&TCM_1_RightTurnLightSWSts_GW_BD_9_1, FCAN.FData, value);}
  __declspec(property(get = get_TCM_1_RightTurnLightSWSts, put = set_TCM_1_RightTurnLightSWSts)) double TCM_1_RightTurnLightSWSts;
  double get_TCM_1_LeftTurnLightSWStsValid(void) { return com.get_can_signal_value((TCANSignal* const)&TCM_1_LeftTurnLightSWStsValid_GW_BD_9_1, FCAN.FData);}
  void set_TCM_1_LeftTurnLightSWStsValid(const double value) { com.set_can_signal_value((TCANSignal* const)&TCM_1_LeftTurnLightSWStsValid_GW_BD_9_1, FCAN.FData, value);}
  __declspec(property(get = get_TCM_1_LeftTurnLightSWStsValid, put = set_TCM_1_LeftTurnLightSWStsValid)) double TCM_1_LeftTurnLightSWStsValid;
  double get_TCM_1_LeftTurnLightSWSts(void) { return com.get_can_signal_value((TCANSignal* const)&TCM_1_LeftTurnLightSWSts_GW_BD_9_1, FCAN.FData);}
  void set_TCM_1_LeftTurnLightSWSts(const double value) { com.set_can_signal_value((TCANSignal* const)&TCM_1_LeftTurnLightSWSts_GW_BD_9_1, FCAN.FData, value);}
  __declspec(property(get = get_TCM_1_LeftTurnLightSWSts, put = set_TCM_1_LeftTurnLightSWSts)) double TCM_1_LeftTurnLightSWSts;
  void init() { FCAN = create().FCAN; }
  TGW_BD_9_1 create() { CANMsgDecl(_GW_BD_9_1, cGW_BD_9_1, 0, 0, 8, 935) return cGW_BD_9_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message GW_BD_24_1
extern const TCANSignal BCM_2_WindowRunningStatusFL_GW_BD_24_1;
extern const TCANSignal BCM_2_WindowRunningStatusFR_GW_BD_24_1;
extern const TCANSignal BCM_2_WindowRunningStatusRL_GW_BD_24_1;
extern const TCANSignal BCM_2_WindowRunningStatusRR_GW_BD_24_1;
extern const TCANSignal BCM_2_WindowPosFL_GW_BD_24_1;
extern const TCANSignal BCM_2_WindowPosFR_GW_BD_24_1;
extern const TCANSignal BCM_2_WindowPosRL_GW_BD_24_1;
extern const TCANSignal BCM_2_WindowPosRR_GW_BD_24_1;
extern const TCANSignal BCM_2_Timeout_Flag_GW_BD_24_1;
struct _GW_BD_24_1;
typedef struct _GW_BD_24_1 TGW_BD_24_1;
struct _GW_BD_24_1{
  TCAN FCAN;
  double get_BCM_2_WindowRunningStatusFL(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_2_WindowRunningStatusFL_GW_BD_24_1, FCAN.FData);}
  void set_BCM_2_WindowRunningStatusFL(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_2_WindowRunningStatusFL_GW_BD_24_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_2_WindowRunningStatusFL, put = set_BCM_2_WindowRunningStatusFL)) double BCM_2_WindowRunningStatusFL;
  double get_BCM_2_WindowRunningStatusFR(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_2_WindowRunningStatusFR_GW_BD_24_1, FCAN.FData);}
  void set_BCM_2_WindowRunningStatusFR(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_2_WindowRunningStatusFR_GW_BD_24_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_2_WindowRunningStatusFR, put = set_BCM_2_WindowRunningStatusFR)) double BCM_2_WindowRunningStatusFR;
  double get_BCM_2_WindowRunningStatusRL(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_2_WindowRunningStatusRL_GW_BD_24_1, FCAN.FData);}
  void set_BCM_2_WindowRunningStatusRL(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_2_WindowRunningStatusRL_GW_BD_24_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_2_WindowRunningStatusRL, put = set_BCM_2_WindowRunningStatusRL)) double BCM_2_WindowRunningStatusRL;
  double get_BCM_2_WindowRunningStatusRR(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_2_WindowRunningStatusRR_GW_BD_24_1, FCAN.FData);}
  void set_BCM_2_WindowRunningStatusRR(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_2_WindowRunningStatusRR_GW_BD_24_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_2_WindowRunningStatusRR, put = set_BCM_2_WindowRunningStatusRR)) double BCM_2_WindowRunningStatusRR;
  double get_BCM_2_WindowPosFL(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_2_WindowPosFL_GW_BD_24_1, FCAN.FData);}
  void set_BCM_2_WindowPosFL(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_2_WindowPosFL_GW_BD_24_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_2_WindowPosFL, put = set_BCM_2_WindowPosFL)) double BCM_2_WindowPosFL;
  double get_BCM_2_WindowPosFR(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_2_WindowPosFR_GW_BD_24_1, FCAN.FData);}
  void set_BCM_2_WindowPosFR(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_2_WindowPosFR_GW_BD_24_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_2_WindowPosFR, put = set_BCM_2_WindowPosFR)) double BCM_2_WindowPosFR;
  double get_BCM_2_WindowPosRL(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_2_WindowPosRL_GW_BD_24_1, FCAN.FData);}
  void set_BCM_2_WindowPosRL(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_2_WindowPosRL_GW_BD_24_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_2_WindowPosRL, put = set_BCM_2_WindowPosRL)) double BCM_2_WindowPosRL;
  double get_BCM_2_WindowPosRR(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_2_WindowPosRR_GW_BD_24_1, FCAN.FData);}
  void set_BCM_2_WindowPosRR(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_2_WindowPosRR_GW_BD_24_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_2_WindowPosRR, put = set_BCM_2_WindowPosRR)) double BCM_2_WindowPosRR;
  double get_BCM_2_Timeout_Flag(void) { return com.get_can_signal_value((TCANSignal* const)&BCM_2_Timeout_Flag_GW_BD_24_1, FCAN.FData);}
  void set_BCM_2_Timeout_Flag(const double value) { com.set_can_signal_value((TCANSignal* const)&BCM_2_Timeout_Flag_GW_BD_24_1, FCAN.FData, value);}
  __declspec(property(get = get_BCM_2_Timeout_Flag, put = set_BCM_2_Timeout_Flag)) double BCM_2_Timeout_Flag;
  void init() { FCAN = create().FCAN; }
  TGW_BD_24_1 create() { CANMsgDecl(_GW_BD_24_1, cGW_BD_24_1, 0, 0, 8, 967) return cGW_BD_24_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message IPB_3_1
extern const TCANSignal IPB_Faultlevel_IPB_3_1;
struct _IPB_3_1;
typedef struct _IPB_3_1 TIPB_3_1;
struct _IPB_3_1{
  TCAN FCAN;
  double get_IPB_Faultlevel(void) { return com.get_can_signal_value((TCANSignal* const)&IPB_Faultlevel_IPB_3_1, FCAN.FData);}
  void set_IPB_Faultlevel(const double value) { com.set_can_signal_value((TCANSignal* const)&IPB_Faultlevel_IPB_3_1, FCAN.FData, value);}
  __declspec(property(get = get_IPB_Faultlevel, put = set_IPB_Faultlevel)) double IPB_Faultlevel;
  void init() { FCAN = create().FCAN; }
  TIPB_3_1 create() { CANMsgDecl(_IPB_3_1, cIPB_3_1, 0, 0, 8, 536) return cIPB_3_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message VCU_42_1
extern const TCANSignal VCU_DrvRangeFuel_VCU_42_1;
extern const TCANSignal VCU_DrvRangeEV_VCU_42_1;
extern const TCANSignal VCU_DrvRangeTotal_VCU_42_1;
extern const TCANSignal VCU_AvgFuelConsLifetime_VCU_42_1;
extern const TCANSignal VCU_AvgPwrConsLifetime_VCU_42_1;
struct _VCU_42_1;
typedef struct _VCU_42_1 TVCU_42_1;
struct _VCU_42_1{
  TCAN FCAN;
  double get_VCU_DrvRangeFuel(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_DrvRangeFuel_VCU_42_1, FCAN.FData);}
  void set_VCU_DrvRangeFuel(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_DrvRangeFuel_VCU_42_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_DrvRangeFuel, put = set_VCU_DrvRangeFuel)) double VCU_DrvRangeFuel;
  double get_VCU_DrvRangeEV(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_DrvRangeEV_VCU_42_1, FCAN.FData);}
  void set_VCU_DrvRangeEV(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_DrvRangeEV_VCU_42_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_DrvRangeEV, put = set_VCU_DrvRangeEV)) double VCU_DrvRangeEV;
  double get_VCU_DrvRangeTotal(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_DrvRangeTotal_VCU_42_1, FCAN.FData);}
  void set_VCU_DrvRangeTotal(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_DrvRangeTotal_VCU_42_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_DrvRangeTotal, put = set_VCU_DrvRangeTotal)) double VCU_DrvRangeTotal;
  double get_VCU_AvgFuelConsLifetime(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_AvgFuelConsLifetime_VCU_42_1, FCAN.FData);}
  void set_VCU_AvgFuelConsLifetime(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_AvgFuelConsLifetime_VCU_42_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_AvgFuelConsLifetime, put = set_VCU_AvgFuelConsLifetime)) double VCU_AvgFuelConsLifetime;
  double get_VCU_AvgPwrConsLifetime(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_AvgPwrConsLifetime_VCU_42_1, FCAN.FData);}
  void set_VCU_AvgPwrConsLifetime(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_AvgPwrConsLifetime_VCU_42_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_AvgPwrConsLifetime, put = set_VCU_AvgPwrConsLifetime)) double VCU_AvgPwrConsLifetime;
  void init() { FCAN = create().FCAN; }
  TVCU_42_1 create() { CANMsgDecl(_VCU_42_1, cVCU_42_1, 0, 0, 8, 883) return cVCU_42_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// CAN Message VCU_43_1
extern const TCANSignal VCU_OdoMeterHEV_VCU_43_1;
extern const TCANSignal VCU_OdoMeterEV_VCU_43_1;
extern const TCANSignal VCU_OdoMeter_VCU_43_1;
struct _VCU_43_1;
typedef struct _VCU_43_1 TVCU_43_1;
struct _VCU_43_1{
  TCAN FCAN;
  double get_VCU_OdoMeterHEV(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_OdoMeterHEV_VCU_43_1, FCAN.FData);}
  void set_VCU_OdoMeterHEV(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_OdoMeterHEV_VCU_43_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_OdoMeterHEV, put = set_VCU_OdoMeterHEV)) double VCU_OdoMeterHEV;
  double get_VCU_OdoMeterEV(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_OdoMeterEV_VCU_43_1, FCAN.FData);}
  void set_VCU_OdoMeterEV(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_OdoMeterEV_VCU_43_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_OdoMeterEV, put = set_VCU_OdoMeterEV)) double VCU_OdoMeterEV;
  double get_VCU_OdoMeter(void) { return com.get_can_signal_value((TCANSignal* const)&VCU_OdoMeter_VCU_43_1, FCAN.FData);}
  void set_VCU_OdoMeter(const double value) { com.set_can_signal_value((TCANSignal* const)&VCU_OdoMeter_VCU_43_1, FCAN.FData, value);}
  __declspec(property(get = get_VCU_OdoMeter, put = set_VCU_OdoMeter)) double VCU_OdoMeter;
  void init() { FCAN = create().FCAN; }
  TVCU_43_1 create() { CANMsgDecl(_VCU_43_1, cVCU_43_1, 0, 0, 8, 884) return cVCU_43_1; }
  void set_data(const PCAN ACAN) { FCAN = *ACAN; }
};

// LIN Databases
// FlexRay Databases
#endif
