﻿#include "TSMasterBaseInclude.h"

/*
DLLEXPORT void __stdcall write_api_document(const void* AOpaque, const TWriteAPIDocumentFunc AAPIFunc, const TWriteAPIParaFunc AParaFunc){
  // To add document for one function with 3 arguments, you need to write 4 (1 + 3) lines of code:
  // If you export this function, auto generated function "write_api_document_auto" will be dismissed
  AAPIFunc(AOpaque, "your_func_name", "your_lib_name", "your function description", "example code for your function", 3);
  AParaFunc(AOpaque, 0, "your_func_name", "Arg1", true, "s32", "description for Arg1");
  AParaFunc(AOpaque, 1, "your_func_name", "Arg2", true, "double", "description for Arg2");
  AParaFunc(AOpaque, 2, "your_func_name", "Arg3", true, "char*", "description for Arg3");

}
*/

